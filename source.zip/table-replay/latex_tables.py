"""Shared LaTeX table formatting."""


def write(path, value):
    path.write_text(value.strip() + "\n", encoding="utf-8")


def table(label, caption, columns, header, rows):
    return "\n".join([
        r"\begin{table}[htbp]", r"\centering\small",
        r"\caption{" + caption + "}", r"\label{" + label + "}",
        r"\begin{tabular}{" + columns + "}", r"\toprule",
        header + r"\\", r"\midrule",
        *(" & ".join(map(str, row)) + r"\\" for row in rows),
        r"\bottomrule", r"\end{tabular}", r"\end{table}",
    ])
