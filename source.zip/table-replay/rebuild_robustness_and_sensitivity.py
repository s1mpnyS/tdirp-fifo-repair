"""Verify the bundled follow-up summaries and rebuild their LaTeX tables."""
from collections import defaultdict
from fractions import Fraction
import json
from math import isclose

from latex_tables import table, write
from rebuild_main_comparisons import BASE, CONTRASTS, contrast, pp, require, sha


OUT = BASE / "display/robustness-and-sensitivity"
EVIDENCE = BASE / "evidence/robustness-and-sensitivity"
CONFIRMATION = BASE / "evidence/probe-confirmation/probe-confirmation-20261111T112110Z"
RUNS = {
    "cold": "robust-confirmation-packed-20261110T142959Z",
    "coordination": "robust-coordination-packed-20261110T054105Z",
    "sensitivity": "sensitivity-packed-20261110T222614Z",
}
TREATMENTS = {
    "base": "Base", "q_mid": r"$Q_{\mathrm{mid}}$", "q_low": r"$Q_{\mathrm{low}}$",
    "h_0_5": r"Holding $\times 0.5$", "h_2": r"Holding $\times 2$", "h_5": r"Holding $\times 5$",
}


def read(root, name):
    return json.loads((root / name).read_bytes())


def close(observed, expected):
    return isclose(float(observed), float(expected), rel_tol=0, abs_tol=1e-12)


def interval(values):
    return f"[{values[0]:.3f}, {values[1]:.3f}]"


def robust_rows(kind):
    root = EVIDENCE / RUNS[kind]
    data, plan, raw = (read(root, name) for name in ("analysis.json", "plan.json", "results.json"))
    require(data["raw_results_sha256"] == sha((root / "results.json").read_bytes())
            and plan["runtime_record_sha256"] == sha((root / "runtime_observed.json").read_bytes())
            and data["plan_sha256"] == plan["plan_sha256"] == raw["plan_sha256"], "Robustness digest mismatch")
    count = 240 if kind == "cold" else 160
    require(data["status"] == "N50_FULL_PIPELINE_PHYSICAL_REPLAY_PASS" and raw["status"] == "COMPLETED"
            and len(raw["row_index"]) == len(plan["cells"]) == len(data["rows"]) == count,
            "Incomplete robustness campaign")
    for row, cell, receipt in zip(data["rows"], plan["cells"], raw["row_index"], strict=True):
        require(all(row[field] == cell[field] for field in ("cell_id", "input", "arm", "seed"))
                and receipt["cell_id"] == cell["cell_id"] and row["worker_exit_code"] == 0
                and row["clean_resource_timing"], "Robustness assignment or timing mismatch")

    rows = []
    for comparator, method in CONTRASTS[kind]:
        key = f"{method}_vs_{comparator}"
        per_file = defaultdict(list)
        for seed, pairs in sorted(data["pairs_by_seed"].items()):
            require(len(pairs) == len({pair["input"] for pair in pairs}) == 40, "Incomplete seed pairs")
            costs = {(row["input"], row["arm"]): row["final"] for row in data["rows"] if str(row["seed"]) == seed}
            for pair in pairs:
                require(all(float(Fraction(cost)) == costs[pair["input"], arm]
                            for arm, cost in pair["costs_exact"].items()), "Pair cost differs from endpoint")
                per_file[pair["input"]].append(pp(pair, comparator, method))
            result = contrast({"pairs": pairs, "family_contrasts": data["seed_contrasts"][seed]}, comparator, method)
            rows.append(contrast_row(method, comparator, seed, result))
        result = data["family_contrasts"][key]
        require(len(per_file) == 40 and all(len(values) == 2 for values in per_file.values())
                and close(sum(sum(values) for values in per_file.values()) / 80, result["mean_family_pp"]),
                "Pooled robustness gain differs")
        rows.append(contrast_row(method, comparator, "Pooled", result))
    return rows


def contrast_row(method, comparator, seed, result):
    return (f"{method} over {comparator}", seed, f"{result['mean_family_pp']:.3f}",
            interval(result["bootstrap_95_percentile_pp"]), "/".join(map(str, result["file_w_t_l"])))


def confirmed_probes(original, plan, replay):
    root = CONFIRMATION
    analysis, roster, proof, progress = (read(root, name) for name in (
        "analysis.json", "confirmation_plan.json", "external_timestamp_verified_before_first_probe.json", "progress.json"))
    require(analysis["status"] == "PROSPECTIVE_PROBE_CONFIRMATION"
            and analysis["original_plan_sha256"] == roster["original_plan_sha256"] == plan["plan_sha256"]
            and analysis["confirmation_plan_sha256"] == sha((root / "confirmation_plan.json").read_bytes())
            and roster["original_index_sha256"] == sha((original / "run/progress.json").read_bytes())
            and analysis["freeze_manifest_sha256"] == proof["manifest_sha256"]
            == sha((root / "execution_freeze.json").read_bytes())
            and proof["status"] == "VERIFIED_EXTERNAL_TIMESTAMP_AND_MEMBER_BYTES", "Confirmation digest mismatch")
    require(analysis["assigned_probes"] == len(progress) == len(roster["assignments"]) == 120
            and analysis["probes"] == progress and analysis["eligibility_counts"] == {"eligible": 120},
            "Incomplete prospective confirmation")
    original_cells = [cell for cell in plan["cells"] if cell["arm"] == "P"]
    require([item["cell"] for item in roster["assignments"]] == original_cells, "Probe assignment changed")
    original_index = read(original, "run/progress.json")
    posthoc = {probe["cell_id"]: probe for probe in replay["probes"]}
    for item, probe in zip(roster["assignments"], progress, strict=True):
        cell = item["cell"]
        previous = posthoc[cell["cell_id"]]
        require(item["source_parent_sha256"] == original_index[cell["source_cell"]]["sha256"]
                and all(probe[key] == previous[key] for key in ("cell_id", "family", "input", "seed", "treatment", "joint_hit"))
                and probe["eligibility"] == "eligible" and probe["clean_resource_timing"]
                and 0 <= probe["first_sample_seconds"] <= probe["verified_pre_solve_checkpoint_seconds"] < 32
                and probe["max_sampling_gap_seconds"] <= 1
                and probe["peak_sampled_tree_rss_bytes"] <= 1024 * 2**20
                and probe["singleton_status"] == "certified" and probe["joint_attempted"] and not probe["joint_deadline"],
                "Confirmation does not match original endpoint, assignment or monitoring rule")
    return analysis


def sensitivity_tables():
    root = EVIDENCE / RUNS["sensitivity"]
    data, plan, replay = (read(root, name) for name in ("analysis.json", "plan.json", "escape_posthoc_replay.json"))
    require(data["plan_sha256"] == plan["plan_sha256"] == replay["plan_sha256"]
            and replay["original_analysis_sha256"] == sha((root / "analysis.json").read_bytes())
            and replay["evidence_index_sha256"] == sha((root / "run/progress.json").read_bytes())
            and plan["runtime_record_sha256"] == sha((root / "runtime_observed.json").read_bytes()),
            "Sensitivity or replay digest mismatch")
    require(data["assigned_cells"] == data["recorded_cells"] == len(plan["cells"]) == 360
            and len(data["rows"]) == 240 and not data["probes"]
            and replay["assigned_probes"] == replay["startup_gap_replayed"] == len(replay["probes"]) == 120
            and not replay["original_clean_replayed"] and not replay["excluded_probes"],
            "Sensitivity or probe coverage changed")

    endpoints = defaultdict(dict)
    for row in data["rows"]:
        require(row["status"] == "complete" and row["resource_timing_clean"], "Unverified sensitivity endpoint")
        endpoints[row["treatment"], row["family"], row["seed"]][row["arm"]] = row
    gains = {}
    for key, arms in endpoints.items():
        k1, k6 = arms["K1"], arms["K6"]
        require(k1["start_cost"] == k6["start_cost"], "Sensitivity pair has different starts")
        gains[key] = 100 * (Fraction(k1["final_cost"]) - Fraction(k6["final_cost"])) / Fraction(k1["start_cost"])

    hits = {}
    for probe in replay["probes"]:
        key = (probe["treatment"], probe["family"], probe["seed"])
        require(key not in hits and probe["singleton_status"] == "certified" and probe["joint_attempted"]
                and not probe["joint_deadline"] and 1 < probe["first_sample_seconds"]
                <= probe["verified_pre_solve_checkpoint_seconds"] < 32
                and probe["max_gap_after_first_sample_seconds"] <= 1
                and probe["peak_sampled_tree_rss_bytes"] <= 1024 * 2**20,
                "Ineligible or duplicate replayed probe")
        hits[key] = probe["joint_hit"]
    require(gains.keys() == hits.keys() and len(gains) == 120, "Sensitivity pair and probe grids differ")
    confirmation = confirmed_probes(root, plan, replay)

    main, decomposition = [], []
    family_rows = defaultdict(list)
    for treatment, label in TREATMENTS.items():
        keys = sorted(key for key in gains if key[0] == treatment)
        require(len(keys) == 20 and all(gains[key] > 0 for key in keys), "Sensitivity gain coverage changed")
        result = data["analysis"]["treatments"][treatment]
        mean = sum(gains[key] for key in keys) / len(keys)
        change = sum(gains[key] - gains["base", *key[1:]] for key in keys) / len(keys)
        require(close(mean, result["joint_gain_pp"]["mean_family"]), "Reported sensitivity gain differs")
        shift = result["paired_increment_vs_base_pp"]
        if shift is not None:
            require(close(change, shift["mean_family"]), "Reported paired change differs")
        escaped = sum(hits[key] for key in keys)
        escape = confirmation["directed_escape_by_treatment"][treatment]
        require(escape["certified_joint_hits"] == escaped and escape["reported_probes"] == len(keys),
                "Reported escape count differs")
        main.append((label, f"{float(mean):.3f}", f"{float(change):+.3f}" if shift else "--",
                     interval(shift["bootstrap_95_percentile"]) if shift else "--", f"{escaped}/{len(keys)}"))
        absolute = []
        for key in keys:
            k1, k6 = (endpoints[key][arm] for arm in ("K1", "K6"))
            gap, route, customer, depot, stock = (Fraction(k1[field]) - Fraction(k6[field]) for field in
                ("final_cost", "route_completion", "customer_holding", "depot_holding", "customer_inventory_units"))
            require(gap == route + customer + depot, "Absolute objective components do not add up")
            delivered = sum(k1["period_loads"]) - sum(k6["period_loads"])
            absolute.append((gap, route, customer, depot, stock, delivered))
        means = [sum(values) / len(keys) for values in zip(*absolute, strict=True)]
        require(close(means[0], result["raw_objective_advantage"]["mean_family"]), "Reported raw objective gap differs")
        decomposition.append((label, *(f"{float(value):,.2f}" for value in means)))
        for family in sorted({key[1] for key in keys}):
            group = [key for key in keys if key[1] == family]
            require(len(group) == 2, "Expected two seeds per family and treatment")
            family_rows[family].append(f"{float(sum(gains[key] for key in group) / 2):.3f} ({sum(hits[key] for key in group)}/2)")
    return main, [(family[-2:], *values) for family, values in sorted(family_rows.items())], decomposition


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    seeds = robust_rows("cold") + robust_rows("coordination")
    write(OUT / "seed_contrasts.tex", table("tab:v19-seed-contrasts",
        "Robustness across two additional seeds. Pooled rows average seeds within each file. "
        "Gains use the study-specific reference cost in percentage points. File W/T/L counts 40 files per row.",
        "llrrr", r"Contrast & Seed & Mean gain & 95\% interval & File W/T/L", seeds))
    sensitivity, families, decomposition = sensitivity_tables()
    write(OUT / "sensitivity.tex", table("tab:v19-sensitivity",
        r"Matched 90-second sensitivity contrasts. Gains and changes are in percentage points of the "
        r"treatment-specific starting cost. The pointwise 95\% intervals apply to the paired changes. "
        r"Escape counts come from the prospectively timestamped confirmation on the original endpoint--block pairs.",
        "lrrrr", r"Condition & K6 gain & Change vs. base & 95\% interval & Escape hits", sensitivity))
    write(OUT / "sensitivity_families.tex", table("tab:v19-sensitivity-families",
        "K6 gain in percentage points and confirmed escape hits by family. Each entry averages two matched seeds. "
        "The count in parentheses is the number of escape hits over the two seeds.",
        "rrrrrrr", " & ".join(["Family", *TREATMENTS.values()]), families))
    write(OUT / "sensitivity_components.tex", table("tab:v20-sensitivity-components",
        "Mean paired differences (K1 minus K6) at 90 seconds. The objective equals completion plus customer "
        "and depot holding. Stock is total customer inventory in unit-periods. Deliveries sum the period vehicle loads in units.",
        "lrrrrrr", r"Condition & Objective & Completion & Cust. hold & Depot hold & Stock & Deliveries", decomposition))
    print("Verified robustness and sensitivity summaries and rebuilt four LaTeX tables.")


if __name__ == "__main__":
    main()
