"""Rebuild server displays from the bundled reference summaries."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import random
from statistics import median

from latex_tables import table, write


BASE = Path(__file__).resolve().parent
OUT = BASE / "display/main-comparisons"
EVIDENCE = BASE / "evidence/main-comparisons"
RUNS = {
    "cold": "confirmation-120-20261109T150546Z",
    "coordination": "coordination-90-20261110T005733Z",
}
CONTRASTS = {
    "cold": (("A+", "J"), ("A+", "G"), ("G", "J")),
    "coordination": (("K1", "K6"),),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(kind):
    root = EVIDENCE / RUNS[kind]
    a, plan, result, runtime = ((root / name).read_bytes() for name in
                                ("analysis.json", "plan.json", "results.json", "runtime_observed.json"))
    analysis, lock, raw = map(json.loads, (a, plan, result))
    require(analysis["raw_results_sha256"] == sha(result)
            and lock["runtime_record_sha256"] == sha(runtime), "Results or runtime digest changed")
    canonical = json.dumps({k: v for k, v in lock.items() if k != "plan_sha256"},
                           sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    require(analysis["plan_sha256"] == raw["plan_sha256"] == lock["plan_sha256"] == sha(canonical),
            "Plan digest changed")
    if kind == "coordination":
        require(sha((root / "execution_freeze.json").read_bytes())
                == raw["external_timestamp_verification"]["manifest_sha256"], "Coordination freeze changed")
    count = 120 if kind == "cold" else 80
    require(analysis["status"] == "N50_FULL_PIPELINE_PHYSICAL_REPLAY_PASS" and raw["status"] == "COMPLETED"
            and len(analysis["rows"]) == analysis["endpoint_cells"] == len(lock["cells"]) == count,
            "Incomplete server cohort")
    require([r["cell_id"] for r in raw["row_index"]] == [r["cell_id"] for r in lock["cells"]],
            "Indexed assignment order changed")
    rows = analysis["rows"]
    require(all((r["cell_id"], r["input"], r["arm"]) == (c["cell_id"], c["input"], c["arm"])
                and r["clean_resource_timing"] and r["worker_exit_code"] == 0
                for r, c in zip(rows, lock["cells"], strict=True)), "Coverage or resource status changed")
    require(len(analysis["pairs"]) == len({r["input"] for r in analysis["pairs"]}) == 40,
            "Incomplete file pairs")
    costs = {(r["input"], r["arm"]): r["final"] for r in rows}
    require(all(r["C0_exact"] == lock["warm_starts"][r["input"]]["point"]["exact_feasible_objective"]
                and all(float(Fraction(v)) == costs[r["input"], arm] for arm, v in r["costs_exact"].items())
                for r in analysis["pairs"]), "Pair costs differ from retained endpoints")
    return analysis


def gain(row, comparator, method):
    return Fraction(row["costs_exact"][comparator]) - Fraction(row["costs_exact"][method])


def pp(row, comparator, method):
    return 100 * gain(row, comparator, method) / Fraction(row["C0_exact"])


def contrast(analysis, comparator, method):
    def wtl(values):
        return [sum(v > 0 for v in values), sum(v == 0 for v in values), sum(v < 0 for v in values)]

    groups = {}
    pairs = analysis["pairs"]
    for row in pairs:
        groups.setdefault(row["family"], []).append(pp(row, comparator, method))
    require(len(groups) == 10 and all(len(g) == 4 for g in groups.values()), "Family balance changed")
    family = [sum(g) / len(g) for g in groups.values()]
    rng = random.Random(20261229)
    draws = sorted(sum(rng.choices(family, k=len(family))) / len(family) for _ in range(10000))
    observed = analysis["family_contrasts"][f"{method}_vs_{comparator}"]
    require(float(sum(family) / len(family)) == observed["mean_family_pp"]
            and float(median(family)) == observed["median_family_pp"]
            and [float(draws[i]) for i in (249, 9749)] == observed["bootstrap_95_percentile_pp"]
            and wtl([gain(row, comparator, method) for row in pairs]) == observed["file_w_t_l"]
            and wtl(family) == observed["family_w_t_l"], "Contrast recomputation differs")
    return observed


def longtable(label, caption, headers, rows):
    header = " & ".join(headers) + r"\\"
    return "\n".join([
        r"\begingroup\small\setlength{\tabcolsep}{4pt}",
        r"\begin{longtable}{" + "r" * len(headers) + "}",
        r"\caption{" + caption + r"}\label{" + label + r"}\\",
        r"\toprule", header, r"\midrule", r"\endfirsthead",
        r"\toprule", header, r"\midrule", r"\endhead",
        r"\bottomrule", r"\endfoot",
        *(" & ".join(map(str, row)) + r"\\" for row in rows),
        r"\end{longtable}", r"\endgroup",
    ])


def number(value):
    return f"{float(Fraction(value)):,.2f}"


def build():
    OUT.mkdir(exist_ok=True)
    analyses = {kind: read(kind) for kind in RUNS}
    summaries = []
    labels = {"cold": "Full workflow", "coordination": "Fixed handoff"}
    for kind, analysis in analyses.items():
        for comparator, method in CONTRASTS[kind]:
            result = contrast(analysis, comparator, method)
            lo, hi = result["bootstrap_95_percentile_pp"]
            summaries.append((labels[kind], f"{method} over {comparator}", f"{result['mean_family_pp']:.3f}",
                              f"[{lo:.3f}, {hi:.3f}]", "/".join(map(str, result["file_w_t_l"]))))
        arms = ("A+", "G", "J") if kind == "cold" else ("K1", "K6")
        headers = ["Family", "$n$", "$H$", "$M$", "Reference", *arms,
                   *(f"{method}/{comp}" for comp, method in CONTRASTS[kind])]
        files = sorted(analysis["pairs"], key=lambda r: (r["family"], r["n"], r["H"]))
        rows = [(row["family"][-2:], row["n"], row["H"], row["M"], number(row["C0_exact"]),
                 *(number(row["costs_exact"][arm]) for arm in arms),
                 *(f"{float(pp(row, comp, method)):+.3f}" for comp, method in CONTRASTS[kind]))
                for row in files]
        write(OUT / f"{kind}_files.tex", longtable(f"tab:v18-{kind}-files",
              f"{labels[kind]} endpoints and paired gains in percentage points.", headers, rows))
    write(OUT / "contrasts.tex", table("tab:v18-server-contrasts",
          "Server comparisons. Gains are in percentage points of the study-specific reference cost.",
          "llrrr", "Study & Contrast & Mean gain & 95\\% interval & File W/T/L", summaries))
    rows = []
    for case in analyses["coordination"]["pairs"]:
        for record in case["strict_joint_witnesses"]:
            move = record["joint"]
            initial, final = map(Fraction, (move["start_exact"], move["candidate_exact"]))
            singletons = record["singleton_certificates"]
            require({r["block"][0] for r in singletons} == set(range(case["n"]))
                    and len(singletons) == case["n"] and initial > final
                    and all(Fraction(r["candidate_exact"]) == Fraction(r["start_exact"]) == initial for r in singletons),
                    "Witness coverage or costs differ")
            rows.append((case["family"][-2:], case["n"], case["H"], case["M"], number(initial),
                         number(final), number(initial - final)))
    require(len(rows) == analyses["coordination"]["strict_joint_witness_files"] == 7, "Witness count changed")
    write(OUT / "witnesses.tex", table("tab:v18-witnesses",
          "Matched-state strict joint improvements after certification of all singleton neighbourhoods.",
          "rrrrrrr", "Family & $n$ & $H$ & $M$ & State cost & Joint candidate & Gain", sorted(rows)))
    print("Server display and evidence checks passed for 120 cold cells, 80 block-width cells, and seven witnesses.")


if __name__ == "__main__":
    build()
