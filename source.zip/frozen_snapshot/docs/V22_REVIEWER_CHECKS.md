# V22 reproducibility checks

Use Python 3.11–3.13 and OpenSSL. Install the pinned Python packages from
`code/research_artifacts/tdirp_v17/requirements.txt` in a fresh environment.
From the code root, run the tests for profile reconstruction, small
inventory masters, numerical certificates, deadlines, and retention.

```sh
python -m pip install -r code/research_artifacts/tdirp_v17/requirements.txt
python -B -m unittest discover -s code/tests -p test_v11_fifo_control.py -v
```

The V22 LaTeX source bundle has the pinned summaries and table build
instructions. Its `build_v19_displays.py` verifies the robustness and
sensitivity records and regenerates the tables. The portable probe ZIP
provides the original confirmation receipts and endpoint evidence.

```sh
python -B code/reviewer_probe_evidence.py verify tdirp-v22-probe-evidence.zip
```

Verification uses OpenSSL to check the timestamp response against both
the original query and the literal freeze manifest. It checks each included
frozen file, the local source against the manifest, and the 120 probe ZIPs
against the published report at commit `7d79b471`. It then replays the
retained K1 handoff, singleton certificates, joint candidates, and the
original resource and deadline gates. The four original runtime binaries
are excluded from redistribution. The compact handoff receipts bind the
retained endpoints to the original K1 run. Auditing the full original
K1 search trajectories also requires the original K1 evidence ZIPs.

## Export from the original server

Run this in the checkout and environment used for the confirmation. The
export first verifies the original timestamp and all frozen members in place.
It then writes a portable ZIP without re-running the optimizer.

```sh
.venv/bin/python -B code/reviewer_probe_evidence.py export \
  --run code/runs/probe-confirmation-20261111T112110Z \
  --output tdirp-v22-probe-evidence.zip
```

An author can share that ZIP, the pinned code, and the LaTeX source bundle
with a reviewer. Use the links in the V22 manuscript to find the original
summary records. For full timed experiments, see the V17 protocols under
`code/research_artifacts/tdirp_v17`. A new timed run has its own operating
system, host, and runtime evidence.

The reviewer code ZIP includes the 40 selected synthetic instances and the
40 immutable handoffs used for the block-width study. The handoff files were
reconstructed from the retained plans and matched against the recorded source
file SHA-256 digests. For a fresh coordination run from the ZIP, use
`--source-run code/reference/v22/starts`. The original published benchmark
archive for the earlier experiments remains available from its cited source.
