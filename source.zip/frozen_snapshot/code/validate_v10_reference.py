"""Portable V10 evidence replay using only the Python standard library.

No optimizer, native executable, producer or analyzer is imported. Original
observations remain historical; omitted journals need original-file replay.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import gzip
import importlib.util
import itertools
import json
import math
import re
from pathlib import Path, PurePosixPath
import zipfile


def stored_sha(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()

CODE = Path(__file__).resolve().parent
FORMAT = "tdirp_v10_portable_reference_v1"
CONTRACT = "completion_c1_endholding_nowait_ML_header_v1"
ARCHIVE_SHA = "90f4b2e5705f43d1a1b2a574ea2f2ac35c443c04fedff8ebf77ac6fecb0e093c"
REQUIRED = {"frozen_plan.json", "analysis.json", "execution_audit.json",
            "selection.json", "prespecified_protocol.md", "bundle.json",
            "native_build.json", "source_closure.json", "raw_coverage.json"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def loads(payload):
    def invalid(value):
        raise ValueError("Nonfinite JSON constant: " + value)
    return json.loads(payload, object_pairs_hook=_pairs, parse_constant=invalid)


def content_path(path):
    path = Path(path)
    if not path.is_file() and Path(str(path)+".gz").is_file():
        path = Path(str(path)+".gz")
    return path


def open_content(path, text=False):
    path = content_path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    return opener(path, "rt" if text else "rb", **({"encoding": "utf-8", "newline": ""} if text else {}))


def load(path):
    with open_content(path) as source:
        return loads(source.read())


def content_stats(path):
    checksum, size = hashlib.sha256(), 0
    with open_content(path) as source:
        while True:
            part = source.read(1024*1024)
            if not part:
                break
            checksum.update(part)
            size += len(part)
    return checksum.hexdigest(), size


def sha(path):
    return content_stats(path)[0]


class _JsonStream:
    structural = re.compile(r'[\[\]{}"]')
    string_special = re.compile(r'["\\]')
    primitive_end = re.compile(r'[\s,\]}]')
    def __init__(self, stream):
        self.stream, self.buffer, self.pos, self.eof = stream, "", 0, False
        self.decoder = json.JSONDecoder(object_pairs_hook=_pairs,
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON constant: "+value)))

    def fill(self):
        self.buffer = self.buffer[self.pos:]
        self.pos = 0
        part = self.stream.read(65536)
        self.eof = not part
        self.buffer += part

    def peek(self):
        while True:
            while self.pos < len(self.buffer) and self.buffer[self.pos].isspace():
                self.pos += 1
            if self.pos < len(self.buffer):
                return self.buffer[self.pos]
            require(not self.eof, "Truncated streamed JSON")
            self.fill()

    def take(self, char):
        require(self.peek() == char, "Malformed streamed JSON punctuation")
        self.pos += 1

    def value(self):
        first = self.peek()
        mode = "compound" if first in "[{" else "string" if first == '"' else "primitive"
        stack = [first] if mode == "compound" else []
        in_string, escaped = mode == "string", False
        cursor = self.pos + (mode != "primitive")
        fragments = []
        # Decode once at a complete lexical boundary. Retrying raw_decode on
        # growing partial multi-megabyte rows was quadratic in row length.
        while True:
            if cursor >= len(self.buffer):
                fragments.append(self.buffer[self.pos:])
                self.pos = len(self.buffer)
                if self.eof:
                    require(mode == "primitive", "Truncated streamed JSON value")
                    break
                self.fill()
                cursor = self.pos
                continue
            if escaped:
                cursor += 1
                escaped = False
                continue
            if in_string:
                match = self.string_special.search(self.buffer, cursor)
                if match is None:
                    cursor = len(self.buffer)
                    continue
                cursor = match.end()
                if match.group() == "\\":
                    escaped = True
                else:
                    in_string = False
                    if mode == "string":
                        break
                continue
            if mode == "compound":
                match = self.structural.search(self.buffer, cursor)
                if match is None:
                    cursor = len(self.buffer)
                    continue
                token, cursor = match.group(), match.end()
                if token == '"':
                    in_string = True
                elif token in "[{":
                    stack.append(token)
                else:
                    require(stack and stack.pop() == {"}": "{", "]": "["}[token],
                            "Mismatched streamed JSON brackets")
                    if not stack:
                        break
            else:
                match = self.primitive_end.search(self.buffer, cursor)
                if match is None:
                    cursor = len(self.buffer)
                    continue
                cursor = match.start()
                break
        fragments.append(self.buffer[self.pos:cursor])
        self.pos = cursor
        payload = "".join(fragments)
        try:
            value, end = self.decoder.raw_decode(payload)
        except json.JSONDecodeError as error:
            raise ValueError("Malformed streamed JSON value") from error
        require(end == len(payload), "Trailing data in streamed JSON value")
        return value


def stream_items(path):
    """Yield top-level fields and rows one at a time; no full aggregate allocation."""
    with open_content(path, text=True) as source:
        parser = _JsonStream(source)
        parser.take("{")
        seen = set()
        while parser.peek() != "}":
            key = parser.value()
            require(isinstance(key, str) and key not in seen, "Duplicate/nonstring streamed root key")
            seen.add(key)
            parser.take(":")
            if key == "rows":
                yield "rows_begin", key, None
                parser.take("[")
                while parser.peek() != "]":
                    yield "row", key, parser.value()
                    if parser.peek() != "]":
                        parser.take(",")
                        require(parser.peek() != "]", "Trailing streamed array comma")
                parser.take("]")
            else:
                yield "field", key, parser.value()
            if parser.peek() != "}":
                parser.take(",")
                require(parser.peek() != "}", "Trailing streamed object comma")
        parser.take("}")
        remainder = parser.buffer[parser.pos:] + source.read()
        require(not remainder.strip(), "Trailing data after streamed JSON object")


def metadata(path, row_fields=None):
    result, count, order = {}, 0, []
    for kind, key, value in stream_items(path):
        if kind == "rows_begin":
            order.append(key)
            result[key] = [] if row_fields is not None else None
        elif kind == "row":
            require(isinstance(value, dict), "Nonobject aggregate row")
            count += 1
            if row_fields is not None:
                result[key].append({k: value[k] for k in row_fields if k in value})
        else:
            order.append(key)
            result[key] = value
    return result, count, order


def stream_rows(path):
    for kind, key, value in stream_items(path):
        if kind == "row":
            yield value



def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def close(left, right):
    return finite(left) and finite(right) and abs(left-right) <= 1e-7


def physical(point):
    return {key: point[key] for key in ("routes", "quantities")}


def safe_path(root, relative):
    require(isinstance(relative, str) and relative and "\\" not in relative and ":" not in relative,
            "Nonportable relative path")
    parts = PurePosixPath(relative)
    require(not parts.is_absolute() and not set(parts.parts) & {".", ".."}, "Unsafe relative path")
    root = Path(root).resolve()
    target = (root / relative).resolve()
    require(target.is_relative_to(root), "Evidence path escapes reference")
    return target


def indexed(rows, fields, label):
    require(isinstance(rows, list), label + " must be a list")
    result = {tuple(row[k] for k in fields): row for row in rows}
    require(len(result) == len(rows), "Duplicate " + label)
    return result


def verify_manifest(reference, code=CODE):
    reference, code = Path(reference).resolve(), Path(code).resolve()
    manifest = load(reference / "manifest.json")
    require(manifest.get("format") == FORMAT and REQUIRED == set(manifest["logical_files"])
            and set(manifest["logical_files"].values()) <= set(manifest["files"]),
            "Wrong/incomplete reference manifest")
    actual = {p.relative_to(reference).as_posix() for p in reference.rglob("*") if p.is_file()}
    require(actual == set(manifest["files"]) | {"manifest.json"}, "Unlisted or missing reference files")
    for relative, entry in manifest["files"].items():
        path = safe_path(reference, relative)
        require((path.suffix in {".json", ".md"} or path.name.endswith(".json.gz")) and path.is_file(),
                "Disallowed reference member")
        require(path.stat().st_size == entry["bytes"] and entry["bytes"] < 99_000_000
                and stored_sha(path) == entry["sha256"],
                "Stored reference bytes changed: " + relative)
        require(entry["encoding"] == ("gzip" if path.suffix == ".gz" else "identity")
                and content_stats(path) == (entry["content_sha256"], entry["content_bytes"]),
                "Uncompressed original reference bytes changed: " + relative)
    require(set(manifest["verification_tools"]) == {"validate_v10_reference.py", "export_v10_reference.py"},
            "Unbound verification tooling")
    for relative, checksum in manifest["verification_tools"].items():
        require(sha(safe_path(code, relative)) == checksum, "Verification tool drift: " + relative)
    return manifest


def parse_instance(payload):
    """Integral physical data and exact decimal holding rates from original bytes."""
    rows = [line.split() for line in payload.decode("utf-8-sig").splitlines() if line.strip()]
    def integer(text):
        value = Fraction(text)
        require(value.denominator == 1 and value >= 0, "Nonintegral/negative physical input")
        return int(value)
    nodes, H, Q, M, step, deadline = map(integer, rows[0])
    require(nodes >= 2 and min(H, Q, M, step) > 0, "Invalid benchmark dimensions")
    n = nodes - 1
    require(len(rows) == 1 + 1 + n + nodes*nodes, "Wrong instance row count")
    require(len(rows[1]) == H+3 and all(len(r) == H+6 for r in rows[2:nodes+1]),
            "Wrong inventory-data width")
    supplier = rows[1]
    clients = rows[2:nodes+1]
    travel = [[integer(t) for t in r] for r in rows[nodes+1:]]
    require(all(len(r) == M for r in travel), "Wrong traffic-bin width")
    holding = [Fraction(supplier[-1])] + [Fraction(r[-2]) for r in clients]
    require(all(h >= 0 for h in holding), "Negative holding rate")
    instance = {"n": n, "H": H, "nodes": nodes, "Q": Q, "M": M, "step": step,
                "deadline": deadline, "supplier_initial": integer(supplier[1]),
                "production": [integer(t) for t in supplier[2:2+H]],
                "initial": [integer(r[1]) for r in clients],
                "maximum": [integer(r[2]) for r in clients],
                "minimum": [integer(r[3]) for r in clients],
                "demand": [[integer(r[4+p]) for r in clients] for p in range(H)],
                "service": [integer(r[-1]) for r in clients], "holding": holding, "travel": travel}
    require(all(lo <= hi for lo, hi in zip(instance["minimum"], instance["maximum"])),
            "Invalid customer stock bounds")
    return instance


def arrival(i, u, v, departure):
    """Literal active-ramp FIFO transform, with no independently chosen waiting."""
    if u == v:
        return departure
    m = departure // i["step"]
    require(0 <= m < i["M"], "Departure outside traffic domain")
    raw = i["travel"][u*i["nodes"]+v]
    value = departure + raw[m]
    for r in range(1, i["M"]):
        if raw[r-1] > raw[r] and departure < r*i["step"]:
            value = min(value, r*i["step"]+raw[r])
    return value


def verify_physical(instance, point):
    """Exact stock/load/cutoff inequalities; original 1e-6 delivery recovery only."""
    i = instance
    routes, q = point["routes"], point["quantities"]
    require(isinstance(routes, list) and isinstance(q, list)
            and len(routes) == len(q) == i["H"], "Incomplete physical horizon")
    stock, supplier = list(i["initial"]), i["supplier_initial"]
    holding, returns, moving, recovered = Fraction(0), [], [], []
    for p, route in enumerate(routes):
        require(isinstance(route, list) and all(type(k) is int and 0 <= k < i["n"] for k in route)
                and len(set(route)) == len(route), "Invalid elementary route")
        require(isinstance(q[p], list) and len(q[p]) == i["n"], "Wrong quantity width")
        require(all(finite(v) and abs(v-round(v)) <= 1e-6 for v in q[p]), "Nonintegral/nonfinite delivery")
        quantities = [int(round(v)) for v in q[p]]
        require(all(v >= 0 for v in quantities) and sum(quantities) <= i["Q"]
                and all(not v or k in route for k, v in enumerate(quantities)), "Load or visit violation")
        require(all(s+v <= maximum for s, v, maximum in zip(stock, quantities, i["maximum"])),
                "Maximum-level pre-demand storage violation")
        stock = [s+v-d for s, v, d in zip(stock, quantities, i["demand"][p])]
        supplier += i["production"][p] - sum(quantities)
        require(supplier >= 0 and all(s >= lo for s, lo in zip(stock, i["minimum"])),
                "Supplier/customer inventory violation")
        now, previous, travel = 0, 0, 0
        for k in route:
            reached = arrival(i, previous, k+1, now)
            travel += reached-now
            now, previous = reached+i["service"][k], k+1
        returned = arrival(i, previous, 0, now) if route else 0
        if route:
            travel += returned-now
        require(returned <= i["deadline"], "Return cutoff violation")
        returns.append(returned)
        moving.append(travel)
        recovered.append(quantities)
        holding += i["holding"][0]*supplier + sum(h*s for h, s in zip(i["holding"][1:], stock))
    value = holding + sum(returns)
    for field in ("objective", "objective_decimal"):
        if field in point:
            require(close(point[field], float(value)), "Literal objective differs: " + field)
    if "exact_feasible_objective" in point:
        require(Fraction(point["exact_feasible_objective"]) == value, "Exact physical cost differs")
    return {"checked": True, "exact_feasible_objective": str(value), "objective_decimal": float(value),
            "routes": routes, "quantities": recovered, "return_times": returns,
            "travel_times": moving, "holding_cost": str(holding)}


def _auditor(code, checksum):
    path = safe_path(code, "research_artifacts/tdirp_v10/audit_run.py")
    require(sha(path) == checksum, "Independent auditor source drift")
    spec = importlib.util.spec_from_file_location("_portable_v10_auditor_checks", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # This module's imports and pure checks are standard-library only.
    return module


def check_sources(code, reference, plan, closure, native, analysis, audit):
    source = plan["source_hashes"]
    require(closure["runtime_files"] == source == analysis["source_hashes"], "Runtime closure mismatch")
    binaries = {k: v for k, v in source.items() if k.endswith(".exe")}
    builds = {k: v for k, v in source.items() if k.endswith(".build.json")}
    require(len(binaries) == len(builds) == 1 and closure["omitted_native_binaries"] == binaries,
            "Unexpected native binary/build closure")
    build = next(iter(builds))
    require(closure["native_build_source_relative"] == build
            and sha(reference/"native_build.json") == builds[build], "Whole native build record drift")
    binary = build.removesuffix(".build.json") + ".exe"
    require(binary in binaries and native["executable_sha256"] == binaries[binary]
            and native["source_sha256"] == source["research_artifacts/tdirp_v9/fifo_tsp.cpp"],
            "Native build/source/binary identity mismatch")
    portable = {k: v for k, v in source.items() if k not in binaries and k not in builds}
    require(closure["portable_source_files"] == portable, "Portable runtime closure incomplete")
    for required in ("execution.py", "pilot.py", "selection.py", "hybrid.py"):
        require("research_artifacts/tdirp_v10/"+required in portable, "Missing frozen V10 runtime file")
    for relative, checksum in portable.items():
        require(sha(safe_path(code, relative)) == checksum, "Current computational source drift: "+relative)
    require(closure["auditor_sha256"] == audit["auditor_sha256"]
            and closure["analyzer_sha256"] == analysis["analyzer_sha256"], "Postprocessor source binding")
    require(sha(safe_path(code, "research_artifacts/tdirp_v10/analyze.py")) == analysis["analyzer_sha256"],
            "Current analysis source drift")


def selected_point(row, start, publications):
    """Select a retained physical endpoint; preserve the no-publication C0 fallback."""
    require(type(row.get("endpoint_eligible")) is bool
            and type(row.get("fallback_to_common_start")) is bool
            and isinstance(row.get("result"), dict), "Malformed endpoint availability flags")
    if row["endpoint_eligible"]:
        key = row["worker_checkpoint_file"]
        require(row["fallback_to_common_start"] is False and key in publications,
                "Selected publication not retained")
        point, receipt = publications[key]
        require(point == row["result"] and receipt == row["checkpoint_receipt"],
                "Original selected bytes differ")
        best = min(publications, key=lambda k: (publications[k][0]["objective"],
                                               -publications[k][0]["publication_sequence"]))
        require(best == key, "Selected endpoint worse/earlier than retained support")
        return point
    require(row["fallback_to_common_start"] is True and not row["result"] and not publications,
            "No-publication common-start fallback differs")
    return start


def reconstruct_raw(bundle, read):
    """Rebuild the byte-identical aggregate from retained original worker records."""
    rows = []
    for item in bundle["cells"]:
        cell = item["cell"]
        if item["worker_record"] is None:
            row = dict(item["unavailable_row"])
        else:
            row = dict(read(item["worker_record"]))
            row["worker_attempted"] = True
            row.update(cell)
        rows.append(row)
    raw = {key: rows if key == "rows" else value for key, value in bundle["raw_root_fields"]}
    require(len(raw) == len(bundle["raw_root_fields"]) and "rows" in raw, "Duplicate/missing raw root key")
    style = bundle["raw_serialization"]
    require(style["newline"] in ("\n", "\r\n") and type(style["trailing_newline"]) is bool,
            "Unknown original serialization")
    encoded = json.dumps(raw, indent=2, allow_nan=False)
    if style["trailing_newline"]:
        encoded += "\n"
    encoded = encoded.replace("\n", style["newline"]).encode("utf-8")
    return raw, encoded


def iter_raw_rows(bundle, read):
    for item in bundle["cells"]:
        if item["worker_record"] is None:
            yield dict(item["unavailable_row"])
        else:
            row = dict(read(item["worker_record"]))
            row["worker_attempted"] = True
            row.update(item["cell"])
            yield row


def reconstructed_raw_digest(bundle, read):
    """Hash canonical original aggregate layout while retaining only one worker row."""
    checksum = hashlib.sha256()
    style = bundle["raw_serialization"]
    require(style["newline"] in ("\n", "\r\n") and type(style["trailing_newline"]) is bool,
            "Unknown original serialization")
    def feed(text):
        checksum.update(text.replace("\n", style["newline"]).encode("utf-8"))
    feed("{")
    count = 0
    root_fields = bundle["raw_root_fields"]
    require(len({k for k, value in root_fields}) == len(root_fields)
            and sum(k == "rows" for k, value in root_fields) == 1, "Invalid original root fields")
    for index, (key, value) in enumerate(root_fields):
        feed(("" if index == 0 else ",")+"\n  "+json.dumps(key)+": ")
        if key == "rows":
            feed("[")
            for row in iter_raw_rows(bundle, read):
                feed(("" if count == 0 else ",")+"\n    "+
                     json.dumps(row, indent=2, allow_nan=False).replace("\n", "\n    "))
                count += 1
            feed("\n  ]" if count else "]")
        else:
            feed(json.dumps(value, indent=2, allow_nan=False).replace("\n", "\n  "))
    feed("\n}"+("\n" if style["trailing_newline"] else ""))
    return checksum.hexdigest(), count


ANALYSIS_FIELDS = ("cell_id", "stage", "input", "start_kind", "seed", "method", "budget_seconds",
                   "feasible_endpoint_available", "objective", "eligible_publication",
                   "fallback_to_common_start", "initial_objective", "gain_pp_C0")


def check_continuation_entry(arm, tail, parent, deadline, handoff_verified_at, reason, counters):
    """Standalone B enters without a prefix; hybrid entry needs its handoff."""
    require(arm in "ABCDEF", "Unknown continuation arm")
    if arm in "AB":
        require(handoff_verified_at is None, "Standalone arm has a foreign handoff")
    if tail is None:
        return
    require(finite(tail) and parent <= tail, "Invalid continuation clock")
    require(arm != "A", "Two-stage-only arm cannot enter a continuation")
    if arm != "B":
        require(finite(handoff_verified_at) and parent <= handoff_verified_at <= tail
                and handoff_verified_at < deadline, "Continuation lacks own timely immutable handoff")
    if tail >= deadline:
        require(reason == "continuation_setup_exhausted_time"
                and counters.get("repair_attempts") == counters.get("polish_calls") == 0,
                "Search continued after setup exhausted deadline")


def validate(reference, archive, code=CODE):
    reference, code = Path(reference).resolve(), Path(code).resolve()
    manifest = verify_manifest(reference, code)
    def stored(relative):
        relative = manifest["logical_files"].get(relative, relative)
        require(relative in manifest["files"], "Unmanifested evidence reference")
        return safe_path(reference, relative)
    def read(relative):
        return load(stored(relative))
    plan, audit = read("frozen_plan.json"), read("execution_audit.json")
    analysis, analysis_count, _ = metadata(stored("analysis.json"), ANALYSIS_FIELDS)
    require(analysis_count == 600, "Incomplete streamed analysis rows")
    selection, bundle, closure = (read(n) for n in ("selection.json", "bundle.json", "source_closure.json"))
    native, coverage = read("native_build.json"), read("raw_coverage.json")
    require(plan["engineering_only"] is False and plan["planned_calls"] == 600
            and plan["status"] == "FROZEN_BEFORE_FIRST_SEARCH"
            and analysis["status"] == audit["status"] == "PASS"
            and analysis["engineering_only"] is False
            and analysis["accounted_calls"] == audit["accounted_calls"] == 600,
            "Only completed600 scientific evidence is accepted")
    require(sha(reference/"frozen_plan.json") == audit["frozen_plan_sha256"]
            and sha(reference/"analysis.json") == audit["analysis_sha256"]
            and sha(reference/"selection.json") == audit["selection_sha256"] == plan["selection_sha256"]
            and sha(reference/"prespecified_protocol.md") == plan["protocol_sha256"], "Audit/plan/selection/protocol binding")
    check_sources(code, reference, plan, closure, native, analysis, audit)
    helper = _auditor(code, audit["auditor_sha256"])
    planned = helper.check_grid({**plan, "_selection": selection})
    unsigned = dict(selection)
    selection_hash = unsigned.pop("selection_content_sha256")
    require(digest(unsigned) == selection_hash and selection["input_sha256"] == plan["input_sha256"],
            "Selection proof digest mismatch")
    require(set(selection["cases"]) == set(plan["input_sha256"])
            and not set(selection["cases"]) & set(selection["prior_usage_registry"]["family_closed_exclusions"]),
            "Held-out input proof mismatch")
    require(sha(archive) == ARCHIVE_SHA == plan["archive_sha256"], "Wrong benchmark archive bytes")
    instances = {}
    with zipfile.ZipFile(archive) as zipped:
        for case, checksum in plan["input_sha256"].items():
            payload = zipped.read(case)
            require(hashlib.sha256(payload).hexdigest() == checksum, "Input byte mismatch: "+case)
            instances[case] = parse_instance(payload)
    cache = {}
    def verify(case, point):
        signature = (case, digest(physical(point)))
        if signature not in cache:
            cache[signature] = verify_physical(instances[case], point)
        checked = cache[signature]
        for field in ("objective", "objective_decimal"):
            if field in point:
                require(close(point[field], checked["objective_decimal"]), "Cached literal objective mismatch")
        if "exact_feasible_objective" in point:
            require(Fraction(point["exact_feasible_objective"]) == Fraction(checked["exact_feasible_objective"]),
                    "Cached exact objective mismatch")
        return checked
    declarations = indexed(plan["initialization"], ("input", "kind"), "declared initial")
    initials = indexed(bundle["initials"], ("input", "kind"), "retained initial")
    require(len(declarations) == len(initials) == 32 and declarations.keys() == initials.keys()
            == set(itertools.product(plan["input_sha256"], ("original", "consolidation"))), "32-start coverage")
    starts = {}
    for key, item in initials.items():
        declared = declarations[key]
        require(read(item["execution_record"]) == declared, "Original initializer execution record differs")
        require(item["success"] is declared["success"], "Initializer availability changed")
        if not item["success"]:
            if item["payload"] is not None:
                read(item["payload"])
            continue
        require(item["payload"] is not None and sha(safe_path(reference, item["payload"])) == declared["payload_sha256"],
                "Initial payload bytes differ")
        point = read(item["payload"])
        require(point["input"] == key[0] and point["success"] is True and point["contract"] == CONTRACT
                and point["objective_definition"] == "completion" and point["input_sha256"] == plan["input_sha256"][key[0]],
                "Initial operational/input identity differs")
        checked = verify(key[0], point)
        expected = digest({"input": key[0], "input_sha256": point["input_sha256"], "contract": CONTRACT,
                           "objective": "completion", "routes": checked["routes"], "quantities": checked["quantities"]})
        require(point["plan_sha256"] == expected, "Initial canonical plan hash differs")
        starts[key] = point
    items = indexed(bundle["cells"], ("cell_id",), "retained cell")
    analyzed = indexed(analysis["rows"], ("cell_id",), "analysis cell")
    require(len(items) == len(analyzed) == 600 and items.keys() == analyzed.keys() == {(k,) for k in planned},
            "Complete600 retained cell coverage")
    raw_sha, raw_count = reconstructed_raw_digest(bundle, read)
    raw = dict(bundle["raw_root_fields"])
    require(raw["status"] == "COMPLETED" and raw["planned_calls"] == raw_count == 600
            and raw_sha == audit["results_sha256"] == coverage["original_results_sha256"],
            "Original raw aggregate cannot be byte-reconstructed")
    require(analysis["input_digests"] == {"frozen_plan.json": sha(reference/"frozen_plan.json"),
            "results.json": raw_sha, "selection.json": sha(reference/"selection.json"),
            "prespecified_protocol.md": sha(reference/"prespecified_protocol.md")}, "Analysis raw-byte inputs differ")
    require(coverage["execution_audit_sha256"] == sha(reference/"execution_audit.json")
            and coverage["full_journal_receipt_pairs_audited"] == audit["original_receipt_pairs_checked"]
            and coverage["full_journal_handoffs_audited"] == audit["original_handoffs_checked"],
            "Omitted-journal audit coverage unbound")
    journal_index = indexed(coverage["journal_index"], ("cell_id", "original_file"), "journal coverage")
    require(len(journal_index) == coverage["all_original_observation_pairs_indexed"]
            and len(journal_index) >= coverage["full_journal_receipt_pairs_audited"], "Journal coverage denominator differs")
    observed_keys = set()
    endpoints, handoffs, supports, available = 0, 0, 0, 0
    for row in iter_raw_rows(bundle, read):
        identifier = row["cell_id"]
        cell, item, reported = planned[identifier], items[(identifier,)], analyzed[(identifier,)]
        require(item["cell"] == cell and all(row.get(k) == v == reported.get(k) for k, v in cell.items()),
                "Retained cell protocol identity differs")
        key = cell["input"], cell["start_kind"]
        if key not in starts:
            require(row.get("worker_attempted") is False and row["endpoint_eligible"] is False
                    and row["endpoint_objective"] is None and row["fallback_to_common_start"] is False
                    and row["failure"] == "unavailable_declared_initializer"
                    and item["endpoint"] is None and not item["publications"] and not item["handoffs"]
                    and reported["feasible_endpoint_available"] is False and reported["objective"] is None,
                    "Unavailable initializer was silently replaced")
            continue
        available += 1
        start = starts[key]
        pairs = item["source_path_map"]
        original_sources = {p["original_path"]: p["sha256"] for p in pairs}
        relative_sources = {p["relative"]: p["sha256"] for p in pairs}
        require(len(pairs) == len(original_sources) == len(relative_sources)
                and relative_sources == plan["source_hashes"] and original_sources == row["source_hashes"],
                "Original worker source-map closure differs")
        budget, parent = cell["budget_seconds"], row["parent_start_perf_counter"]
        deadline = parent+budget-plan["reserve_seconds"]
        require(row["run_id"] == identifier and finite(parent)
                and close(row["absolute_search_deadline_perf_counter"], deadline)
                and close(row["absolute_parent_deadline_perf_counter"], parent+budget)
                and close(row["wall_budget_seconds"], budget) and row["finalization_reserve_seconds"] == 3.,
                "Original parent budget identity differs")
        identity = {"input": cell["input"], "method": cell["method"], "seed": cell["seed"], "run_id": identifier,
                    "attempt_id": row["attempt_id"], "initial_plan_sha256": start["plan_sha256"],
                    "expected_initial_sha256": start["plan_sha256"],
                    "initial_payload_sha256": declarations[key]["payload_sha256"],
                    "source_hashes": original_sources, "initial_identity_checked": True}
        observations = indexed(row["checkpoint_audit"], ("file",), "checkpoint observation")
        retained_names = {p["original_file"] for p in item["publications"]}
        for (original,), observation in observations.items():
            journal_key = (identifier, original)
            require(journal_key in journal_index, "Original observation omitted from compact journal coverage")
            observed_keys.add(journal_key)
            proof = journal_index[journal_key]
            require(proof["observed_elapsed_seconds"] == observation.get("observed_elapsed_seconds")
                    and proof["rejections"] == observation["rejections"]
                    and proof["original_bytes_retained"] is (original in retained_names), "Journal coverage metadata differs")
        publications, publication_paths = [], {}
        for retained in item["publications"]:
            payload, receipt = read(retained["payload"]), read(retained["receipt"])
            checksum = sha(safe_path(reference, retained["payload"]))
            require(retained["original_file"] not in publication_paths, "Duplicate retained publication")
            observation = observations[(retained["original_file"],)]
            rejected = helper.rejections(payload, receipt, checksum, identity, start["objective"], budget,
                                         observation.get("observed_elapsed_seconds"))
            require(not rejected and not observation["rejections"], "Retained publication is ineligible")
            require(type(payload.get("publication_sequence")) is int and payload["publication_sequence"] >= 0
                    and retained["original_file"].replace("\\", "/").rsplit("/", 1)[-1]
                    == f"checkpoint_{payload['publication_sequence']:08d}.json", "Publication sequence/name differs")
            require(finite(payload["checkpoint_verified_elapsed_since_parent"])
                    and 0 <= payload["checkpoint_verified_elapsed_since_parent"]
                    <= receipt["checkpoint_completed_elapsed_since_parent"] <= observation["observed_elapsed_seconds"],
                    "Publication verification/commit/observation order differs")
            proof = journal_index[(identifier, retained["original_file"])]
            require(proof["payload_sha256"] == checksum
                    and proof["receipt_sha256"] == sha(safe_path(reference, retained["receipt"])),
                    "Retained publication bytes differ from original-journal index")
            verify(cell["input"], payload)
            require(payload.get("global_bound") is None and payload.get("global_gap") is None
                    and payload.get("conditional_lower_bound") is None
                    and not payload.get("conditional_optimum_verified", False)
                    and not payload.get("global_routing_table_used", False), "Local/static bound promoted to global")
            publications.append(payload)
            publication_paths[retained["original_file"]] = (payload, receipt)
            supports += 1
        point = selected_point(row, start, publication_paths)
        require(physical(point) == physical(item["endpoint"]) and close(item["endpoint"]["objective"], row["endpoint_objective"]),
                "Portable endpoint differs from original selected physical plan")
        checked = verify(cell["input"], item["endpoint"])
        cost, c0 = Fraction(checked["exact_feasible_objective"]), Fraction(start["exact_feasible_objective"])
        require(cost <= c0 and close(reported["objective"], float(cost)) and reported["feasible_endpoint_available"] is True
                and reported["eligible_publication"] is row["endpoint_eligible"]
                and reported["fallback_to_common_start"] is row["fallback_to_common_start"]
                and close(reported["initial_objective"], float(c0))
                and close(reported["gain_pp_C0"], float(100*(c0-cost)/c0)), "Analyzed cost/availability or C0 denominator differs")
        endpoints += 1
        run_identity = {"parent_start_perf_counter": parent, "input": cell["input"], "arm": cell["method"],
                        "seed": cell["seed"], "attempt_id": row["attempt_id"],
                        "initial_payload_sha256": declarations[key]["payload_sha256"]}
        retained_handoffs = {}
        for member in item["handoffs"]:
            payload_path, commit_path = safe_path(reference, member["payload"]), safe_path(reference, member["receipt"])
            envelope = helper.check_handoff(payload_path, commit_path, run_identity,
                        lambda p: verify(cell["input"], p), deadline)
            require(Fraction(envelope["exact_feasible_objective"]) <= c0, "Handoff degraded common start")
            require(member["original_file"] not in retained_handoffs, "Duplicate handoff")
            retained_handoffs[member["original_file"]] = member
            handoffs += 1
        require(len(retained_handoffs) <= 1 and (cell["method"] not in "AB" or not retained_handoffs),
                "Unexpected handoff number/arm")
        for payload in publications:
            if "run_identity" not in payload:
                require(payload["status"] == "initialized" and physical(payload) == physical(start),
                        "Foreign nonhybrid initialization")
                continue
            require(payload["run_identity"] == run_identity
                    and close(payload["absolute_search_deadline_perf_counter"], deadline), "Hybrid identity/clock differs")
            provenance = payload["provenance"]
            for field, relative in (("hybrid_source_sha256", "research_artifacts/tdirp_v10/hybrid.py"),
                    ("stage_a_source_sha256", "research_artifacts/tdirp_v9/two_stage.py"),
                    ("operators_source_sha256", "research_artifacts/tdirp_v5/operators.py")):
                if provenance.get(field) is not None:
                    require(provenance[field] == plan["source_hashes"][relative], "Hybrid source provenance differs")
            require(provenance["free_prefix_reuse"] is False and provenance["reserved_continuation_fraction"] == 0.
                    and provenance["raw_publication_before_polish"] is True, "Hybrid policy differs")
            helper.check_events(payload, publications, parent, deadline, cell["method"], str(c0))
            prefix = payload.get("stage_a_report")
            helper.check_prefix(prefix, lambda p: verify(cell["input"], p))
            if prefix is not None:
                require(prefix.get("retained_origin") in {"common_start", "static_phase", "routing_phase"},
                        "Unknown prefix origin bypasses fixed-assignment check")
                if prefix["retained_origin"] == "common_start":
                    require(physical(prefix) == physical(start), "Prefix common start differs")
            handoff_metadata = payload.get("handoff")
            tail = payload.get("continuation_started_parent_perf_counter")
            if handoff_metadata is None:
                require(cell["method"] != "B" or prefix is None, "Standalone B has a two-stage prefix")
                check_continuation_entry(cell["method"], tail, parent, deadline, None,
                    payload.get("continuation_reason"), payload["counters"])
                continue
            require(handoff_metadata["path"] in retained_handoffs, "Selected handoff original payload missing")
            member = retained_handoffs[handoff_metadata["path"]]
            require(handoff_metadata["commit_path"] == member["original_receipt"], "Selected handoff receipt path differs")
            envelope = helper.check_handoff(safe_path(reference, member["payload"]),
                safe_path(reference, member["receipt"]), run_identity,
                lambda p: verify(cell["input"], p), deadline, handoff_metadata)
            require(prefix is not None and physical(prefix) == envelope["physical_plan"], "Handoff not own completed prefix")
            hcost = Fraction(envelope["exact_feasible_objective"])
            require(Fraction(payload["exact_feasible_objective"]) <= hcost <= c0,
                    "Within-call handoff nonworsening differs")
            require(handoff_metadata["verified"]["elapsed_since_parent_seconds"]
                    <= payload["checkpoint_verified_elapsed_since_parent"] + 1e-7, "Publication predates handoff verification")
            check_continuation_entry(cell["method"], tail, parent, deadline,
                handoff_metadata["verified"]["parent_perf_counter"], payload.get("continuation_reason"), payload["counters"])
            require(all(e["stage"] == "two_stage" or e["parent_perf_counter"] >= handoff_metadata["verified"]["parent_perf_counter"]
                        for e in payload["trace"]), "Continuation acceptance predates handoff")
    require(observed_keys == journal_index.keys(), "Extra or missing compact journal evidence")
    require(handoffs == audit["original_handoffs_checked"], "Not all original committed handoffs retained")
    return {"status": "PASS", "declared_cells": 600, "available_start_cells": available,
            "literal_endpoints_checked": endpoints, "successful_full_starts_checked": len(starts),
            "declared_initials": 32, "literal_handoffs_checked": handoffs,
            "retained_publications_checked": supports, "raw_aggregate_sha256": raw_sha,
            "unique_literal_plans_checked": len(cache), "optimizer_called": False,
            "native_executable_loaded_or_verified": False,
            "historical_full_journal_audit_sha256": sha(reference/"execution_audit.json"),
            "scope": "Portable byte closure, reconstructed raw aggregate, retained original receipts, literal FIFO plans, own handoffs and retained raw-acceptance support. Omitted journals require original-file replay; historical clocks/RSS are not remeasured; no global certificate or trajectory reproduction."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--reference", type=Path, default=CODE/"reference/v10")
    args = parser.parse_args()
    print(json.dumps(validate(args.reference, args.archive), indent=2))

