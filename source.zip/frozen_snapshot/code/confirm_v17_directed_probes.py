"""Confirm the V17 directed probes on their original K1 endpoints only."""

import argparse
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

from replay_v17_probe_startup import (
    cell_evidence, load_cell, runner, sensitivity_analysis, sensitivity_probe,
    warm_start_after_first_sample,
)
import timestamp


PROTOCOL = Path(__file__).with_suffix(".md").resolve()


def copy_verified_source(source, destination):
    """Keep the retained source and its receipt, omitting unrelated K1 publications."""
    destination.mkdir(parents=True)
    compact = {name: source[name] for name in (
        "cell", "identity", "clean_resource_timing", "initial", "retained",
        "retained_checkpoint_file", "budget_seconds",
    )}
    compact["phase_records"] = {"fixed_handoff": source["phase_records"]["fixed_handoff"]}
    compact["publications"] = []
    files = []
    retained_file = source["retained_checkpoint_file"]
    if retained_file is not None:
        selected = next(row for row in source["publications"] if row["file"] == retained_file)
        compact_publication = dict(selected)
        for field, name in (("file", "checkpoint.json"), ("receipt_file", "checkpoint.commit.json")):
            path = destination / name
            with cell_evidence.open_bytes(selected[field]) as file:
                path.write_bytes(file.read())
            compact_publication[field] = str(path)
            files.append(path)
        compact["retained_checkpoint_file"] = compact_publication["file"]
        compact["publications"].append(compact_publication)
    compact_path = destination / "parent_result.json"
    runner.atomic(compact_path, compact)
    return compact_path, [compact_path, *files]


def probe_roster(original, output, plan, index):
    verifier = runner.independent_verifier()
    cells = {cell["cell_id"]: cell for cell in plan["cells"]}
    if (plan["cohort"] != "sensitivity" or len(cells) != 360 or set(cells) != set(index)
            or any(row["alias_of"] is not None for row in plan["sensitivity_files"].values())):
        raise ValueError("Expected the original complete 360-cell sensitivity campaign")
    roster, files = [], []
    with ZipFile(plan["archive"]) as inputs:
        for probe in cells.values():
            if probe["arm"] != "P":
                continue
            source_cell = cells[probe["source_cell"]]
            source = load_cell(original, plan, source_cell, index)
            parent, material = copy_verified_source(source, output / "sources" / probe["cell_id"])
            instance = verifier.parse_instance(inputs.read(probe["input"]))
            endpoint = sensitivity_probe.source_endpoint(parent, plan, probe, verifier, instance)
            if endpoint != source["retained"]:
                raise ValueError("Compact handoff differs from the original retained K1 endpoint")
            roster.append({"cell": probe, "source": str(parent),
                           "source_parent_sha256": index[source_cell["cell_id"]]["sha256"],
                           "source_endpoint_sha256": runner.physical_signature(endpoint),
                           "compact_parent_sha256": runner.sha(parent)})
            files.extend(material)
    if len(roster) != 120 or len({row["cell"]["source_cell"] for row in roster}) != 120:
        raise ValueError("Expected one confirmation per original K1 endpoint")
    return roster, files


def confirmation_result(row, item, plan, verifier, instance):
    cell = item["cell"]
    metadata = plan["sensitivity_files"][cell["input"]]
    result = {"cell_id": cell["cell_id"], "family": metadata["family"], "input": metadata["base_input"],
              "treatment": metadata["treatment"], "seed": cell["seed"],
              "worker_exit_code": row["worker_exit_code"], "external_stop": row["external_stop"],
              "clean_resource_timing": row["clean_resource_timing"],
              "max_sampling_gap_seconds": row["observed_max_sampling_gap_seconds"],
              "peak_sampled_tree_rss_bytes": row["peak_sampled_tree_rss_bytes"],
              "singleton_status": "unresolved", "joint_hit": False,
              "joint_attempted": False, "joint_deadline": False}
    if row["worker_exit_code"] != 0 or row["execution_error"] or row["external_stop"]:
        return {**result, "eligibility": "worker_failure_or_stop"}
    if not row["clean_resource_timing"]:
        return {**result, "eligibility": "original_monitoring_gate_failed"}
    probe_report = row["phase_records"].get("probe")
    if probe_report is None:
        return {**result, "eligibility": "missing_timely_probe_report"}
    source = runner.load(item["source"])
    if (row["identity"]["source_result_sha256"] != item["compact_parent_sha256"]
            or row["identity"]["source_endpoint_sha256"] != item["source_endpoint_sha256"]):
        raise ValueError("Confirmation receipt is not bound to its frozen source")
    first = row["samples"][0]["elapsed_seconds"]
    before = warm_start_after_first_sample(row, source["retained"], first)
    if before is None:
        return {**result, "eligibility": "no_proof_of_sampling_before_solver"}
    status, hit, attempted, deadline = sensitivity_probe.replay(row, source, probe_report, verifier, instance)
    return {**result, "eligibility": "eligible", "first_sample_seconds": first,
            "verified_pre_solve_checkpoint_seconds": before, "singleton_status": status,
            "joint_hit": hit, "joint_attempted": attempted, "joint_deadline": deadline}


def confirm(original, output):
    plan_path = original / "plan.json"
    plan = runner.load(plan_path)
    runner.validate_plan(plan)
    runner.external_freeze(plan_path, plan, original / "execution_freeze.json", original / "receipt")
    index_path = original / "run" / "progress.json"
    output.mkdir(parents=True, exist_ok=False)
    roster, sources = probe_roster(original, output, plan, runner.load(index_path))
    roster_path = output / "confirmation_plan.json"
    runner.atomic(roster_path, {"original_plan_sha256": plan["plan_sha256"],
        "original_index_sha256": runner.sha(index_path), "assignments": roster})

    manifest, receipt = output / "execution_freeze.json", output / "receipt"
    members = {plan_path, index_path, roster_path, PROTOCOL, Path(__file__).resolve(), *sources,
               Path(__file__).with_name("replay_v17_probe_startup.py").resolve(),
               *(Path(plan[key]) for key in ("archive", "runtime_record", "protocol")),
               *(Path(path) for key in ("source_sha256", "runtime_binary_sha256") for path in plan[key])}
    timestamp.freeze(manifest, members, scope="Prospective timing confirmation of the 120 original V17 directed probes")
    print("Requesting timestamp for 120 directed probes. K1/K6 search endpoints are reused.", flush=True)
    timestamp.stamp(manifest, receipt)
    proof = runner.external_freeze(plan_path, plan, manifest, receipt)
    runner.atomic(output / "external_timestamp_verified_before_first_probe.json", proof)

    verifier = runner.independent_verifier()
    records = []
    with ZipFile(plan["archive"]) as inputs:
        for item in roster:
            cell = item["cell"]
            folder = output / "run" / "cells" / cell["cell_id"]
            row = runner.run_one(plan_path, plan, cell, folder, manifest, receipt, probe_source=Path(item["source"]))
            instance = verifier.parse_instance(inputs.read(cell["input"]))
            record = confirmation_result(row, item, plan, verifier, instance)
            record["parent_result_sha256"] = runner.sha(folder / "parent_result.json")
            record.update(cell_evidence.pack(folder))
            records.append(record)
            runner.atomic(output / "progress.json", records)
            print(f"{cell['cell_id']} {record['eligibility']} {record['singleton_status']} hit={record['joint_hit']}", flush=True)

    lookup = {sensitivity_analysis.row_key(record): record for record in records
              if record["eligibility"] == "eligible"}
    keys = [sensitivity_analysis.row_key(record) for record in records]
    summary = {treatment: sensitivity_analysis.escape_summary(
        sorted(key for key in keys if key[3] == treatment), lookup)
        for treatment in sensitivity_analysis.TREATMENTS}
    path = output / "analysis.json"
    runner.atomic(path, {"status": "PROSPECTIVE_PROBE_CONFIRMATION", "original_plan_sha256": plan["plan_sha256"],
        "confirmation_plan_sha256": runner.sha(roster_path), "freeze_manifest_sha256": proof["manifest_sha256"],
        "assigned_probes": len(roster), "eligibility_counts": dict(Counter(record["eligibility"] for record in records)),
        "directed_escape_by_treatment": summary, "probes": records})
    print(path, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path, help="Original completed sensitivity run")
    parser.add_argument("--output", required=True, type=Path, help="New confirmation output directory")
    args = parser.parse_args()
    confirm(args.source.resolve(strict=True), args.output.resolve())


if __name__ == "__main__":
    main()
