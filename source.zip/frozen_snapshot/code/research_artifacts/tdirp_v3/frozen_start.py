"""Canonical, independently verified shared starting plans for operator tests."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys,time,zipfile
import numpy as np
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent/'tdirp_newalgo'))
from schedule_repair import read_instance,FifoNetwork,verify_routes
from routing_initializer import build_initial_plan

ARCHIVE=BASE.parent/'tdirp_check_2026-11-01'/'Benchmark.zip'
CONTRACT='completion_c1_endholding_nowait_ML_header_v1'


def commit_checkpoint(path,record,parent_start=None):
    """A receipt timestamps completed atomic publication, not just verification."""
    path=Path(path);payload=json.dumps(record,indent=2).encode('utf-8')
    temporary=path.with_suffix('.tmp');temporary.write_bytes(payload);temporary.replace(path)
    receipt={'result_sha256':hashlib.sha256(payload).hexdigest(),
             'checkpoint_completed_elapsed_since_parent':None if parent_start is None else time.perf_counter()-parent_start}
    receipt_path=path.with_suffix('.commit.json');temporary=receipt_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(receipt),encoding='utf-8');temporary.replace(receipt_path)


def input_hash(name):
    with zipfile.ZipFile(ARCHIVE) as zipped:return hashlib.sha256(zipped.read(name)).hexdigest()


def plan_hash(name,routes,quantities,objective='completion'):
    q=np.asarray(quantities)
    if not np.isfinite(q).all() or np.max(np.abs(q-np.rint(q)))>1e-6:
        raise ValueError('Canonical start requires integral benchmark deliveries')
    payload={'input':name,'input_sha256':input_hash(name),'contract':CONTRACT,'objective':objective,
             'routes':[[int(k) for k in route] for route in routes],
             'quantities':np.rint(q).astype(int).tolist()}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def validate_plan(i,record,objective='completion'):
    if record.get('input')!=i.name or record.get('contract')!=CONTRACT or record.get('objective_definition')!=objective:
        raise ValueError('Frozen-start input/operational contract mismatch')
    if record['input_sha256']!=input_hash(i.name):raise ValueError('Frozen input bytes changed')
    if record['plan_sha256']!=plan_hash(i.name,record['routes'],record['quantities'],objective):
        raise ValueError('Frozen route/quantity identity mismatch')
    if not np.isfinite(record.get('objective',np.nan)):raise ValueError('Nonfinite frozen objective')
    verification=verify_routes(i,record['routes'],record['quantities'],objective)
    if not verification.get('checked'):raise ValueError('Frozen start failed independent feasibility check')
    if abs(verification['objective_decimal']-record['objective'])>1e-7:raise ValueError('Frozen cost mismatch')
    return verification


def create_start(name,path,seconds=10.,seed=20261102):
    start=time.perf_counter();i=read_instance(name);net=FifoNetwork(i)
    value=build_initial_plan(i,net,start+seconds,seed,'completion')
    record={'input':name,'created_utc':datetime.now(timezone.utc).isoformat(),'input_sha256':input_hash(name),
            'contract':CONTRACT,'objective_definition':'completion','initializer_seed':seed,
            'initializer_budget_seconds':seconds,'success':bool(value['success'])}
    if value['success']:
        verification=value['verification']
        record.update({'routes':value['routes'],'quantities':verification['quantities'],
                       'objective':verification['objective_decimal'],
                       'exact_feasible_objective':verification['exact_feasible_objective'],
                       'plan_sha256':plan_hash(name,value['routes'],verification['quantities']),
                       'initializer_route_dp_calls':value['route_dp_calls'],
                       'initializer_joint_repairs':value['joint_seed_repairs']})
        validate_plan(i,record)
        stocks=np.r_[i.supplier_initial,i.initial].astype(int);inventory=[stocks.tolist()]
        for p,q in enumerate(record['quantities']):
            stocks=stocks.copy();stocks[0]+=int(i.production[p])-sum(q)
            stocks[1:]+=np.asarray(q,dtype=int)-i.demand[p].astype(int)
            inventory.append(stocks.tolist())
        record['inventory_including_initial_period']=inventory
    else:record['failure_reason']=value.get('reason')
    record['offline_initialization_wall_seconds']=time.perf_counter()-start
    sys.path.insert(0,str(BASE.parent/'tdirp_math_audit'))
    from n20_root_pilot import peak_working_set_bytes
    record['initializer_parent_cumulative_peak_working_set_bytes']=peak_working_set_bytes()
    record['initialization_memory_scope']='parent process cumulative peak after this initialization; not isolated per-instance allocation'
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(record,indent=2),encoding='utf-8')
    return record
