"""Frozen-start multi-period repair and explicit decoder/backend controls.

The algorithm is a matheuristic. Global bounds are never inferred from a
restricted repair. V2 source files are imported unchanged for reproducibility.
"""
from pathlib import Path
import hashlib,json,sys,time
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent/'tdirp_newalgo'))
sys.path.insert(0,str(BASE.parent/'tdirp_math_audit'))
from schedule_repair import (FifoNetwork,read_instance,route_finish,backbone_values,
                             inventory_recourse,verify_routes,MILP_OPTIONS)
from root_lp_probe import base_model
from frozen_start import validate_plan,plan_hash,commit_checkpoint


def greedy_values(i,backbone,block,net,incumbent=None):
    """Heuristic all-subset profiles using best-last-customer insertion.

    Each subset reuses one route from each predecessor subset; the chosen route
    is not a dominance-safe label for later insertion. No exact decoder claim.
    Outside order and selected membership are preserved.
    """
    k=len(block);count=1<<k;orders=[None]*count;values=np.full(count,np.inf)
    orders[0]=list(backbone);values[0]=route_finish(i,backbone,net);prefixes={}
    oldmask=None if incumbent is None else sum(1<<j for j,a in enumerate(block) if a in incumbent)
    oldfinish=np.inf if incumbent is None else route_finish(i,incumbent,net)
    for T in range(1,count):
        best=None;cost=np.inf
        for j in range(k):
            if not T>>j&1:continue
            previous=T^(1<<j);route=orders[previous]
            if route is None:continue
            if previous not in prefixes:
                labels=[0.];last=0
                for a in route:
                    labels.append(net.arrival(last,a+1,labels[-1])+i.service[a]);last=a+1
                prefixes[previous]=labels
            for position in range(len(route)+1):
                last=0 if position==0 else route[position-1]+1
                now=net.arrival(last,block[j]+1,prefixes[previous][position])+i.service[block[j]]
                last=block[j]+1
                for a in route[position:]:now=net.arrival(last,a+1,now)+i.service[a];last=a+1
                finish=net.arrival(last,0,now)
                if finish<cost:
                    cost=finish;best=route[:position]+[block[j]]+route[position:]
        if T==oldmask and oldfinish<cost:cost=oldfinish;best=list(incumbent)
        values[T]=cost;orders[T]=best
    return values,orders


def profile_repair(i,routes,block,time_limit=1.5,objective='completion',decoder='dp',net=None,
                   freeze_outside_quantities=None):
    start=time.perf_counter();end=start+time_limit;block=list(block);B=set(block)
    if len(B)!=len(block) or any(a<0 or a>=i.n for a in block):raise ValueError('Invalid customer block')
    if len(block)>10:raise ValueError('Research repair caps either decoder block at 10')
    if len(routes)!=i.horizon or any(len(set(r))!=len(r) or any(a<0 or a>=i.n for a in r) for r in routes):
        raise ValueError('Invalid route horizon or elementary route')
    if decoder not in {'dp','greedy'} or objective not in {'completion','travel'}:raise ValueError('Unsupported profile mode')
    net=FifoNetwork(i) if net is None else net;tables=[];paths=[];complete=True
    for route in routes:
        backbone=[a for a in route if a not in B]
        finish,orders=(backbone_values(i,backbone,block,net) if decoder=='dp' else greedy_values(i,backbone,block,net,route))
        # Guarantee the same verified incumbent remains representable even when
        # a greedy subset route is worse than the original ordering.
        oldmask=sum(1<<j for j,a in enumerate(block) if a in route)
        oldfinish=route_finish(i,route,net)
        if decoder=='dp' and oldfinish<finish[oldmask]-1e-8:
            raise RuntimeError('Exact decoder failed incumbent containment')
        if oldfinish<finish[oldmask]:finish[oldmask]=oldfinish;orders[oldmask]=list(route)
        values=finish.copy()
        if objective=='travel':
            for T,path in enumerate(orders):
                if path is not None:values[T]-=sum(i.service[a] for a in path)
        tables.append(values);paths.append(orders)
        if time.perf_counter()>=end:complete=False;break
    profile_seconds=time.perf_counter()-start
    if not complete:return {'status':1,'objective':None,'reason':'profile build budget','profile_seconds':profile_seconds,'decoder':decoder}
    lp,y,q,inv,z=base_model(i);zset=set(z)
    keep=[r for r,row in enumerate(lp.ub) if not zset.intersection(row)]
    lp.ub=[lp.ub[r] for r in keep];lp.ubrhs=[lp.ubrhs[r] for r in keep]
    for v in z:lp.c[v]=0.
    columns=[]
    for p,route in enumerate(routes):
        present=set(route)
        for a in range(i.n):
            lp.bounds[inv[p][a+1]]=(float(i.minimum[a]),None)
            if a not in B:lp.bounds[y[p][a]]=(float(a in present),float(a in present))
            if freeze_outside_quantities is not None and a not in B:
                value=float(freeze_outside_quantities[p][a]);lp.bounds[q[p][a]]=(value,value)
        eligible=[T for T,path in enumerate(paths[p]) if path is not None and route_finish(i,path,net)<=i.deadline]
        cols={T:lp.var(c=float(tables[p][T])) for T in eligible};columns.append(cols)
        if not cols:return {'status':2,'objective':None,'profile_seconds':profile_seconds,'reason':'no feasible profile'}
        lp.equality({v:1. for v in cols.values()},1.)
        for j,a in enumerate(block):
            row={y[p][a]:-1.};row.update({v:1. for T,v in cols.items() if T>>j&1});lp.equality(row,0.)
    integer=np.zeros(len(lp.c),dtype=np.uint8)
    for p in range(i.horizon):
        for a in block:integer[y[p][a]]=1
    constraints=[LinearConstraint(lp.sparse(lp.eq),lp.eb,lp.eb),LinearConstraint(lp.sparse(lp.ub),-np.inf,lp.ubrhs)]
    if time.perf_counter()>=end:return {'status':1,'objective':None,'profile_seconds':profile_seconds,'reason':'master build budget'}
    result=milp(lp.c,integrality=integer,
                bounds=Bounds([b[0] for b in lp.bounds],[np.inf if b[1] is None else b[1] for b in lp.bounds]),
                constraints=constraints,options={'time_limit':max(.001,end-time.perf_counter()),**MILP_OPTIONS})
    answer={'status':int(result.status),'objective':None,'decoder':decoder,'profile_seconds':profile_seconds,
            'variables':len(lp.c),'binary_visits':len(block)*i.horizon,'patterns_by_period':[len(c) for c in columns],
            'profile_master_lower_bound':None if getattr(result,'mip_dual_bound',None) is None else float(result.mip_dual_bound),
            'conditional_lower_bound':None if decoder!='dp' or getattr(result,'mip_dual_bound',None) is None else float(result.mip_dual_bound),
            'scope':'restricted exact neighborhood for DP; constructed-profile neighborhood for greedy'}
    if result.x is not None:
        selected=[max(cols,key=lambda T:result.x[cols[T]]) for cols in columns]
        newroutes=[paths[p][T] for p,T in enumerate(selected)]
        recourse=inventory_recourse(i,newroutes,time_limit=max(.001,end-time.perf_counter()),
                                    frozen=freeze_outside_quantities,free_customers=block)
        if recourse['success']:
            verification=verify_routes(i,newroutes,recourse['quantities'],objective)
            if verification.get('checked'):
                answer.update({'objective':verification['objective_decimal'],'routes':newroutes,
                    'quantities':verification['quantities'],'inventory':recourse['inventory'],
                    'independent_verification':verification})
                answer['profile_master_optimal']=result.status==0 and abs(result.fun-answer['objective'])<=1e-5
                answer['conditional_optimum_verified']=decoder=='dp' and answer['profile_master_optimal']
    answer['wall_seconds']=time.perf_counter()-start
    return answer


def search_from_plan(i,initial,method='joint_dp',seed=20261104,time_limit=15.,checkpoint=None,run_id=None,parent_start=None):
    start=time.perf_counter();end=start+time_limit
    numeric=[i.travel,i.service,i.initial,i.maximum,i.minimum,i.demand,i.production,
             np.array([i.supplier_initial,i.capacity,i.deadline,i.steps,i.step_seconds])]
    if any(not np.isfinite(a).all() or np.any(a<0) or np.any(a!=np.rint(a)) for a in numeric):
        raise ValueError('Finite nonnegative integral benchmark data required')
    holding=np.r_[i.supplier_holding,i.holding]
    if not np.isfinite(holding).all() or np.any(holding<0) or i.steps<1 or i.step_seconds<1 or i.n<1 or i.horizon<1:
        raise ValueError('Invalid dimensions/costs for the declared model and trivial bound')
    verification=validate_plan(i,initial);net=FifoNetwork(i)
    routes=[list(r) for r in initial['routes']];quantities=[list(q) for q in initial['quantities']]
    expected_hash=initial['plan_sha256'];actual_hash=plan_hash(i.name,routes,quantities)
    if expected_hash!=actual_hash:raise RuntimeError('Initial-state mismatch')
    rng=np.random.default_rng(seed);best=verification['objective_decimal'];initialcost=best
    arc_cache=None
    if method=='joint_arc':
        from arc_repair import ArcProfileCache
        arc_cache=ArcProfileCache()
    iterations=0;improvements=0;stagnation=0;profile_seconds=0.;repair_seconds=0.;exact_repairs=0
    cache_hits=0;cache_misses=0
    trace=[{'iteration':0,'seconds':time.perf_counter()-start,'objective':best}]
    initialroutes=[r.copy() for r in routes];initialq=[q.copy() for q in quantities]
    def snapshot(status='searching'):
        return {'input':i.name,'method':method,'status':status,'objective':best,'lower_bound':0.,'mip_gap':None,
                'objective_definition':'completion','c':1.,'p0_holding':False,'seed':seed,'run_id':run_id,
                'initial_plan_sha256':actual_hash,'expected_initial_sha256':expected_hash,'initial_objective':initialcost,
                'initial_routes':initialroutes,'initial_quantities':initialq,
                'offline_initialization_wall_seconds':initial['offline_initialization_wall_seconds'],
                'global_routing_table_used':False,
                'routes':routes,'quantities':quantities,'independent_verification':verification,
                'iterations':iterations,'improvements':improvements,'exact_local_repairs':exact_repairs,
                'arc_profile_cache_hits':cache_hits,'arc_profile_cache_misses':cache_misses,
                'profile_seconds':profile_seconds,'repair_wall_seconds':repair_seconds,
                'search_wall_seconds':time.perf_counter()-start,'trace':trace,
                'checkpoint_verified_elapsed_since_parent':None if parent_start is None else time.perf_counter()-parent_start,
                'scope':'frozen-start matheuristic, offline common initialization reported separately; no global certificate'}
    def save(status='searching'):
        if checkpoint:
            commit_checkpoint(checkpoint,snapshot(status),parent_start)
    save()
    while time.perf_counter()<end-.03:
        k=1 if method=='single_dp' else min(i.n,4 if stagnation<8 else 6)
        block=list(map(int,rng.choice(i.n,k,replace=False)))
        allowance=min(1.5,max(.001,end-time.perf_counter()))
        lap=time.perf_counter()
        if method=='joint_arc':
            from arc_repair import solve_arc_repair
            repair=solve_arc_repair(i,routes,block,time_limit=allowance,objective='completion',profile_cache=arc_cache)
        elif method in {'single_dp','joint_dp','joint_greedy'}:
            repair=profile_repair(i,routes,block,time_limit=allowance,
                                  decoder='greedy' if method=='joint_greedy' else 'dp',net=net)
        else:raise ValueError(method)
        repair_seconds+=time.perf_counter()-lap
        profile_seconds+=repair.get('profile_seconds',repair.get('profile_setup_seconds',0.))
        cache_hits+=repair.get('profile_cache_hits',0);cache_misses+=repair.get('profile_cache_misses',0)
        iterations+=1;exact_repairs+=bool(repair.get('conditional_optimum_verified'))
        if repair.get('objective') is not None and repair['objective']<best-1e-7:
            check=repair.get('independent_verification')
            if not check or not check.get('checked'):raise RuntimeError('Unverified repair cannot become incumbent')
            best=repair['objective'];routes=repair['routes'];quantities=repair['quantities'];verification=check
            improvements+=1;stagnation=0
            trace.append({'iteration':iterations,'seconds':time.perf_counter()-start,'objective':best,'block':block})
        else:stagnation+=1
        save()
    save('time_limit');return snapshot('time_limit')
