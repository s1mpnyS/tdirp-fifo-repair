"""Deterministic-work routing initialization plus conditional-DP feasibility.

No global subset table. Failure means no seed found under this budget.
"""
import time
import numpy as np
from schedule_repair import inventory_recourse,route_finish,backbone_values,verify_routes,solve_repair


def deterministic_route(i,customers,net,end):
    customers=sorted(customers)
    if not customers:return []
    candidates=[]
    for first in customers:
        left=set(customers);left.remove(first);route=[first]
        now=net.arrival(0,first+1,0.)+i.service[first]
        while left:
            nxt=min(left,key=lambda k:(net.arrival(route[-1]+1,k+1,now)+i.service[k],k))
            now=net.arrival(route[-1]+1,nxt+1,now)+i.service[nxt];route.append(nxt);left.remove(nxt)
        candidates.append(route)
        if time.perf_counter()>=end:break
    current=min(candidates,key=lambda r:(route_finish(i,r,net),tuple(r)))
    value=route_finish(i,current,net)
    # Fixed scan/pass order makes successful completed initializations repeatable.
    for sweep in range(3):
        best=current;bestvalue=value
        for a in range(len(current)):
            for b in range(a+1,len(current)):
                candidate=current[:a]+list(reversed(current[a:b+1]))+current[b+1:]
                cost=route_finish(i,candidate,net)
                if cost<bestvalue:best=candidate;bestvalue=cost
            if time.perf_counter()>=end:return best
        if bestvalue>=value:break
        current=best;value=bestvalue
    return current


def mandatory_polish(i,route,net,end,max_calls=24):
    current=list(route);value=route_finish(i,current,net)
    if value<=i.deadline:return current,0
    calls=0;m=len(current);k=min(6,m)
    if not m:return current,0
    for sweep in range(3):
        changed=False
        for offset in range(m):
            if calls>=max_calls or time.perf_counter()>=end:return current,calls
            # Alternate contiguous and spread-out free customers.
            stride=1 if sweep%2==0 else max(1,m//k)
            block=[]
            for j in range(m):
                customer=current[(offset+j*stride)%m]
                if customer not in block:block.append(customer)
                if len(block)==k:break
            if len(block)<k:
                block+= [a for a in current if a not in block][:k-len(block)]
            B=set(block);backbone=[a for a in current if a not in B]
            values,orders=backbone_values(i,backbone,block,net);calls+=1
            if values[-1]<value:
                current=orders[-1];value=float(values[-1]);changed=True
                if value<=i.deadline:return current,calls
        if not changed:break
    return current,calls


def build_initial_plan(i,net,end,seed=20261102,objective='completion'):
    start=time.perf_counter();flow=inventory_recourse(i,[list(range(i.n)) for _ in range(i.horizon)],
                                                    time_limit=max(.001,end-time.perf_counter()))
    if not flow['success']:return {'success':False,'reason':'inventory seed LP: '+flow.get('message','')}
    routes=[deterministic_route(i,np.flatnonzero(np.array(flow['quantities'][p])>1e-6).tolist(),net,end)
            for p in range(i.horizon)]
    calls=0
    for p in range(i.horizon):
        if route_finish(i,routes[p],net)>i.deadline:
            routes[p],count=mandatory_polish(i,routes[p],net,end);calls+=count
    verification=verify_routes(i,routes,flow['quantities'],objective)
    if verification['checked']:
        return {'success':True,'routes':routes,'verification':verification,'route_dp_calls':calls,
                'joint_seed_repairs':0,'seconds':time.perf_counter()-start}
    # A hard local repair can restore duration feasibility while changing visits
    # and reallocating shipments. It is common initialization for all controls.
    rng=np.random.default_rng(seed);attempts=0
    for attempt in range(3):
        if time.perf_counter()>=end:break
        attempts+=1
        block=list(map(int,rng.choice(i.n,min(6,i.n),replace=False)))
        result=solve_repair(i,routes,block,time_limit=min(1.,max(.001,end-time.perf_counter())),
                            objective=objective,net=net)
        if result.get('objective') is not None:
            return {'success':True,'routes':result['routes'],'verification':result['independent_verification'],
                    'route_dp_calls':calls,'joint_seed_repairs':attempts,'seconds':time.perf_counter()-start}
    # Preserve zero-delivery service stops as an alternative on nonmetric FIFO.
    full=deterministic_route(i,list(range(i.n)),net,end)
    full,count=mandatory_polish(i,full,net,end);calls+=count
    verification=verify_routes(i,[full.copy() for _ in range(i.horizon)],flow['quantities'],objective)
    if verification['checked']:
        return {'success':True,'routes':[full.copy() for _ in range(i.horizon)],'verification':verification,
                'route_dp_calls':calls,'joint_seed_repairs':attempts,'seconds':time.perf_counter()-start}
    return {'success':False,'reason':verification['reason'],'seconds':time.perf_counter()-start,
            'route_dp_calls':calls,'scope':'initialization failure, not global infeasibility'}
