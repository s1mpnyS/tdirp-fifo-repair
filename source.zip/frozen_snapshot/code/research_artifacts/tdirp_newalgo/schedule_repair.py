"""Joint multi-period schedule repair with conditional FIFO insertion DP.

The full algorithm is a matheuristic. A completed repair is exact only within
its declared customer block and outside-order neighborhood. No cuts or global
2**n routing table are used. Generic MIP repair and bounded reinsertion DP have
prior art; this prototype does not establish publication priority.
"""
from pathlib import Path
from fractions import Fraction
import itertools,json,sys,time
import numpy as np
from scipy.optimize import linprog,milp,Bounds,LinearConstraint

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent/'tdirp_math_audit'))
from fifo_probe import FifoNetwork,direct_arrival,read_instance
from root_lp_probe import base_model

MILP_OPTIONS={'threads':1,'primal_feasibility_tolerance':1e-8,
              'dual_feasibility_tolerance':1e-8,'mip_feasibility_tolerance':1e-7,
              'mip_abs_gap':1e-6,'mip_rel_gap':0.}


def route_finish(i,route,net=None):
    net=FifoNetwork(i) if net is None else net
    now=0.;last=0
    for k in route:now=net.arrival(last,k+1,now)+i.service[k];last=k+1
    return net.arrival(last,0,now) if route else 0.


def backbone_values(i,backbone,block,net=None):
    """All selected-block subset values with outside relative order fixed.

    DP state (outside prefix length, inserted block subset, last code).
    Last code 0 is the last outside node (depot for empty prefix); j+1 is B[j].
    Complexity O((m+1)(k+1)^2 2**k), memory O((m+1)(k+1)2**k).
    """
    backbone=list(backbone);block=list(block);m=len(backbone);k=len(block)
    if len(set(backbone+block))!=m+k or any(j<0 or j>=i.n for j in backbone+block):
        raise ValueError('Backbone and block must be disjoint unique customer indices')
    if k>10:raise ValueError('Research repair caps block size at 10')
    net=FifoNetwork(i) if net is None else net;count=1<<k
    d=np.full((m+1,count,k+1),np.inf);pred=np.full(d.shape,-1,dtype=np.int8)
    d[0,0,0]=0.
    for r in range(m+1):
        for T in range(count):
            for lastcode in range(k+1):
                departure=d[r,T,lastcode]
                if not np.isfinite(departure):continue
                last=(backbone[r-1]+1 if r else 0) if lastcode==0 else block[lastcode-1]+1
                if r<m:
                    j=backbone[r];candidate=net.arrival(last,j+1,departure)+i.service[j]
                    if candidate<d[r+1,T,0]:d[r+1,T,0]=candidate;pred[r+1,T,0]=lastcode
                for j in range(k):
                    if T>>j&1:continue
                    actual=block[j];candidate=net.arrival(last,actual+1,departure)+i.service[actual]
                    new=T|(1<<j)
                    if candidate<d[r,new,j+1]:d[r,new,j+1]=candidate;pred[r,new,j+1]=lastcode
    finish=np.full(count,np.inf);orders=[None]*count
    for T in range(count):
        if m==0 and T==0:finish[T]=0.;orders[T]=[];continue
        code=-1
        for lastcode in range(k+1):
            if not np.isfinite(d[m,T,lastcode]):continue
            last=(backbone[-1]+1 if m else 0) if lastcode==0 else block[lastcode-1]+1
            value=net.arrival(last,0,d[m,T,lastcode])
            if value<finish[T]:finish[T]=value;code=lastcode
        if code<0:continue
        r=m;mask=T;reverse=[]
        while r or mask:
            old=code;code=int(pred[r,mask,old])
            if old==0:reverse.append(backbone[r-1]);r-=1
            else:
                j=old-1;reverse.append(block[j]);mask^=1<<j
            if code<0:raise RuntimeError('Broken conditional DP predecessor')
        orders[T]=list(reversed(reverse))
    return finish,orders


def verify_routes(i,routes,quantities,objective='completion'):
    """Literal FIFO + exact integer stock/load and rational holding check."""
    if len(routes)!=i.horizon or objective not in {'travel','completion'}:
        return {'checked':False,'reason':'invalid route horizon/objective'}
    q=np.asarray(quantities)
    if q.shape!=(i.horizon,i.n) or not np.isfinite(q).all():return {'checked':False,'reason':'invalid quantity array'}
    if np.max(np.abs(q-np.rint(q)))>1e-6:return {'checked':False,'reason':'nonintegral quantity recovery'}
    q=np.rint(q).astype(int);stock=i.initial.astype(int).copy();supplier=int(i.supplier_initial)
    holding=Fraction(0);returns=[];travels=[]
    for p,route in enumerate(routes):
        if len(set(route))!=len(route) or any(k<0 or k>=i.n for k in route):return {'checked':False,'reason':'invalid elementary route'}
        present=set(route)
        if np.any(q[p]<0) or q[p].sum()>i.capacity or any(q[p,k] and k not in present for k in range(i.n)):
            return {'checked':False,'reason':'load/visit violation'}
        if np.any(stock+q[p]>i.maximum):return {'checked':False,'reason':'pre-demand storage violation'}
        stock=stock+q[p]-i.demand[p].astype(int);supplier+=int(i.production[p])-int(q[p].sum())
        if np.any(stock<i.minimum) or supplier<0:return {'checked':False,'reason':'inventory/supplier violation'}
        now=0.;last=0;travel=0.
        for k in route:
            arrival=direct_arrival(i,last,k+1,now);travel+=arrival-now;now=arrival+i.service[k];last=k+1
        arrival=direct_arrival(i,last,0,now) if route else 0.
        if route:travel+=arrival-now
        if not np.isfinite(arrival) or arrival>i.deadline:return {'checked':False,'reason':'route deadline/domain violation'}
        if arrival!=int(arrival) or travel!=int(travel):return {'checked':False,'reason':'noninteger reachable time'}
        returns.append(int(arrival));travels.append(int(travel))
        holding+=Fraction(str(i.supplier_holding))*supplier
        holding+=sum(Fraction(str(i.holding[k]))*int(stock[k]) for k in range(i.n))
    routing=sum(returns if objective=='completion' else travels);value=holding+routing
    return {'checked':True,'exact_feasible_objective':str(value),'objective_decimal':float(value),
            'return_times':returns,'travel_times':travels,'holding_cost':str(holding),
            'quantities':q.tolist(),'routes':routes,'scope':'integral benchmark inputs, c=1'}


def inventory_recourse(i,routes,time_limit=5.,frozen=None,free_customers=None):
    lp,y,q,inv,z=base_model(i)
    zset=set(z);keep=[j for j,row in enumerate(lp.ub) if not zset.intersection(row)]
    lp.ub=[lp.ub[j] for j in keep];lp.ubrhs=[lp.ubrhs[j] for j in keep]
    free=set() if free_customers is None else set(free_customers)
    for p,route in enumerate(routes):
        present=set(route)
        for k in range(i.n):
            lp.bounds[y[p][k]]=(float(k in present),float(k in present))
            lp.bounds[inv[p][k+1]]=(float(i.minimum[k]),None)
            if frozen is not None and k not in free:
                value=float(frozen[p][k]);lp.bounds[q[p][k]]=(value,value)
        lp.c[z[p]]=0.
    result=linprog(lp.c,A_eq=lp.sparse(lp.eq),b_eq=lp.eb,A_ub=lp.sparse(lp.ub),b_ub=lp.ubrhs,
                   bounds=lp.bounds,method='highs',options={'time_limit':max(.001,time_limit),'threads':1,
                    'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8})
    if not result.success:return {'success':False,'status':int(result.status),'message':result.message}
    return {'success':True,'holding_cost':float(result.fun),'quantities':result.x[np.array(q)].tolist(),
            'inventory':result.x[np.array(inv)].tolist()}


def solve_repair(i,routes,block,time_limit=2.,freeze_outside_quantities=None,objective='completion',net=None):
    start=time.perf_counter();end=start+time_limit;block=list(block);B=set(block)
    if objective not in {'travel','completion'}:raise ValueError(objective)
    net=FifoNetwork(i) if net is None else net
    tables=[];orders=[]
    for route in routes:
        values,paths=backbone_values(i,[k for k in route if k not in B],block,net)
        if objective=='travel':
            for T,path in enumerate(paths):
                if path is not None:values[T]-=sum(i.service[k] for k in path)
        tables.append(values);orders.append(paths)
    dp_seconds=time.perf_counter()-start
    lp,y,q,inv,z=base_model(i);zset=set(z)
    keep=[j for j,row in enumerate(lp.ub) if not zset.intersection(row)]
    lp.ub=[lp.ub[j] for j in keep];lp.ubrhs=[lp.ubrhs[j] for j in keep]
    for v in z:lp.c[v]=0.
    variables=[]
    for p,route in enumerate(routes):
        present=set(route)
        for k in range(i.n):
            lp.bounds[inv[p][k+1]]=(float(i.minimum[k]),None)
            if k not in B:lp.bounds[y[p][k]]=(float(k in present),float(k in present))
            if freeze_outside_quantities is not None and k not in B:
                value=float(freeze_outside_quantities[p][k]);lp.bounds[q[p][k]]=(value,value)
        eligible=[]
        for T,path in enumerate(orders[p]):
            if path is not None and route_finish(i,path,net)<=i.deadline:eligible.append(T)
        cols={T:lp.var(c=float(tables[p][T])) for T in eligible};variables.append(cols)
        if not cols:return {'status':2,'objective':None,'reason':'no conditional feasible pattern','dp_seconds':dp_seconds}
        lp.equality({v:1. for v in cols.values()},1.)
        for j,k in enumerate(block):
            row={y[p][k]:-1.};row.update({v:1. for T,v in cols.items() if T>>j&1});lp.equality(row,0.)
    integer=np.zeros(len(lp.c),dtype=np.uint8)
    for p in range(i.horizon):
        for k in block:integer[y[p][k]]=1
    constraints=[LinearConstraint(lp.sparse(lp.eq),lp.eb,lp.eb),LinearConstraint(lp.sparse(lp.ub),-np.inf,lp.ubrhs)]
    remaining=end-time.perf_counter()
    if remaining<=0:return {'status':1,'objective':None,'reason':'repair build budget','dp_seconds':dp_seconds}
    result=milp(lp.c,integrality=integer,
                bounds=Bounds([b[0] for b in lp.bounds],[np.inf if b[1] is None else b[1] for b in lp.bounds]),
                constraints=constraints,options={'time_limit':remaining,**MILP_OPTIONS})
    ans={'status':int(result.status),'objective':None,'solver_objective':None if result.fun is None else float(result.fun),
         'conditional_lower_bound':None if getattr(result,'mip_dual_bound',None) is None else float(result.mip_dual_bound),
         'dp_seconds':dp_seconds,'variables':len(lp.c),'binary_visits':len(block)*i.horizon,
         'patterns_by_period':[len(c) for c in variables],'scope':'exact only within declared outside-order/block neighborhood'}
    if result.x is not None:
        selected=[max(cols,key=lambda T:result.x[cols[T]]) for cols in variables]
        newroutes=[orders[p][T] for p,T in enumerate(selected)]
        # Re-solve quantities for the selected visits, then verify the literal
        # route. This may only improve the recovered feasible cost.
        recourse=inventory_recourse(i,newroutes,time_limit=max(.001,end-time.perf_counter()),
                                    frozen=freeze_outside_quantities,free_customers=block)
        if recourse['success']:
            verification=verify_routes(i,newroutes,recourse['quantities'],objective)
            if verification['checked']:
                ans.update({'objective':verification['objective_decimal'],'routes':newroutes,
                            'quantities':verification['quantities'],'inventory':recourse['inventory'],
                            'independent_verification':verification})
                ans['conditional_optimum_verified']=result.status==0 and abs(ans['objective']-float(result.fun))<=1e-5
    ans['wall_seconds']=time.perf_counter()-start
    return ans


def improve_route(i,route,net,deadline):
    if not route:return []
    candidates=[list(route)]
    for first in list(route)[:min(8,len(route))]:
        left=set(route);left.remove(first);order=[first];now=net.arrival(0,first+1,0.)+i.service[first]
        while left:
            nxt=min(left,key=lambda k:(net.arrival(order[-1]+1,k+1,now)+i.service[k],k))
            now=net.arrival(order[-1]+1,nxt+1,now)+i.service[nxt];order.append(nxt);left.remove(nxt)
        candidates.append(order)
    current=min(candidates,key=lambda r:route_finish(i,r,net));value=route_finish(i,current,net)
    while time.perf_counter()<deadline:
        best=current;bestvalue=value
        for a in range(len(current)):
            for b in range(len(current)):
                if a==b:continue
                candidate=current.copy();node=candidate.pop(a);candidate.insert(b,node)
                cost=route_finish(i,candidate,net)
                if cost<bestvalue:best=candidate;bestvalue=cost
            if time.perf_counter()>=deadline:break
        if bestvalue>=value:break
        current=best;value=bestvalue
    return current


def pair_scores(i,routes,quantities,net,deadline=float('inf')):
    """Candidate ranking proxy, not a feasibility certificate or bound.

    Exact FIFO route deltas of two-period membership exchanges plus a linear
    holding-transfer proxy. Actual repair decides all quantities jointly.
    """
    n=i.n;H=i.horizon;q=np.asarray(quantities);sets=[set(r) for r in routes]
    finishes=[route_finish(i,r,net) for r in routes];score=np.zeros((n,n))
    slack=i.capacity-q.sum(axis=1)
    for a in range(n):
        for b in range(a+1,n):
            if time.perf_counter()>=deadline:return score
            best=0.;tables={}
            for p in range(H):
                if a not in sets[p] or b in sets[p]:continue
                for r in range(H):
                    if r==p or b not in sets[r] or a in sets[r]:continue
                    # k=2 conditional DP permits all reinsertion positions and
                    # keeps the remaining relative order exactly.
                    for period in [p,r]:
                        if period not in tables:
                            tables[period]=backbone_values(i,[k for k in routes[period] if k not in {a,b}],[a,b],net)[0]
                    v1=tables[p];v2=tables[r]
                    routing=finishes[p]+finishes[r]-v1[2]-v2[1]
                    volume=min(q[p,a],q[r,b]);holding=(i.holding[a]-i.holding[b])*(r-p)*volume
                    tight=volume/(1.+max(0.,slack[p])+max(0.,slack[r]))
                    best=max(best,float(routing+holding)*(1.+tight))
            score[a,b]=score[b,a]=best
    return score


def run_case(name,objective='completion',time_limit=55.,seed=20261102,selection='exchange',checkpoint=None,run_id=None):
    start=time.perf_counter();end=start+time_limit;i=read_instance(name);net=FifoNetwork(i)
    rng=np.random.default_rng(seed)
    numeric=[i.travel,i.service,i.initial,i.maximum,i.minimum,i.demand,i.production,
             np.array([i.supplier_initial,i.capacity,i.deadline])]
    if any(not np.isfinite(a).all() or np.any(a<0) or np.any(a!=np.rint(a)) for a in numeric):
        raise ValueError('Research implementation requires finite nonnegative integral benchmark data')
    if not np.isfinite(np.r_[i.supplier_holding,i.holding]).all() or np.any(np.r_[i.supplier_holding,i.holding]<0):
        raise ValueError('Nonnegative finite holding costs required for the reported trivial bound')
    from routing_initializer import build_initial_plan
    initialization=build_initial_plan(i,net,min(end,time.perf_counter()+min(6.,max(.1,time_limit/4))),seed,objective)
    if not initialization['success']:
        return {'input':name,'method':'joint_schedule_repair','objective_definition':objective,
                'status':'initialization_failed','reason':initialization['reason'],'objective':None,
                'run_id':run_id,'total_wall_seconds':time.perf_counter()-start}
    routes=initialization['routes'];verification=initialization['verification']
    initial=verification['objective_decimal'];best=initial;quantities=verification['quantities']
    initialization_seconds=time.perf_counter()-start
    repairs=0;improvements=0;exact_repairs=0;dp_seconds=0.;selection_seconds=0.;repair_seconds=0.
    trace=[{'repair':0,'block':[],'objective':best,'seconds':initialization_seconds}];stagnation=0
    def snapshot(status='searching'):
        return {'input':name,'method':'joint_schedule_repair','status':status,'objective_definition':objective,
                'c':1.,'p0_holding':False,'objective':best,'lower_bound':0.,
                'mip_gap':None,'run_id':run_id,'selection':selection,'seed':seed,
                'initial_objective':initial,'repairs':repairs,'improvements':improvements,
                'repairs_solved_to_optimality':exact_repairs,'repair_dp_seconds':dp_seconds,
                'block_selection_seconds':selection_seconds,'repair_wall_seconds':repair_seconds,
                'initialization_seconds':initialization_seconds,
                'initialization_route_dp_calls':initialization['route_dp_calls'],
                'initialization_joint_seed_repairs':initialization['joint_seed_repairs'],
                'global_routing_table_used':False,'total_wall_seconds':time.perf_counter()-start,
                'routes':routes,'quantities':quantities,'independent_verification':verification,'trace':trace,
                'scope':'matheuristic, no global optimality claim; numerical exactness only for completed repair neighborhoods'}
    def save(status='searching'):
        if checkpoint:
            path=Path(checkpoint);temp=path.with_suffix('.tmp')
            temp.write_text(json.dumps(snapshot(status),indent=2),encoding='utf-8');temp.replace(path)
    save();single_queue=list(rng.permutation(i.n));used=set();graph=None
    while time.perf_counter()<end-.03:
        selection_started=time.perf_counter()
        if single_queue:block=[int(single_queue.pop())]
        elif selection=='single':block=[int(rng.integers(i.n))]
        else:
            k=min(i.n,4 if stagnation<8 else 6)
            if selection=='exchange':
                if graph is None:graph=pair_scores(i,routes,quantities,net,end-.03)
                pairs=sorted(((graph[a,b],a,b) for a in range(i.n) for b in range(a+1,i.n)),reverse=True)
                candidate=next(((a,b) for weight,a,b in pairs if (a,b) not in used),None)
                if candidate is None:
                    used.clear();block=list(map(int,rng.choice(i.n,k,replace=False)))
                else:
                    used.add(candidate);block=list(candidate)
                    while len(block)<k:
                        left=[a for a in range(i.n) if a not in block]
                        nxt=max(left,key=lambda a:(sum(graph[a,b] for b in block),float(rng.random())))
                        block.append(nxt)
            else:block=list(map(int,rng.choice(i.n,k,replace=False)))
        selection_seconds+=time.perf_counter()-selection_started
        if time.perf_counter()>=end-.03:break
        allowance=min(1.5,max(.001,end-time.perf_counter()))
        repair_started=time.perf_counter()
        result=solve_repair(i,routes,block,time_limit=allowance,objective=objective,net=net)
        repair_seconds+=time.perf_counter()-repair_started
        repairs+=1;exact_repairs+=bool(result.get('conditional_optimum_verified'));dp_seconds+=result.get('dp_seconds',0.)
        if result.get('objective') is not None and result['objective']<best-1e-7:
            best=result['objective'];routes=result['routes'];quantities=result['quantities'];verification=result['independent_verification']
            improvements+=1;stagnation=0;used.clear();graph=None
            trace.append({'repair':repairs,'block':block,'objective':best,'seconds':time.perf_counter()-start})
        else:stagnation+=1
        save()
    save('time_limit');return snapshot('time_limit')


if __name__=='__main__':
    result=run_case('H3/inst_20_120_1.txt',time_limit=20.)
    (BASE/'first_pilot.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in {'routes','quantities','independent_verification','trace'}}))
