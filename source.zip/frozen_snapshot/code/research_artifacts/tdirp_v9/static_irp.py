"""Full static single-vehicle IRP, solved with SciPy's bundled native HiGHS.

Directed costs are unrounded arithmetic means of the original traffic bins.
The model includes whole depot tours, fixed service, end-period holding,
finite supplier production, maximum-level customer storage and return cutoff.
Single-commodity flow connects every visit, including visits with zero delivery;
no metric/triangle assumption is made. Bounds and gaps refer ONLY to this
static MILP. No FIFO routing initializer or joint repair is called here.

Deadlines are absolute time.perf_counter() values. Native solver limits are
cooperative; the caller must provide its own hard wall/RSS watchdog.
"""
from __future__ import annotations

import math
import time

import numpy as np
from scipy.sparse import coo_matrix


TOL = 1e-7
DELIVERY_TOL = 1e-6
STATIC_CONTRACT = "directed_raw_bin_mean_service_endholding_ML_full_arc_scf_v1"


def _validate_instance(i):
    if int(i.n) != i.n or int(i.horizon) != i.horizon or i.n < 1 or i.horizon < 1:
        raise ValueError("Positive integer customer/period dimensions required")
    shapes = {"initial": (i.n,), "maximum": (i.n,), "minimum": (i.n,),
              "demand": (i.horizon, i.n), "production": (i.horizon,),
              "service": (i.n,), "holding": (i.n,),
              "travel": (i.n + 1, i.n + 1, i.steps)}
    if int(i.steps) != i.steps or i.steps < 1:
        raise ValueError("Positive integer number of traffic bins required")
    for name, shape in shapes.items():
        value = np.asarray(getattr(i, name), dtype=float)
        if value.shape != shape or not np.isfinite(value).all() or np.any(value < 0):
            raise ValueError("Invalid instance field: " + name)
        if name not in {"holding", "travel"} and np.any(value != np.rint(value)):
            raise ValueError("Integral benchmark physical data required: " + name)
    values = np.asarray([i.capacity, i.deadline, i.supplier_initial, i.supplier_holding], dtype=float)
    if not np.isfinite(values).all() or np.any(values < 0):
        raise ValueError("Invalid capacity, cutoff, supplier stock or holding")
    if np.any(np.asarray(i.minimum) > np.asarray(i.maximum)):
        raise ValueError("Customer minimum exceeds maximum")


def build_static_model(i):
    """Construct a full arc IRP MILP without solving or mutating the instance.

    y[p,k] is a visit, q[p,k] a continuous delivery, inventory[p,0] the
    supplier's end stock, and inventory[p,k+1] a customer's end stock.
    x[p,u,v] uses depot=0/customer=k+1. f consumes one unit at every visited
    customer, independently of delivery quantity. z activates one depot tour.
    """
    _validate_instance(i)
    n, horizon = int(i.n), int(i.horizon)
    nodes = n + 1
    at = 0

    def allocate(shape):
        nonlocal at
        size = int(np.prod(shape))
        result = np.arange(at, at + size, dtype=np.int64).reshape(shape)
        at += size
        return result

    y, q = allocate((horizon, n)), allocate((horizon, n))
    inventory, z = allocate((horizon, nodes)), allocate((horizon,))
    pairs = [(u, v) for u in range(nodes) for v in range(nodes) if u != v]
    x_array, f_array = allocate((horizon, len(pairs))), allocate((horizon, len(pairs)))
    x = {(p, u, v): int(x_array[p, a]) for p in range(horizon) for a, (u, v) in enumerate(pairs)}
    flow = {(p, u, v): int(f_array[p, a]) for p in range(horizon) for a, (u, v) in enumerate(pairs)}
    objective, lower, upper = np.zeros(at), np.zeros(at), np.full(at, np.inf)
    integrality = np.zeros(at, dtype=np.uint8)
    for columns in (y, z, x_array):
        upper[columns] = 1.
        integrality[columns] = 1
    upper[q] = np.minimum(np.asarray(i.maximum), i.capacity)
    lower[inventory[:, 1:]] = np.asarray(i.minimum)
    upper[inventory[:, 1:]] = np.asarray(i.maximum)
    upper[inventory[:, 0]] = i.supplier_initial + np.cumsum(i.production)
    upper[f_array] = n
    objective[y] = np.asarray(i.service)
    objective[inventory[:, 0]] = i.supplier_holding
    objective[inventory[:, 1:]] = np.asarray(i.holding)
    mean = np.mean(np.asarray(i.travel, dtype=float), axis=2)
    row_index, col_index, values, row_lower, row_upper, row_names = [], [], [], [], [], []

    def add(name, coefficients, lo=-np.inf, hi=np.inf):
        row = len(row_lower)
        for column, value in coefficients.items():
            if value:
                row_index.append(row)
                col_index.append(int(column))
                values.append(float(value))
        row_lower.append(float(lo))
        row_upper.append(float(hi))
        row_names.append(name)

    for p in range(horizon):
        depot_balance = {int(inventory[p, 0]): 1., **{int(j): 1. for j in q[p]}}
        if p:
            depot_balance[int(inventory[p - 1, 0])] = -1.
        rhs = i.production[p] + (i.supplier_initial if p == 0 else 0.)
        add(("supplier_balance", p), depot_balance, rhs, rhs)
        add(("vehicle_load", p), {int(j): 1. for j in q[p]}, hi=i.capacity)
        outgoing = {x[p, 0, v]: 1. for v in range(1, nodes)}
        incoming = {x[p, u, 0]: 1. for u in range(1, nodes)}
        add(("depot_out", p), {**outgoing, int(z[p]): -1.}, 0., 0.)
        add(("depot_in", p), {**incoming, int(z[p]): -1.}, 0., 0.)
        add(("nonempty_tour", p), {int(z[p]): -1., **{int(k): 1. for k in y[p]}}, lo=0.)
        depot_flow = {flow[p, 0, v]: 1. for v in range(1, nodes)}
        depot_flow.update({int(k): -1. for k in y[p]})
        add(("flow_supply", p), depot_flow, 0., 0.)
        duration = {int(y[p, k]): i.service[k] for k in range(n)}
        for u, v in pairs:
            objective[x[p, u, v]] = mean[u, v]
            duration[x[p, u, v]] = mean[u, v]
            add(("flow_arc", p, u, v), {flow[p, u, v]: 1., x[p, u, v]: -n}, hi=0.)
            if v == 0:
                upper[flow[p, u, v]] = 0.
        add(("static_return_cutoff", p), duration, hi=i.deadline)
        for k in range(n):
            v = k + 1
            add(("customer_in", p, k), {**{x[p, u, v]: 1. for u in range(nodes) if u != v},
                                      int(y[p, k]): -1.}, 0., 0.)
            add(("customer_out", p, k), {**{x[p, v, u]: 1. for u in range(nodes) if u != v},
                                       int(y[p, k]): -1.}, 0., 0.)
            consume = {flow[p, u, v]: 1. for u in range(nodes) if u != v}
            consume.update({flow[p, v, u]: -1. for u in range(nodes) if u != v})
            consume[int(y[p, k])] = -1.
            add(("flow_consume", p, k), consume, 0., 0.)
            balance = {int(inventory[p, v]): 1., int(q[p, k]): -1.}
            if p:
                balance[int(inventory[p - 1, v])] = -1.
            rhs = -i.demand[p, k] + (i.initial[k] if p == 0 else 0.)
            add(("customer_balance", p, k), balance, rhs, rhs)
            storage = {int(q[p, k]): 1.}
            if p:
                storage[int(inventory[p - 1, v])] = 1.
            add(("ML_pre_demand_storage", p, k), storage,
                hi=i.maximum[k] - (i.initial[k] if p == 0 else 0.))
            add(("delivery_visit", p, k), {int(q[p, k]): 1., int(y[p, k]): -upper[q[p, k]]}, hi=0.)
    matrix = coo_matrix((values, (row_index, col_index)), shape=(len(row_lower), at)).tocsc()
    return {"objective": objective, "lower": lower, "upper": upper,
            "integrality": integrality, "matrix": matrix,
            "row_lower": np.asarray(row_lower), "row_upper": np.asarray(row_upper),
            "row_names": row_names, "y": y, "q": q, "inventory": inventory,
            "z": z, "x": x, "flow": flow, "arc_pairs": pairs,
            "mean_travel": mean, "variables": at, "constraints": len(row_lower),
            "contract": STATIC_CONTRACT}


def check_vector(model, vector, tolerance=TOL):
    """Check every bound, row and declared integer variable, independently of HiGHS."""
    value = np.asarray(vector, dtype=float)
    if value.shape != model["objective"].shape or not np.isfinite(value).all():
        return {"checked": False, "reason": "invalid_vector"}
    activity = model["matrix"] @ value
    bounds = max(float(np.max(model["lower"] - value, initial=0.)),
                 float(np.max(value - model["upper"], initial=0.)))
    rows = max(float(np.max(model["row_lower"] - activity, initial=0.)),
               float(np.max(activity - model["row_upper"], initial=0.)))
    integer = value[model["integrality"].astype(bool)]
    error = float(np.max(np.abs(integer - np.rint(integer)), initial=0.))
    return {"checked": max(bounds, rows, error) <= tolerance,
            "maximum_bound_violation": bounds, "maximum_row_violation": rows,
            "maximum_integrality_violation": error,
            "proxy_objective": float(model["objective"] @ value)}


def encode_plan(i, model, record):
    """Encode a complete plan, including zero-q visits, and reject any residual."""
    routes = record["routes"]
    q = np.asarray(record["quantities"], dtype=float)
    if len(routes) != i.horizon or q.shape != (i.horizon, i.n) or not np.isfinite(q).all():
        raise ValueError("Complete finite plan required")
    if np.max(np.abs(q - np.rint(q)), initial=0.) > DELIVERY_TOL:
        raise ValueError("Delivery recovery is nonintegral")
    q = np.rint(q)
    value = np.zeros(model["variables"])
    value[model["q"]] = q
    stocks = np.r_[i.supplier_initial, np.asarray(i.initial, dtype=float)]
    for p, route in enumerate(routes):
        if (any(isinstance(k, (bool, np.bool_)) or not isinstance(k, (int, np.integer))
                or k < 0 or k >= i.n for k in route) or len(set(route)) != len(route)):
            raise ValueError("Invalid elementary customer route")
        value[model["z"][p]] = bool(route)
        path = [0] + [int(k) + 1 for k in route] + [0]
        for j, k in enumerate(route):
            value[model["y"][p, k]] = 1.
            value[model["x"][p, path[j], path[j + 1]]] = 1.
            value[model["flow"][p, path[j], path[j + 1]]] = len(route) - j
        if route:
            value[model["x"][p, path[-2], 0]] = 1.
        stocks = stocks.copy()
        stocks[0] += i.production[p] - np.sum(q[p])
        stocks[1:] += q[p] - i.demand[p]
        value[model["inventory"][p]] = stocks
    checked = check_vector(model, value)
    if not checked["checked"]:
        raise ValueError("Plan is not static-feasible: " + str(checked))
    return value


def _decode(i, model, vector):
    checked = check_vector(model, vector)
    if not checked["checked"]:
        raise ValueError("Solver vector fails full static residual check: " + str(checked))
    q = np.asarray(vector)[model["q"]]
    if np.max(np.abs(q - np.rint(q)), initial=0.) > DELIVERY_TOL:
        raise ValueError("Continuous delivery solution is not integrally recoverable")
    routes = []
    for p in range(i.horizon):
        arcs = [(u, v) for u, v in model["arc_pairs"] if vector[model["x"][p, u, v]] > .5]
        successor = dict(arcs)
        route, current, seen = [], 0, set()
        while current in successor:
            current = successor[current]
            if current == 0:
                break
            if current in seen or len(route) >= i.n:
                raise ValueError("Disconnected or cyclic decoded route")
            seen.add(current)
            route.append(current - 1)
        if len(arcs) != (len(route) + 1 if route else 0) or (route and current != 0):
            raise ValueError("Decoded route does not cover all selected arcs")
        routes.append(route)
    record = {"routes": routes, "quantities": np.rint(q).astype(int).tolist()}
    recovered = encode_plan(i, model, record)
    objective = float(model["objective"] @ recovered)
    if abs(objective - checked["proxy_objective"]) > 1e-6:
        raise ValueError("Integral recovery changes static objective")
    return {**record, "proxy_objective": objective, "verification": check_vector(model, recovered)}


def solve_static(i, initial, deadline, seed):
    """Solve a warm-started full static IRP; return only fully checked plans.

    A rejected/nonstatic-feasible start is recorded and never repaired here.
    A verified static start may be retained if no better solver plan is usable.
    A native accepted setSolution call records API acceptance, not a promise
    that HiGHS used that incumbent internally. No bound applies to FIFO costs.
    """
    started = time.perf_counter()
    from scipy.optimize._highspy import _core as high
    if not math.isfinite(deadline):
        raise ValueError("Finite absolute deadline required")
    diag = {"backend": "scipy.optimize._highspy._core._Highs", "backend_version": None,
            "seed_submitted": False, "seed_accepted": False, "warm_start_static_feasible": False,
            "bound_scope": "static_proxy_only", "contract": STATIC_CONTRACT}
    output = {"success": False, "status": "deadline_before_model", "diag": diag,
              "static_bound": None, "static_gap": None, "routes": None, "quantities": None,
              "proxy_objective": None}

    def finish():
        output["objective"] = output["static_objective"] = output["proxy_objective"]
        output["diagnostics"] = diag
        diag.update(status=output["status"], lower_bound=output["static_bound"],
                    gap=output["static_gap"], elapsed_seconds=time.perf_counter() - started,
                    completed_before_deadline=time.perf_counter() <= deadline)
        return output

    if time.perf_counter() >= deadline:
        return finish()
    model = build_static_model(i)
    diag.update(variables=model["variables"], constraints=model["constraints"])
    incumbent = None
    if initial is not None:
        try:
            encoded = encode_plan(i, model, initial)
            incumbent = _decode(i, model, encoded)
            diag["warm_start_static_feasible"] = True
        except (ValueError, KeyError, TypeError, IndexError) as exc:
            diag["warm_start_rejection"] = str(exc)
    remaining = deadline - time.perf_counter() - .03
    if remaining <= 0:
        output["status"] = "deadline_after_model"
        if incumbent is not None:
            output.update(incumbent, success=True)
        return finish()
    solver = high._Highs()
    diag["backend_version"] = solver.version()

    def accepted(status, what):
        if status != high.HighsStatus.kOk:
            raise RuntimeError(what + ": " + str(status))

    for name, value in (("output_flag", False), ("threads", 1), ("random_seed", int(seed) % 2147483647),
                        ("mip_rel_gap", 0.), ("mip_abs_gap", 0.), ("mip_feasibility_tolerance", TOL)):
        accepted(solver.setOptionValue(name, value), "HiGHS option " + name)
    lp = high.HighsLp()
    lp.num_col_, lp.num_row_ = model["variables"], model["constraints"]
    lp.col_cost_, lp.col_lower_, lp.col_upper_ = model["objective"], model["lower"], model["upper"]
    lp.row_lower_, lp.row_upper_ = model["row_lower"], model["row_upper"]
    lp.integrality_ = [high.HighsVarType.kInteger if v else high.HighsVarType.kContinuous for v in model["integrality"]]
    matrix = model["matrix"]
    lp.a_matrix_.format_ = high.MatrixFormat.kColwise
    lp.a_matrix_.num_col_, lp.a_matrix_.num_row_ = matrix.shape[1], matrix.shape[0]
    lp.a_matrix_.start_ = np.asarray(matrix.indptr, dtype=np.int32)
    lp.a_matrix_.index_ = np.asarray(matrix.indices, dtype=np.int32)
    lp.a_matrix_.value_ = matrix.data
    accepted(solver.passModel(lp), "HiGHS model submission")
    if incumbent is not None:
        start = high.HighsSolution()
        start.col_value = encoded
        start.value_valid = True
        diag["seed_submitted"] = True
        status = solver.setSolution(start)
        diag["seed_submission_status"] = str(status)
        diag["seed_accepted"] = status == high.HighsStatus.kOk
    remaining = deadline - time.perf_counter() - .03
    if remaining > 0:
        accepted(solver.setOptionValue("time_limit", float(remaining)), "HiGHS time limit")
        run_status = solver.run()
        model_status = solver.getModelStatus()
        output["status"] = str(model_status).split(".")[-1]
        diag["run_status"] = str(run_status)
        diag["backend_model_status"] = str(model_status)
        info, solution = solver.getInfo(), solver.getSolution()
        diag["mip_node_count"] = int(info.mip_node_count)
        bound = float(info.mip_dual_bound)
        if info.valid and math.isfinite(bound):
            output["static_bound"] = bound
        if solution.value_valid:
            try:
                candidate = _decode(i, model, solution.col_value)
                if incumbent is None or candidate["proxy_objective"] < incumbent["proxy_objective"]:
                    incumbent = candidate
                    diag["selected_plan_source"] = "native_solver"
            except (ValueError, TypeError, IndexError) as exc:
                diag["solver_plan_rejection"] = str(exc)
    else:
        output["status"] = "deadline_before_native_run"
    if incumbent is not None:
        output.update(incumbent, success=True)
        diag.setdefault("selected_plan_source", "retained_static_feasible_warm_start")
        bound = output["static_bound"]
        if bound is not None:
            if bound > incumbent["proxy_objective"] + 1e-6:
                raise RuntimeError("Static dual bound exceeds verified feasible static objective")
            output["static_gap"] = max(0., incumbent["proxy_objective"] - bound) / max(abs(incumbent["proxy_objective"]), 1e-10)
    return finish()
