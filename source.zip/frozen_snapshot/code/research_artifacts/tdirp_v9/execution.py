"""Full-workflow comparison cold-worker adapter with deadline receipts and Windows process-tree limits.

The public entry point is run_one(case, method, seed, initial, folder, budget,
reserve=3, memory=1024).  No optimizer executes in the parent process.
"""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import traceback
import uuid

BASE = Path(__file__).resolve().parent
ART = BASE.parent
CONTRACT = "completion_c1_endholding_nowait_ML_header_v1"
METHODS = ("joint_dp_polish", "two_stage_irp_fifo")
THREAD_ENV = {name: "1" for name in
              ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
               "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")}
SAMPLE_SECONDS = .1


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def source_paths(method=None):
    """Frozen Python/native closure; build completes before any search worker."""
    paths = [ART / "tdirp_v5/operators.py", ART / "tdirp_v5/matched_extension.py",
             ART / "tdirp_v3/joint_repair.py", ART / "tdirp_v3/frozen_start.py",
             ART / "tdirp_newalgo/schedule_repair.py", ART / "tdirp_newalgo/routing_initializer.py",
             ART / "tdirp_followup/matched_study.py", ART / "tdirp_v7/static_operators.py"]
    paths += sorted((ART / "tdirp_math_audit").glob("*.py"))
    paths += sorted((ART / "tdirp_v8").glob("*.py"))
    paths += sorted(BASE.glob("*.py")) + sorted(BASE.glob("*.cpp"))
    from fifo_tsp import native_source_paths
    paths += native_source_paths()
    return sorted(set(path.resolve() for path in paths if path.is_file()))


def _finite_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def checkpoint_rejections(result, receipt, identity, initial_record, budget,
                          observed_elapsed, actual_digest):
    """Pure eligibility logic. Publication must have been observed by deadline."""
    rejected = []
    if not isinstance(result, dict) or not isinstance(receipt, dict):
        return ["non_object_checkpoint_or_receipt"]
    if receipt.get("result_sha256") != actual_digest:
        rejected.append("receipt_digest_mismatch")
    for key, expected in identity.items():
        if result.get(key) != expected:
            rejected.append("identity_mismatch:" + key)
    completed = receipt.get("checkpoint_completed_elapsed_since_parent")
    if not _finite_number(completed) or not 0 <= completed <= budget:
        rejected.append("receipt_outside_budget")
    if not _finite_number(observed_elapsed) or not 0 <= observed_elapsed <= budget:
        rejected.append("publication_not_observed_within_budget")
    value = result.get("objective")
    check = result.get("independent_verification")
    if not _finite_number(value):
        rejected.append("nonfinite_objective")
    elif value > initial_record["objective"] + 1e-7:
        rejected.append("worse_than_retained_common_start")
    if not isinstance(check, dict) or check.get("checked") is not True:
        rejected.append("unverified_checkpoint")
    else:
        checked_value = check.get("objective_decimal")
        if (not _finite_number(checked_value) or not _finite_number(value)
                or abs(value - checked_value) > 1e-7):
            rejected.append("verification_objective_mismatch")
        if check.get("routes") != result.get("routes") or check.get("quantities") != result.get("quantities"):
            rejected.append("verification_plan_mismatch")
    if result.get("contract") != CONTRACT or result.get("objective_definition") != "completion":
        rejected.append("objective_contract_mismatch")
    return rejected


def select_endpoint(parsed, initial_record):
    """Choose an eligible incumbent; late/broken publications cannot erase it."""
    eligible = [(path, entry) for path, entry in parsed.items() if not entry["rejections"]]
    chosen = min(eligible, key=lambda item: (item[1]["result"]["objective"],
                                            -item[1]["result"].get("publication_sequence", 0))) if eligible else None
    objective = float(chosen[1]["result"]["objective"]) if chosen else float(initial_record["objective"])
    return chosen, objective


class WindowsJob:
    """One kill-on-close job; descendants inherit membership automatically."""

    def __init__(self):
        if os.name != "nt":
            raise RuntimeError("Windows native process-tree monitor required")
        self.api = ctypes.WinDLL("kernel32", use_last_error=True)
        self.psapi = ctypes.WinDLL("psapi", use_last_error=True)
        self.api.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        self.api.CreateJobObjectW.restype = wintypes.HANDLE
        self.api.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.api.QueryInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                                       wintypes.DWORD, ctypes.c_void_p]
        self.api.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        self.api.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        self.api.CloseHandle.argtypes = [wintypes.HANDLE]
        self.api.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.api.OpenProcess.restype = wintypes.HANDLE

        class BasicLimits(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                        ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD),
                        ("SchedulingClass", wintypes.DWORD)]

        class IoCounters(ctypes.Structure):
            _fields_ = [(name, ctypes.c_uint64) for name in
                        ("ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                         "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

        class ExtendedLimits(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", BasicLimits), ("IoInfo", IoCounters),
                        ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                        ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]

        class Accounting(ctypes.Structure):
            _fields_ = [(name, ctypes.c_int64) for name in
                        ("TotalUserTime", "TotalKernelTime", "ThisPeriodTotalUserTime", "ThisPeriodTotalKernelTime")]
            _fields_ += [(name, wintypes.DWORD) for name in
                         ("TotalPageFaultCount", "TotalProcesses", "ActiveProcesses", "TotalTerminatedProcesses")]

        class Memory(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)]
            _fields_ += [(name, ctypes.c_size_t) for name in
                         ("PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
                          "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage",
                          "PagefileUsage", "PeakPagefileUsage", "PrivateUsage")]

        self.ExtendedLimits, self.Accounting, self.Memory = ExtendedLimits, Accounting, Memory
        self.psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Memory), wintypes.DWORD]
        self.handle = self.api.CreateJobObjectW(None, None)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        limits = ExtendedLimits()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not self.api.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
            self.close()
            raise ctypes.WinError(ctypes.get_last_error())

    def attach(self, process):
        if not self.api.AssignProcessToJobObject(self.handle, wintypes.HANDLE(int(process._handle))):
            raise ctypes.WinError(ctypes.get_last_error())

    def _query(self, code, record):
        if not self.api.QueryInformationJobObject(self.handle, code, ctypes.byref(record), ctypes.sizeof(record), None):
            raise ctypes.WinError(ctypes.get_last_error())
        return record

    def process_ids(self):
        capacity = 32
        while capacity <= 65536:
            class ProcessIds(ctypes.Structure):
                _fields_ = [("assigned", wintypes.DWORD), ("count", wintypes.DWORD),
                            ("ids", ctypes.c_size_t * capacity)]
            record = ProcessIds()
            if self.api.QueryInformationJobObject(self.handle, 3, ctypes.byref(record), ctypes.sizeof(record), None):
                return [int(record.ids[j]) for j in range(record.count)]
            if ctypes.get_last_error() != 234:  # ERROR_MORE_DATA
                raise ctypes.WinError(ctypes.get_last_error())
            capacity *= 2
        raise RuntimeError("Unexpected process-tree size")

    def sample(self):
        accounting = self._query(1, self.Accounting())
        limits = self._query(9, self.ExtendedLimits())
        rss = private = 0
        processes = []
        for pid in self.process_ids():
            handle = self.api.OpenProcess(0x400 | 0x10, False, pid)
            if not handle:
                if ctypes.get_last_error() == 87:  # process exited between queries
                    continue
                raise ctypes.WinError(ctypes.get_last_error())
            try:
                counter = self.Memory()
                counter.cb = ctypes.sizeof(counter)
                if not self.psapi.GetProcessMemoryInfo(handle, ctypes.byref(counter), counter.cb):
                    if pid not in self.process_ids():
                        continue
                    raise ctypes.WinError(ctypes.get_last_error())
                rss += counter.WorkingSetSize
                private += counter.PrivateUsage
                processes.append({"pid": pid, "resident_bytes": int(counter.WorkingSetSize),
                                  "peak_process_resident_bytes": int(counter.PeakWorkingSetSize),
                                  "private_commit_bytes": int(counter.PrivateUsage)})
            finally:
                self.api.CloseHandle(handle)
        return {"resident_bytes": int(rss), "private_commit_bytes": int(private),
                "cpu_user_seconds": accounting.TotalUserTime / 1e7,
                "cpu_kernel_seconds": accounting.TotalKernelTime / 1e7,
                "total_processes": int(accounting.TotalProcesses),
                "active_processes": int(accounting.ActiveProcesses),
                "os_peak_job_private_commit_bytes": int(limits.PeakJobMemoryUsed),
                "processes": processes}

    def terminate(self):
        if self.handle and not self.api.TerminateJobObject(self.handle, 1):
            raise ctypes.WinError(ctypes.get_last_error())

    def close(self):
        if getattr(self, "handle", None):
            self.api.CloseHandle(self.handle)
            self.handle = None


def _load_optimizer(method):
    if method == "joint_dp_polish":
        path = ART / "tdirp_v5/operators.py"
    elif method == "two_stage_irp_fifo":
        path = BASE / "two_stage.py"
    else:
        raise ValueError("Unsupported method: " + method)
    spec = importlib.util.spec_from_file_location("_full_workflow_execution_optimizer", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.optimize


def require_method_available(method):
    if method not in METHODS:
        raise ValueError("Unsupported full-workflow comparison method")
    from fifo_tsp import executable_path
    if not executable_path().is_file():
        raise RuntimeError("Prebuild the owned FIFO-TSP executable before preparation; no timed worker compiles code")


def worker(args):
    started = time.perf_counter()
    # No scientific imports or descendants before parent successfully attaches job.
    while not Path(args.gate).exists():
        if time.perf_counter() >= args.parent_start + args.wall:
            raise TimeoutError("Parent launch gate did not open within budget")
        time.sleep(.005)
    for name in ("tdirp_followup", "tdirp_v3", "tdirp_newalgo", "tdirp_math_audit"):
        sys.path.insert(0, str(ART / name))
    import model_probe
    import frozen_start
    model_probe.ARCHIVE = frozen_start.ARCHIVE = Path(args.archive)
    from frozen_start import read_instance, validate_plan, commit_checkpoint
    from schedule_repair import verify_routes
    initial = json.loads(Path(args.initial).read_text(encoding="utf-8"))
    if sha(args.initial) != args.initial_sha256:
        raise ValueError("Initial payload changed after parent launch")
    manifest = json.loads(Path(args.source_manifest).read_text(encoding="utf-8"))
    for path, digest in manifest.items():
        if sha(path) != digest:
            raise ValueError("Source changed after parent launch: " + path)
    instance = read_instance(args.case)
    verification = validate_plan(instance, initial)
    import numpy
    import scipy
    import scipy.optimize._highspy._core as highs
    software = {"python": sys.version, "python_executable": sys.executable,
                "numpy": numpy.__version__, "scipy": scipy.__version__,
                "highs": ".".join(str(getattr(highs, "HIGHS_VERSION_" + v))
                                  for v in ("MAJOR", "MINOR", "PATCH")),
                "platform": platform.platform()}
    common = {"input": args.case, "method": args.method, "seed": args.seed,
              "run_id": args.run_id, "attempt_id": args.attempt_id,
              "initial_plan_sha256": initial["plan_sha256"],
              "expected_initial_sha256": initial["plan_sha256"],
              "initial_payload_sha256": args.initial_sha256,
              "initial_routes": initial["routes"], "initial_quantities": initial["quantities"],
              "initial_objective": initial["objective"], "initial_identity_checked": True,
              "offline_initialization_wall_seconds": initial["offline_initialization_wall_seconds"],
              "contract": CONTRACT, "objective_definition": "completion",
              "global_bound": None, "global_gap": None,
              "source_hashes": manifest, "software": software}
    sequence = 0
    last_verified_plan = None
    last_verified_value = None

    def publish(record):
        nonlocal sequence, last_verified_plan, last_verified_value
        # Identical verified incumbents need no repeated journal publication.
        # Every distinct plan and all initialized/final states are still checked.
        signature = json.dumps({"routes": record.get("routes"),
                                "quantities": record.get("quantities")},
                               sort_keys=True, separators=(",", ":"), allow_nan=False)
        if (record.get("status") == "searching" and signature == last_verified_plan
                and record.get("objective") == last_verified_value):
            return
        # Verify the literal original FIFO model independently of optimizer claims.
        checked = verify_routes(instance, record["routes"], record["quantities"], "completion")
        if checked.get("checked") is not True:
            raise ValueError("Published candidate failed literal FIFO verification")
        if (not _finite_number(record.get("objective"))
                or abs(record["objective"] - checked["objective_decimal"]) > 1e-7
                or checked["objective_decimal"] > initial["objective"] + 1e-7):
            raise ValueError("Published candidate has inconsistent or degraded objective")
        result = {**record, **common, "independent_verification": checked,
                  "routes": checked["routes"], "quantities": checked["quantities"],
                  "worker_wall_seconds_including_imports": time.perf_counter() - started,
                  "checkpoint_verified_elapsed_since_parent": time.perf_counter() - args.parent_start,
                  "publication_sequence": sequence}
        path = Path(args.journal) / f"checkpoint_{sequence:08d}.json"
        commit_checkpoint(path, result, args.parent_start)
        last_verified_plan = signature
        last_verified_value = checked["objective_decimal"]
        sequence += 1

    publish({"status": "initialized", "objective": initial["objective"],
             "routes": initial["routes"], "quantities": initial["quantities"],
             "independent_verification": verification})
    optimize = _load_optimizer(args.method)
    result = optimize(instance, initial, args.method, args.seed,
                      deadline=args.parent_start + args.wall - args.reserve, publish=publish)
    publish(result)


def run_one(case, method, seed, initial, folder, budget, reserve=3, memory=1024, archive=None):
    """Run one sequential cold worker; all operational failures return a row.

    Caller must supply the same preverified frozen full start to every method.
    Invalid call configuration raises before attempting a worker. Worker launch,
    monitoring, malformed result and deadline failures are retained in the row.
    """
    if method not in METHODS:
        raise ValueError("Unsupported method: " + str(method))
    require_method_available(method)
    if (not _finite_number(budget) or not _finite_number(reserve)
            or not _finite_number(memory) or budget <= 0 or not 0 <= reserve < budget or memory <= 0):
        raise ValueError("Require budget > reserve >= 0 and memory > 0")
    archive = Path(archive or os.environ.get("TDIRP_ARCHIVE", ART.parent / "data/Benchmark.zip")).resolve()
    if not archive.is_file():
        raise ValueError("Benchmark archive missing; run download_data.py or supply --archive")
    initial, folder = Path(initial).resolve(), Path(folder).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    attempt_id = uuid.uuid4().hex
    stem = re.sub(r"[^A-Za-z0-9_.-]", "_", str(case).removesuffix(".txt"))
    stem += f"_{method}_{seed}_{attempt_id[:12]}"
    journal = folder / (stem + "_checkpoints")
    journal.mkdir()
    output, logpath = folder / (stem + ".json"), folder / (stem + ".log")
    initial_record = json.loads(initial.read_text(encoding="utf-8"))
    if (initial_record.get("input") != case or initial_record.get("contract") != CONTRACT
            or initial_record.get("objective_definition") != "completion"
            or initial_record.get("success") is not True
            or not _finite_number(initial_record.get("objective"))):
        raise ValueError("Expected successful frozen common start under the required contract")
    payload_hash = sha(initial)
    hashes = {str(p): sha(p) for p in source_paths(method)}
    source_manifest = folder / (stem + ".sources.json")
    atomic(source_manifest, hashes)
    identity = {"input": case, "method": method, "seed": seed, "run_id": folder.name,
                "attempt_id": attempt_id, "initial_plan_sha256": initial_record["plan_sha256"],
                "expected_initial_sha256": initial_record["plan_sha256"],
                "initial_payload_sha256": payload_hash, "source_hashes": hashes,
                "initial_identity_checked": True}
    gate = folder / (stem + ".gate")
    command = [sys.executable, "-B", str(Path(__file__).resolve()), "--worker",
               "--case", case, "--method", method, "--seed", str(seed),
               "--initial", str(initial), "--initial-sha256", payload_hash,
               "--journal", str(journal), "--run-id", folder.name,
               "--attempt-id", attempt_id, "--source-manifest", str(source_manifest),
               "--gate", str(gate), "--wall", str(budget), "--reserve", str(reserve)]
    command += ["--archive", str(archive)]
    env = dict(os.environ, PYTHONIOENCODING="utf-8", **THREAD_ENV)
    start = time.perf_counter()
    command += ["--parent-start", str(start)]
    process = job = None
    attached = False
    reason = error = None
    observed = {}
    parsed = {}
    samples = []
    pid_peaks = {}
    peaks = {"resident_bytes": 0, "private_commit_bytes": 0,
             "os_peak_job_private_commit_bytes": 0, "total_processes": 0}
    cpu_user = cpu_kernel = 0.
    monitor_ok = True

    def collect_checkpoints():
        for receipt_path in journal.glob("checkpoint_*.commit.json"):
            if str(receipt_path) in observed:
                continue
            candidate = receipt_path.with_name(receipt_path.name.removesuffix(".commit.json") + ".json")
            try:
                payload = candidate.read_bytes()
                result = json.loads(payload)
                receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
                elapsed = time.perf_counter() - start
                observed[str(receipt_path)] = elapsed
                rejects = checkpoint_rejections(result, receipt, identity, initial_record,
                                                 budget, elapsed, hashlib.sha256(payload).hexdigest())
                parsed[str(candidate)] = {"result": result, "receipt": receipt,
                                           "observed_elapsed": elapsed, "rejections": rejects}
            except (OSError, ValueError, TypeError, KeyError) as exc:
                # Incomplete pairs may finish on the next watchdog sample.
                parsed[str(candidate)] = {"rejections": ["checkpoint_parse_error:" + str(exc)]}

    try:
        with logpath.open("w", encoding="utf-8") as log:
            job = WindowsJob()
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                       env=env, cwd=str(BASE.parents[1]),
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            job.attach(process)
            attached = True
            atomic(gate, {"attached_to_job": True})
            while True:
                try:
                    info = job.sample()
                except Exception:
                    if process.poll() is None:
                        monitor_ok = False
                        reason = "process_tree_monitor_unavailable"
                        raise
                    info = None
                if info is not None:
                    cpu_user, cpu_kernel = info["cpu_user_seconds"], info["cpu_kernel_seconds"]
                    for key in peaks:
                        peaks[key] = max(peaks[key], info[key])
                    for item in info["processes"]:
                        prior = pid_peaks.setdefault(str(item["pid"]), {"observed_peak_resident_bytes": 0,
                                                                       "os_peak_process_resident_bytes": 0})
                        prior["observed_peak_resident_bytes"] = max(prior["observed_peak_resident_bytes"], item["resident_bytes"])
                        prior["os_peak_process_resident_bytes"] = max(prior["os_peak_process_resident_bytes"], item["peak_process_resident_bytes"])
                    samples.append({"elapsed_seconds": time.perf_counter() - start, **info})
                    if info["resident_bytes"] > memory * 1024 ** 2:
                        reason = "resident_memory_limit"
                collect_checkpoints()
                alive = process.poll() is None
                if not alive:
                    if time.perf_counter() > start + budget and reason is None:
                        reason = "normal_exit_observed_after_wall_budget"
                    break
                if reason or time.perf_counter() >= start + budget:
                    reason = reason or "wall_time_limit"
                    job.terminate()
                    break
                time.sleep(min(SAMPLE_SECONDS, max(0., start + budget - time.perf_counter())))
            process.wait(timeout=10.)
            collect_checkpoints()
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        reason = reason or ("worker_launch_or_job_failure" if process is None or job is None else "execution_harness_error")
        if process is not None and process.poll() is None:
            if job is not None and attached:
                try:
                    job.terminate()
                except Exception:
                    process.kill()
            else:
                process.kill()
            try:
                process.wait(timeout=10.)
            except Exception:
                pass
        collect_checkpoints()
    finally:
        if job is not None:
            try:
                final = job.sample()
                cpu_user, cpu_kernel = final["cpu_user_seconds"], final["cpu_kernel_seconds"]
                for key in peaks:
                    peaks[key] = max(peaks[key], final[key])
                # Native descendants must never outlive the worker, even on success.
                if final["active_processes"]:
                    reason = reason or "descendants_remaining_after_worker_exit"
                    job.terminate()
            except Exception as exc:
                monitor_ok = False
                error = error or f"final_accounting:{type(exc).__name__}: {exc}"
            job.close()
    wall_seconds = time.perf_counter() - start
    chosen, endpoint = select_endpoint(parsed, initial_record)
    result = chosen[1]["result"] if chosen else {}
    telemetry_path = folder / (stem + ".telemetry.json")
    atomic(telemetry_path, {"sampling_seconds": SAMPLE_SECONDS, "samples": samples, "pid_peaks": pid_peaks})
    row = {"input": case, "method": method, "seed": seed, "run_id": folder.name,
           "attempt_id": attempt_id, "created_utc": datetime.now(timezone.utc).isoformat(),
           "result": result, "external_stop": reason,
           "worker_exit_code": None if process is None else process.returncode,
           "execution_error": error, "full_worker_wall_seconds": wall_seconds,
           "wall_budget_seconds": budget, "finalization_reserve_seconds": reserve,
           "memory_limit_mib": memory, "threads": 1, "thread_environment": THREAD_ENV,
           "offline_initialization_seconds": initial_record["offline_initialization_wall_seconds"],
           "observed_peak_resident_bytes": peaks["resident_bytes"],
           "observed_peak_private_commit_bytes": peaks["private_commit_bytes"],
           "os_peak_job_private_commit_bytes": peaks["os_peak_job_private_commit_bytes"],
           "tree_cpu_user_seconds": cpu_user, "tree_cpu_kernel_seconds": cpu_kernel,
           "tree_cpu_seconds": cpu_user + cpu_kernel, "tree_total_processes": peaks["total_processes"],
           "process_tree_monitor_available": monitor_ok, "parent_start_perf_counter": start,
           "absolute_parent_deadline_perf_counter": start + budget,
           "absolute_search_deadline_perf_counter": start + budget - reserve,
           "checkpoint_receipt": chosen[1]["receipt"] if chosen else {},
           "checkpoint_receipt_matches": bool(chosen),
           "checkpoint_completed_within_budget": bool(chosen),
           "checkpoint_publication_observed_elapsed_seconds": chosen[1]["observed_elapsed"] if chosen else None,
           "endpoint_eligible": bool(chosen), "endpoint_objective": endpoint,
           "fallback_to_common_start": not bool(chosen),
           "retained_common_start_objective": initial_record["objective"],
           "retained_common_start_routes": initial_record["routes"],
           "retained_common_start_quantities": initial_record["quantities"],
           "initial_plan_sha256": initial_record["plan_sha256"], "initial_payload_sha256": payload_hash,
           "checkpoint_audit": [{"file": path, "rejections": entry["rejections"],
                                  "observed_elapsed_seconds": entry.get("observed_elapsed")}
                                 for path, entry in parsed.items()],
           "result_file": str(output), "worker_checkpoint_file": chosen[0] if chosen else None,
           "log_file": str(logpath), "initial_file": str(initial), "telemetry_file": str(telemetry_path),
           "checkpoint_folder": str(journal), "source_manifest_file": str(source_manifest),
           "source_hashes": hashes, "command": command,
           "parent_software": {"python": sys.version, "platform": platform.platform()},
           "publication_policy": "distinct plans plus initialized/final states; unchanged verified searching states suppressed",
           "observed_max_sampling_gap_seconds": max((b["elapsed_seconds"]-a["elapsed_seconds"] for a,b in zip(samples,samples[1:])), default=0.),
           "enforcement": "Windows Job Object kill-on-close, aggregate simultaneous sampled tree RSS; "
                          "all descendant CPU included by OS job accounting; 0.1s watchdog may overshoot; "
                          "eligible immutable receipt must be observed by absolute parent deadline"}
    if process is not None and process.returncode and reason is None:
        row["failure"] = "worker_error"
    if error:
        row["failure"] = "execution_error"
    atomic(output, row)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--case")
    parser.add_argument("--method", choices=METHODS)
    parser.add_argument("--seed", type=int)
    for key in ("initial", "initial-sha256", "journal", "run-id", "attempt-id", "source-manifest", "gate"):
        parser.add_argument("--" + key)
    parser.add_argument("--parent-start", type=float)
    parser.add_argument("--wall", type=float)
    parser.add_argument("--reserve", type=float, default=3.)
    parser.add_argument("--archive", required=True)
    args = parser.parse_args()
    if not args.worker:
        parser.error("Use the run_one Python interface; no experiment cohort is launched by this module")
    try:
        worker(args)
    except Exception:
        traceback.print_exc()
        raise


if __name__ == "__main__":
    main()
