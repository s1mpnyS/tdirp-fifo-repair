"""Predeclared full-workflow comparison; no retries or historical pooling."""
from __future__ import annotations

import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import random
import shutil
import sys
import zipfile

BASE = Path(__file__).resolve().parent
CODE = BASE.parent.parent
for variable in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
sys.path.insert(0,str(BASE))
import execution
METHODS = execution.METHODS

CASES = ("H6/inst_15_12_2.txt","H6/inst_20_60_2.txt","H3/inst_25_12_2.txt","H3/inst_30_60_2.txt")
STARTS = ("original","consolidation")
SEEDS = (20261151,20261152)
ORDER_SEED = 20261153
ARCHIVE_SHA = "90f4b2e5705f43d1a1b2a574ea2f2ac35c443c04fedff8ebf77ac6fecb0e093c"


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def now():
    return datetime.now(timezone.utc).isoformat()


def bind_archive(archive):
    for name in ("tdirp_math_audit","tdirp_newalgo","tdirp_v3"):
        sys.path.insert(0,str(BASE.parent/name))
    import model_probe
    import frozen_start
    model_probe.ARCHIVE = frozen_start.ARCHIVE = Path(archive)
    return frozen_start


def sources():
    return {path.relative_to(CODE).as_posix():execution.sha(path) for path in execution.source_paths()}


def verify_sources(expected):
    if sources() != expected:
        raise ValueError("Frozen full-workflow source/binary changed")


def prepare(args):
    root = args.root.resolve()
    if root.exists():
        raise FileExistsError("Preserve existing preparation; use a new root")
    archive = args.archive.resolve()
    if execution.sha(archive) != ARCHIVE_SHA:
        raise ValueError("Wrong benchmark archive")
    source_reference = args.initial_reference.resolve()
    reference_plan = load(source_reference/"frozen_plan.json")
    cases = ("H3/inst_5_120_1.txt",) if args.engineering else CASES
    entries = {(r["input"],r["kind"]):r for r in reference_plan["initialization"]}
    bundle = load(source_reference/"endpoints.json") if (source_reference/"endpoints.json").is_file() else None
    with zipfile.ZipFile(archive) as z:
        import hashlib
        input_hashes = {case:hashlib.sha256(z.read(case)).hexdigest() for case in cases}
    cells = []
    seeds = SEEDS[:1] if args.engineering else SEEDS
    for case in cases:
        for kind in STARTS:
            for seed in seeds:
                for method in execution.METHODS:
                    cells.append({"stage":"engineering" if args.engineering else "primary60","input":case,
                                  "start_kind":kind,"seed":seed,"method":method,
                                  "budget_seconds":10. if args.engineering else 60.})
    rng = random.Random(ORDER_SEED)
    rng.shuffle(cells)
    if not args.engineering:
        diagnostic = [{"stage":"diagnostic300","input":case,"start_kind":"consolidation",
                       "seed":SEEDS[0],"method":method,"budget_seconds":300.}
                      for case in (cases[0],cases[-1]) for method in execution.METHODS]
        rng.shuffle(diagnostic)
        cells += diagnostic
    for j,cell in enumerate(cells):
        cell["cell_id"] = f"{j:04d}"
    expected = sources()
    root.mkdir(parents=True)
    plan = {"status":"DESIGN_FIXED_BEFORE_SEARCH","created_utc":now(),"engineering_only":args.engineering,
            "contract":execution.CONTRACT,"archive":str(archive),"archive_sha256":ARCHIVE_SHA,
            "input_sha256":input_hashes,"source_hashes":expected,"methods":list(execution.METHODS),
            "start_kinds":list(STARTS),"algorithm_seeds":list(seeds),"order_seed":ORDER_SEED,
            "reserve_seconds":3.,"sampled_tree_memory_limit_mib":1024.,"threads":1,
            "static_phase_share":.5,"initialization":"Reuse complete byte-identical V8 plans; no new initialization",
            "initial_reference_plan_sha256":execution.sha(source_reference/"frozen_plan.json"),
            "scope":"All four inputs reused; complete two-stage workflow adaptation, not original author software/model; 60/300 stages independent and not pooled with historical protocols",
            "cells":cells,"planned_calls":len(cells)}
    execution.atomic(root/"design_before_search.json",plan)
    frozen = bind_archive(archive)
    initials = []
    for case in cases:
        instance = frozen.read_instance(case)
        for kind in STARTS:
            entry = entries[case,kind]
            if not entry["success"]:
                raise ValueError("A declared frozen full start is unavailable")
            if bundle is not None:
                member = next(r for r in bundle["initials"] if (r["input"],r["start_kind"]) == (case,kind))
                original = source_reference/member["payload_relative_file"]
            else:
                original = Path(entry["initial_file"])
            if execution.sha(original) != entry["payload_sha256"]:
                raise ValueError("Reference full-start payload changed")
            payload = load(original)
            frozen.validate_plan(instance,payload)
            destination = root/"initials"/original.name
            destination.parent.mkdir(exist_ok=True)
            shutil.copyfile(original,destination)
            initials.append({"input":case,"kind":kind,"success":True,"initial_file":str(destination),
                             "payload_sha256":entry["payload_sha256"]})
    verify_sources(expected)
    for relative in expected:
        destination = root/"frozen_source"/relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(CODE/relative,destination)
    plan.update(status="FROZEN_BEFORE_FIRST_SEARCH",frozen_utc=now(),initialization=initials)
    execution.atomic(root/"frozen_plan.json",plan)
    print(json.dumps({"frozen":True,"planned_calls":len(cells),"full_starts":len(initials)}))


def run(args):
    root = args.root.resolve()
    plan = load(root/"frozen_plan.json")
    if plan["status"] != "FROZEN_BEFORE_FIRST_SEARCH":
        raise ValueError("Preparation not frozen")
    verify_sources(plan["source_hashes"])
    if execution.sha(plan["archive"]) != plan["archive_sha256"]:
        raise ValueError("Frozen benchmark changed")
    output = root/"results.json"
    if output.exists():
        raise FileExistsError("Preserve prior scientific cells; no automatic retry")
    initial = {(r["input"],r["kind"]):r for r in plan["initialization"]}
    results = {"status":"RUNNING","started_utc":now(),"planned_calls":plan["planned_calls"],
               "frozen_plan_sha256":execution.sha(root/"frozen_plan.json"),"rows":[]}
    execution.atomic(output,results)
    for n,cell in enumerate(plan["cells"],1):
        verify_sources(plan["source_hashes"])
        start = initial[cell["input"],cell["start_kind"]]
        if execution.sha(start["initial_file"]) != start["payload_sha256"]:
            raise ValueError("Full starting payload changed")
        row = execution.run_one(cell["input"],cell["method"],cell["seed"],start["initial_file"],
                                root/"workers",cell["budget_seconds"],plan["reserve_seconds"],
                                plan["sampled_tree_memory_limit_mib"],archive=plan["archive"])
        row.update(cell)
        results["rows"].append(row)
        execution.atomic(output,results)
        print(json.dumps({"progress":f"{n}/{len(plan['cells'])}","input":cell["input"],
                          "start":cell["start_kind"],"method":cell["method"],"stage":cell["stage"],
                          "cost":row["endpoint_objective"],"eligible":row["endpoint_eligible"],
                          "failure":row.get("failure"),"stop":row.get("external_stop")}),flush=True)
    results.update(status="COMPLETED",completed_utc=now())
    execution.atomic(output,results)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare",action="store_true")
    mode.add_argument("--run",action="store_true")
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--archive",type=Path,default=CODE/"data/Benchmark.zip")
    parser.add_argument("--initial-reference",type=Path,default=CODE/"reference/v8")
    parser.add_argument("--engineering",action="store_true")
    args = parser.parse_args()
    prepare(args) if args.prepare else run(args)
