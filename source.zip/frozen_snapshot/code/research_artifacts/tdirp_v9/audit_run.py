"""Original-file, identity, budget and fixed-quantity audit of the full workflow."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib,json,math
from pathlib import Path
BASE=Path(__file__).resolve().parent
CODE=BASE.parent.parent
CONTRACT="completion_c1_endholding_nowait_ML_header_v1"
def load(path): return json.loads(Path(path).read_text(encoding="utf-8"))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(condition,message):
    if not condition: raise ValueError(message)
def finite(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)

def eligible(result, receipt, payload_hash, identity, c0, budget, observed):
    """Independent eligibility predicate; no execution-adapter helper calls."""
    return (receipt.get("result_sha256") == payload_hash
            and all(result.get(key) == value for key,value in identity.items())
            and finite(receipt.get("checkpoint_completed_elapsed_since_parent"))
            and 0 <= receipt["checkpoint_completed_elapsed_since_parent"] <= budget
            and finite(observed) and 0 <= observed <= budget
            and finite(result.get("objective")) and result["objective"] <= c0+1e-7
            and result.get("contract") == CONTRACT and result.get("objective_definition") == "completion"
            and isinstance(result.get("independent_verification"),dict)
            and result["independent_verification"].get("checked") is True
            and finite(result["independent_verification"].get("objective_decimal"))
            and abs(result["objective"]-result["independent_verification"]["objective_decimal"]) <= 1e-7
            and result.get("routes") == result["independent_verification"].get("routes")
            and result.get("quantities") == result["independent_verification"].get("quantities"))


def audit(root):
    root=Path(root).resolve()
    plan=load(root/"frozen_plan.json")
    raw=load(root/"results.json")
    analysis=load(root/"analysis.json")
    expected_count=4 if plan["engineering_only"] else 36
    require(raw["status"] == "COMPLETED" and analysis["status"] == "PASS","Incomplete raw/analysis")
    require(len(raw["rows"]) == len(analysis["rows"]) == len(plan["cells"]) == expected_count,
            "Wrong full-workflow cell denominator")
    require(raw["frozen_plan_sha256"] == sha(root/"frozen_plan.json"),"Raw/protocol identity")
    for relative,checksum in plan["source_hashes"].items():
        require(sha(CODE/relative) == sha(root/"frozen_source"/relative) == checksum,
                "Frozen source or executable drift: "+relative)
    planned={r["cell_id"]:r for r in plan["cells"]}
    reported={r["cell_id"]:r for r in analysis["rows"]}
    require(len(planned)==len(reported)==expected_count and planned.keys()==reported.keys(),"Duplicate/missing cells")
    initials={(r["input"],r["kind"]):r for r in plan["initialization"]}
    require(len(initials)==len(plan["initialization"])==(2 if plan["engineering_only"] else 8),"Full start coverage")
    for item in initials.values():
        require(sha(item["initial_file"])==item["payload_sha256"],"Initial payload drift")
    seen=set()
    checked_pairs=0
    cells=[]
    for row in raw["rows"]:
        key=row["cell_id"]
        require(key in planned and key not in seen,"Unexpected/duplicate raw cell")
        seen.add(key)
        cell=planned[key]
        require(all(row.get(k)==v==reported[key].get(k) for k,v in cell.items()),"Raw/analyzed identity differs")
        require(abs(row["endpoint_objective"]-reported[key]["objective"])<1e-7
                and row["endpoint_eligible"]==reported[key]["eligible_publication"]
                and row["fallback_to_common_start"]==reported[key]["fallback_to_common_start"],"Stale analyzed endpoint")
        initial=initials[cell["input"],cell["start_kind"]]
        start=load(initial["initial_file"])
        stored=load(row["result_file"])
        require(all(row.get(k)==v for k,v in stored.items()),"Original worker/aggregate mismatch")
        sources=load(row["source_manifest_file"])
        require(sources==row["source_hashes"],"Source manifest mismatch")
        for path,checksum in sources.items():
            relative=Path(path).resolve().relative_to(CODE).as_posix()
            require(plan["source_hashes"].get(relative)==checksum and sha(path)==checksum,"Unbound worker source")
        identity={"input":cell["input"],"method":cell["method"],"seed":cell["seed"],
                  "run_id":row["run_id"],"attempt_id":row["attempt_id"],
                  "initial_plan_sha256":start["plan_sha256"],"expected_initial_sha256":start["plan_sha256"],
                  "initial_payload_sha256":initial["payload_sha256"],"source_hashes":sources,"initial_identity_checked":True}
        candidates=[]
        for observed in row["checkpoint_audit"]:
            path=Path(observed["file"])
            receipt_path=path.with_suffix(".commit.json")
            if not path.is_file() or not receipt_path.is_file():
                require(bool(observed["rejections"]),"Accepted missing publication pair")
                continue
            value,receipt=load(path),load(receipt_path)
            ok=eligible(value,receipt,sha(path),identity,start["objective"],cell["budget_seconds"],observed.get("observed_elapsed_seconds"))
            require(ok==(not observed["rejections"]),"Independent receipt eligibility disagrees")
            checked_pairs+=1
            if ok:
                candidates.append((value["objective"],-value.get("publication_sequence",0),str(path),value,receipt))
        if candidates:
            chosen=min(candidates,key=lambda r:r[:2])
            require(row["endpoint_eligible"] and chosen[2]==row["worker_checkpoint_file"]
                    and chosen[3]==row["result"] and chosen[4]==row["checkpoint_receipt"],"Wrong retained endpoint")
        else:
            require(not row["endpoint_eligible"] and row["fallback_to_common_start"]
                    and abs(row["endpoint_objective"]-start["objective"])<1e-7,"Wrong full-start fallback")
        endpoint=row.get("result") or start
        if cell["method"]=="two_stage_irp_fifo":
            require(endpoint.get("global_bound") is None and endpoint.get("global_gap") is None
                    and not endpoint.get("conditional_optimum_verified",False),"Static bound leaked as FIFO certificate")
            require(endpoint.get("counters",{}).get("inventory_recourse_calls_in_phase_two",0)==0,
                    "Phase two introduced inventory recourse")
            first=endpoint.get("phase_one_plan")
            if endpoint.get("retained_origin")=="common_start":
                require(endpoint["routes"]==start["routes"] and endpoint["quantities"]==start["quantities"],
                        "Reported common start differs from frozen start")
            elif endpoint.get("retained_origin") in ("static_phase","routing_phase"):
                require(first is not None and endpoint["quantities"]==first["quantities"]
                        and [set(r) for r in endpoint["routes"]]==[set(r) for r in first["routes"]],"Phase-two visits/quantities changed")
            if endpoint.get("workflow_completed"):
                candidate=endpoint.get("last_complete_candidate_plan")
                require(first is not None and candidate is not None
                        and candidate["quantities"]==first["quantities"]
                        and [set(r) for r in candidate["routes"]]==[set(r) for r in first["routes"]]
                        and endpoint["counters"]["td_tsp_calls"]==len(first["routes"]),"Incomplete reported two-stage workflow")
        cells.append({"cell_id":key,"method":cell["method"],"eligible_pairs":len(candidates),
                      "workflow_completed":endpoint.get("workflow_completed"),
                      "wall_over_budget":row["full_worker_wall_seconds"]>cell["budget_seconds"],
                      "failure":row.get("failure"),"external_stop":row.get("external_stop")})
    require(seen==set(planned),"Missing planned cells")
    return {"status":"PASS","created_utc":datetime.now(timezone.utc).isoformat(),
            "accounted_calls":len(cells),"original_receipt_pairs_checked":checked_pairs,
            "frozen_plan_sha256":sha(root/"frozen_plan.json"),"analysis_sha256":sha(root/"analysis.json"),
            "results_sha256":sha(root/"results.json"),"auditor_sha256":sha(Path(__file__)),
            "wall_over_budget_count":sum(r["wall_over_budget"] for r in cells),"cells":cells,
            "optimizer_called":False,"scope":"Original receipts, identities, endpoint selection and fixed-y/q workflow invariants; physical validation is independently recorded by the analyzer"}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root",type=Path)
    args=parser.parse_args()
    report=audit(args.root)
    (args.root/"execution_audit.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:report[k] for k in ("status","accounted_calls","original_receipt_pairs_checked")}))

