"""Independent literal-plan audit of the complete two-stage workflow comparison."""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import statistics
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import pilot


def wtl(values, tolerance=1e-7):
    return [sum(x > tolerance for x in values), sum(abs(x) <= tolerance for x in values),
            sum(x < -tolerance for x in values)]


def mean(values):
    return statistics.fmean(values) if values else None


def components(instance, checked):
    complete = sum(checked["return_times"])
    moving = sum(checked["travel_times"])
    holding = Fraction(checked["holding_cost"])
    objective = Fraction(checked["exact_feasible_objective"])
    if objective != complete + holding:
        raise ValueError("Physical objective components do not add")
    return {"objective": float(objective), "moving": moving, "service": complete-moving,
            "holding": float(holding), "stops": sum(map(len, checked["routes"]))}


def analyze(root):
    root = Path(root).resolve()
    plan = pilot.load(root / "frozen_plan.json")
    raw = pilot.load(root / "results.json")
    if raw["frozen_plan_sha256"] != pilot.execution.sha(root / "frozen_plan.json"):
        raise ValueError("Result/plan identity mismatch")
    if raw["status"] != "COMPLETED" or len(raw["rows"]) != plan["planned_calls"]:
        raise ValueError("Incomplete pilot; do not silently analyze a success-only prefix")
    frozen = pilot.bind_archive(Path(plan["archive"]))
    from schedule_repair import verify_routes
    expected = {cell["cell_id"]: cell for cell in plan["cells"]}
    if len(expected) != len(plan["cells"]):
        raise ValueError("Duplicate planned cells")
    instances = {case: frozen.read_instance(case) for case in plan["input_sha256"]}
    starts = {}
    for item in plan["initialization"]:
        key = (item["input"], item["kind"])
        if not item["success"]:
            starts[key] = {"success": False}
            continue
        record = pilot.load(item["initial_file"])
        if pilot.execution.sha(item["initial_file"]) != item["payload_sha256"]:
            raise ValueError("Initial payload changed")
        checked = frozen.validate_plan(instances[key[0]], record)
        starts[key] = {"success": True, "record": record,
                       "components": components(instances[key[0]], checked)}
    rows, seen = [], set()
    for record in raw["rows"]:
        cell_id = record["cell_id"]
        if cell_id in seen or cell_id not in expected:
            raise ValueError("Unexpected or duplicate result cell")
        seen.add(cell_id)
        cell = expected[cell_id]
        if any(record.get(k) != value for k, value in cell.items()):
            raise ValueError("Cell filters differ from frozen design")
        initial = starts[(cell["input"], cell["start_kind"])]
        row = dict(cell)
        if not initial["success"]:
            if record.get("failure") != "unavailable_declared_initializer":
                raise ValueError("Unavailable start has an unexplained result")
            rows.append({**row, "feasible_endpoint_available": False,
                         "failure": record["failure"], "objective": None})
            continue
        if record.get("endpoint_eligible"):
            endpoint = record["result"]
            payload = Path(record["worker_checkpoint_file"]).read_bytes()
            receipt = record["checkpoint_receipt"]
            if hashlib.sha256(payload).hexdigest() != receipt["result_sha256"]:
                raise ValueError("Selected result/receipt byte mismatch")
            if json.loads(payload) != endpoint:
                raise ValueError("Selected result differs from raw checkpoint")
            if not 0 <= record["checkpoint_publication_observed_elapsed_seconds"] <= cell["budget_seconds"]:
                raise ValueError("Selected result was not observed within budget")
        else:
            if not record.get("fallback_to_common_start"):
                raise ValueError("Ineligible output lacks explicit common-start fallback")
            endpoint = initial["record"]
        checked = verify_routes(instances[cell["input"]], endpoint["routes"],
                                endpoint["quantities"], "completion")
        if not checked.get("checked") or abs(checked["objective_decimal"]-record["endpoint_objective"]) > 1e-7:
            raise ValueError("Reported endpoint failed independent literal verification")
        if checked["objective_decimal"] > initial["components"]["objective"] + 1e-7:
            raise ValueError("Endpoint degraded the retained full start")
        costs = components(instances[cell["input"]], checked)
        if cell["method"] == "two_stage_irp_fifo" and endpoint.get("baseline_candidate_available"):
            candidate = endpoint.get("last_complete_candidate_plan")
            if not isinstance(candidate,dict):
                raise ValueError("Claimed complete workflow candidate is missing")
            candidate_check = verify_routes(instances[cell["input"]],candidate["routes"],candidate["quantities"],"completion")
            if (not candidate_check.get("checked") or
                    abs(candidate_check["objective_decimal"]-endpoint["last_complete_candidate_objective"]) > 1e-7):
                raise ValueError("Complete workflow candidate failed independent literal verification")
        counters = endpoint.get("counters", {})
        rows.append({**row, "feasible_endpoint_available": True, **costs,
                     "initial_objective": initial["components"]["objective"],
                     "gain_pp_C0": 100*(initial["components"]["objective"]-costs["objective"])/initial["components"]["objective"],
                     "eligible_publication": bool(record["endpoint_eligible"]),
                     "fallback_to_common_start": bool(record.get("fallback_to_common_start")),
                     "failure": record.get("failure"), "external_stop": record.get("external_stop"),
                     "wall_seconds": record["full_worker_wall_seconds"],
                     "peak_resident_bytes": record["observed_peak_resident_bytes"],
                     "max_sampling_gap_seconds": record.get("observed_max_sampling_gap_seconds"),
                     "iterations": endpoint.get("iterations"),
                     "cluster_calls": counters.get("cluster_calls", 0),
                     "cluster_internal_dp_states": counters.get("cluster_internal_dp_states", 0),
                     "cluster_true_fifo_rejections": counters.get("cluster_true_fifo_rejected_candidates", 0),
                     "cluster_incumbent_fallbacks": counters.get("cluster_incumbent_profile_fallbacks", 0),
                     "workflow_completed": bool(endpoint.get("workflow_completed", False)),
                     "baseline_candidate_available": bool(endpoint.get("baseline_candidate_available", False)),
                     "retained_origin": endpoint.get("retained_origin"),
                     "pipeline_failure_reason": endpoint.get("pipeline_failure_reason"),
                     "static_irp_calls": counters.get("static_irp_calls", 0),
                     "td_tsp_calls": counters.get("td_tsp_calls", 0),
                     "td_tsp_nodes": counters.get("td_tsp_nodes", 0),
                     "static_phase_gap": (endpoint.get("phase_one_report") or {}).get("static_gap"),
                     "static_warm_start_accepted": ((endpoint.get("phase_one_report") or {}).get("diagnostics") or {}).get("seed_accepted",False)})
    if seen != set(expected):
        raise ValueError("Missing planned cells")
    groups = defaultdict(list)
    for row in rows:
        groups[(row["stage"], row["start_kind"], row["method"])].append(row)
    summaries = []
    for key, group in groups.items():
        feasible = [row for row in group if row["feasible_endpoint_available"]]
        summaries.append({"stage": key[0], "start_kind": key[1], "method": key[2],
                          "planned_rows": len(group), "feasible_endpoints": len(feasible),
                          "eligible_publications": sum(row.get("eligible_publication", False) for row in feasible),
                          "operational_failures": sum(bool(row.get("failure") or row.get("external_stop")) for row in group),
                          "common_start_fallbacks": sum(row.get("fallback_to_common_start", False) for row in feasible),
                          "mean_objective": mean([row["objective"] for row in feasible]),
                          "mean_gain_pp_C0": mean([row["gain_pp_C0"] for row in feasible]),
                          "mean_wall_seconds": mean([row["wall_seconds"] for row in feasible]),
                          "maximum_sampled_resident_bytes": max((row["peak_resident_bytes"] for row in feasible), default=None),
                          "cluster_active_rows": sum(row.get("cluster_internal_dp_states", 0) > 0 for row in feasible),
                          "workflows_completed": sum(row.get("workflow_completed",False) for row in feasible),
                          "baseline_candidate_available_rows": sum(row.get("baseline_candidate_available",False) for row in feasible),
                          "mean_td_tsp_calls": mean([row.get("td_tsp_calls",0) for row in feasible])})
    indexed = {(r["stage"], r["input"], r["start_kind"], r["seed"], r["method"]): r for r in rows}
    contrasts = []
    for stage in dict.fromkeys(row["stage"] for row in rows):
        for kind in pilot.STARTS:
            for other in pilot.METHODS[1:]:
                per_input = defaultdict(list)
                for row in rows:
                    if row["stage"] != stage or row["start_kind"] != kind or row["method"] != pilot.METHODS[0]:
                        continue
                    peer = indexed.get((stage, row["input"], kind, row["seed"], other))
                    if peer and row["feasible_endpoint_available"] and peer["feasible_endpoint_available"]:
                        value = 100*(peer["objective"]-row["objective"])/row["initial_objective"]
                        per_input[row["input"]].append(value)
                if per_input:
                    values = [value for group in per_input.values() for value in group]
                    input_means = {case: mean(group) for case, group in per_input.items()}
                    contrasts.append({"stage": stage, "start_kind": kind, "comparator": other,
                                      "matched_pairs": len(values), "input_count": len(input_means),
                                      "mean_input_advantage_pp_C0": mean(list(input_means.values())),
                                      "run_wins_ties_losses": wtl(values),
                                      "input_wins_ties_losses": wtl(list(input_means.values())),
                                      "input_means": input_means})
    cross_start = []
    for row in rows:
        if row["start_kind"] != "original" or not row["feasible_endpoint_available"]:
            continue
        peer = indexed.get((row["stage"], row["input"], "consolidation", row["seed"], row["method"]))
        if peer and peer["feasible_endpoint_available"]:
            cross_start.append({"stage": row["stage"], "input": row["input"], "seed": row["seed"],
                                "method": row["method"], "original_start_final_cost": row["objective"],
                                "consolidation_start_final_cost": peer["objective"],
                                "advantage_of_consolidation_pp_original_C0":
                                    100*(row["objective"]-peer["objective"])/row["initial_objective"]})
    result = {"status": "PASS", "scope": plan["scope"], "engineering_only": plan["engineering_only"],
              "planned_and_accounted_calls": len(rows), "independent_literal_endpoints": sum(r["feasible_endpoint_available"] for r in rows),
              "complete_workflow_reimplemented": True, "original_author_software_or_model_reproduced": False,
              "grouping": "Seed means within input, then equal input weights; four same-family inputs do not establish external geographical validation",
              "inference": "Descriptive pilot; no significance or population noninferiority claim",
              "initialization": [{"input": case, "start_kind": kind, "success": item["success"],
                                  **({"components": item["components"]} if item["success"] else {})}
                                 for (case, kind), item in starts.items()],
              "methods": summaries, "contrasts": contrasts, "cross_start": cross_start, "rows": rows}
    pilot.execution.atomic(root / "analysis.json", result)
    return result


def write_report(root, result):
    lines = ["## Material Passport", "", "- Mode: run + independent literal validation.",
             "- Status: VERIFIED within the retained operational model and pilot scope.",
             "- Historical cohorts: unchanged and not pooled.",
             "- Comparator: complete static-IRP then fixed-quantity FIFO-TSP workflow adaptation, not original author software/model reproduction.",
             "", "## Initialization", "",
             "| Input | Start | Feasible | Initial cost | Stops | Moving | Service | Holding |",
             "|---|---|---:|---:|---:|---:|---:|---:|"]
    for item in result["initialization"]:
        c = item.get("components", {})
        numbers = [c.get(k) for k in ("objective", "stops", "moving", "service", "holding")]
        values = ["NA" if v is None else f"{v:.4f}" for v in numbers]
        lines.append("| " + " | ".join([item["input"], item["start_kind"], str(item["success"]), *values]) + " |")
    lines += ["", "## Method outcomes", "",
              "Costs include retained common-start fallbacks when an initialization is available; eligibility/failures remain separate.",
              "", "| Stage | Start | Method | Feasible/planned | Eligible | Failures | Mean final cost | Mean gain (% C0) |",
              "|---|---|---|---:|---:|---:|---:|---:|"]
    for row in result["methods"]:
        values = ["NA" if row[k] is None else f"{row[k]:.6f}" for k in ("mean_objective", "mean_gain_pp_C0")]
        lines.append("| " + " | ".join([row["stage"], row["start_kind"], row["method"],
                     f"{row['feasible_endpoints']}/{row['planned_rows']}", str(row["eligible_publications"]),
                     str(row["operational_failures"]), *values]) + " |")
    lines += ["", "## Matched method contrasts", "",
              "Positive values favor joint exact profiles. Seeds are averaged within input; inputs receive equal weight.",
              "", "| Stage | Start | Comparator | Pairs | Input groups | Mean advantage (pp C0) | Run W/T/L | Input W/T/L |",
              "|---|---|---|---:|---:|---:|---|---|"]
    for row in result["contrasts"]:
        lines.append("| " + " | ".join([row["stage"], row["start_kind"], row["comparator"],
                     str(row["matched_pairs"]), str(row["input_count"]), f"{row['mean_input_advantage_pp_C0']:.6f}",
                     "/".join(map(str, row["run_wins_ties_losses"])),
                     "/".join(map(str, row["input_wins_ties_losses"]))]) + " |")
    lines += ["", "## Starting-plan sensitivity", "",
              "These contrasts compare final costs, using the original starting cost as a shared denominator. Own-start improvement percentages must not be compared as though their denominators were equal.", ""]
    grouped = defaultdict(list)
    for row in result["cross_start"]:
        grouped[(row["stage"], row["method"])].append(row["advantage_of_consolidation_pp_original_C0"])
    lines += ["| Stage | Method | Matched pairs | Mean advantage from consolidation start (pp original C0) | W/T/L |",
              "|---|---|---:|---:|---|"]
    for key, values in grouped.items():
        lines.append(f"| {key[0]} | {key[1]} | {len(values)} | {mean(values):.6f} | {'/'.join(map(str, wtl(values)))} |")
    lines += ["", "## Interpretation limits", "",
              "This is a predeclared pilot on one traffic family. Repeated seeds and two starting constructions do not create independent networks. No statistical significance, global optimality, population noninferiority, historical priority or superiority over the full published BCHeu solver is asserted.",
              "", "Proxy master bounds are not FIFO bounds. Every endpoint is audited using the original literal clock, finite supplier inventory, vehicle load and customer stock rules. Initialization and search have separate recorded budgets. The longer-budget stage contains only its explicitly declared methods and inputs.", ""]
    (Path(root) / "summary.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    report = analyze(args.root)
    write_report(args.root, report)
    print(json.dumps({"status": report["status"], "accounted_calls": report["planned_and_accounted_calls"],
                      "independent_literal_endpoints": report["independent_literal_endpoints"]}))
