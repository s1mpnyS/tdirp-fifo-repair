# Fixed-handoff comparison of one- and six-customer repair

This follow-up reuses all 40 synthetic instances from the A+/G/J
confirmation. The question is whether releasing six customers together
improves a verified two-stage plan more than repeated singleton repair
with the same repair-time budget.

## Common start and compute

For every file, take the pre-repair J handoff from the original
`confirmation-120-20261109T150546Z` server run. Read the original
`run/cells/<cell_id>/immutable_handoff.json`, replay its physical
feasibility and objective independently, and require its signature and
cost to match the pinned confirmation analysis. Use the same literal
routes and quantities for K1 and K6. The selection uses the declared
source arm and full file grid. No final J or G endpoint is used as a start.
Freeze the imported states and provenance with the new run protocol
before executing either arm.

Both arms receive 90 seconds of cold repair wall time including a
three-second final reserve, one logical CPU, one numerical thread and
1,024 MiB sampled process-tree RSS. Setup, reading and verification
inside the worker are charged. Earlier constructor and two-stage time
is a shared offline cost. Neither arm reruns that prefix. Assign 80
cells in paired file blocks, ordered with seed 20261242. One search
seed (20261241) keys each sweep by instance hash. Require a fresh output
directory and retain all assigned outcomes and flags.

K1 releases one customer per call. K6 releases six. Both use the
same exact free-interleaving FIFO decoder, FIFO completion valuation,
horizon-wide inventory master with all quantities free, recourse,
six-second local cap, and strict true-cost acceptance. Each sweep
hash-orders all customers using the same permutation across arms.
K1 takes singletons in that order. K6 takes consecutive groups of six
in the permutation, wrapping the last group within the sweep to
keep six distinct customers. Every completed sweep covers all customers.

## Decision and mechanism

The primary contrast is `100*(C_K1-C_K6)/C_start`, where
`C_start` is this file's common handoff cost. The stored
`C0_exact` field refers to that handoff in this cohort. Weight the
four variants equally within each latent family, then weight all
ten families equally. Report exact file/family wins, ties and losses,
median costs and the same 10,000 whole-family bootstrap draws as
the confirmation. Use +0.2 percentage points of handoff cost as a
new practical reference. A bootstrap lower limit above zero supports
a positive effect on this cohort. A lower limit above +0.2 supports
a gain beyond the stated reference. Report the observed difference
with its uncertainty regardless of outcome.

Record repair returns and conditional no-improvement certificates.
Also look for a same-state mechanism witness in the eligible
repair receipts. On a particular verified state, K1 must have a
valid conditional no-improvement certificate and exact incumbent
cost for each of the file's customers. K6 must have a strictly
better verified candidate from that exact physical state. Preserve
the attempt identifiers, artifact hashes, block and exact costs.
This is a certificate under the implementation's numerical contract
and covers one application of each singleton neighborhood at the
specified state. Report the number of files with full singleton
coverage and the number with a matched joint witness.

The primary contrast measures the effect of block width under a
fixed clock, including its search and throughput effects. It uses
the same synthetic families as the earlier confirmation, one seed
and one online budget. These are separate experiments. Preserve the
original source-run folder until all handoffs have been imported.
