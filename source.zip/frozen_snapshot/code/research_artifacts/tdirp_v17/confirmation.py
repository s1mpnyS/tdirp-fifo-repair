"""Inputs and family-level analysis for the A+/G/J server study."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import random
from statistics import median
import zipfile


HERE = Path(__file__).resolve().parent
DATA = HERE.parents[1] / "reference/v12/v12/data/synthetic_stress_2026-11-06"
MANIFEST = HERE / "data/confirmation_inputs.json"
PROTOCOL = HERE / "CONFIRMATION.md"
SEED, ORDER_SEED = 20261221, 20261227
ROBUSTNESS_SEEDS, ROBUSTNESS_ORDER_SEED = (20261223, 20261224), 20261228
ROBUSTNESS_PROTOCOL = HERE / "ROBUSTNESS.md"
BUDGET = 120.
ARMS = ("A+", "G", "J")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inputs():
    manifest = json.loads(MANIFEST.read_bytes())
    if manifest["schema"] != "tdirp_v17_confirmation_inputs_v1":
        raise ValueError("Unexpected confirmation input schema")
    generation = (DATA / "generation_manifest.json").read_bytes()
    if sha(generation) != manifest["synthetic_generation_manifest_sha256"]:
        raise ValueError("Original synthetic generation manifest changed")
    original = {r["path"]: r["sha256"] for r in json.loads(generation)["files"]}
    files = {r["input"]: r for r in manifest["files"]}
    if len(files) != len(manifest["files"]) or len(files) != 40:
        raise ValueError("Expected 40 unique confirmation inputs")
    for seed in range(20261201, 20261211):
        for n in (40, 50):
            for horizon in (3, 6):
                m = 30 if (seed + (horizon == 6)) % 2 else 120
                name = f"synthetic_seed{seed}_H{horizon}_n{n}_M{m}.txt"
                row = files[name]
                if ((row["n"], row["H"], row["M"], row["family"], row["source"])
                        != (n, horizon, m, f"latent-{seed}", "synthetic_primary")
                        or row["sha256"] != original[name]
                        or row["witness_sha256"] != original[name + ".witness.json"]):
                    raise ValueError("Confirmation assignment differs from the selected V15 input")
    return files


def prepare_inputs(archive, verifier):
    """Create the runtime ZIP from verified original bytes and replay each C0."""
    files = inputs()
    warm = {}
    with zipfile.ZipFile(archive, "x") as out:
        for name, row in files.items():
            witness = name + ".witness.json"
            payload, point_bytes = (DATA / name).read_bytes(), (DATA / witness).read_bytes()
            if sha(payload) != row["sha256"] or sha(point_bytes) != row["witness_sha256"]:
                raise ValueError("Original input or witness changed: " + name)
            nodes, horizon, _, bins, *_ = map(int, payload.splitlines()[0].split())
            point = json.loads(point_bytes)
            if (nodes - 1, horizon, bins) != (row["n"], row["H"], row["M"]):
                raise ValueError("Input header differs from the locked factors")
            if verifier.verify_physical(verifier.parse_instance(payload), point) != point:
                raise ValueError("Confirmation C0 failed independent replay: " + name)
            warm[name] = point
            for member, data in ((name, payload), (witness, point_bytes)):
                out.writestr(zipfile.ZipInfo(member), data, compress_type=zipfile.ZIP_DEFLATED)
    return files, warm


def order(cases, arms=ARMS, order_seed=ORDER_SEED):
    rng = random.Random(order_seed)
    names = list(cases)
    rng.shuffle(names)
    for name in names:
        shuffled = list(arms)
        rng.shuffle(shuffled)
        for arm in shuffled:
            yield name, arm


def robustness_order(cases, arms, seeds, order_seed):
    """Shuffle file-seed blocks, preserving matched arm adjacency."""
    rng = random.Random(order_seed)
    blocks = [(name, seed) for name in cases for seed in seeds]
    rng.shuffle(blocks)
    for name, seed in blocks:
        shuffled = list(arms)
        rng.shuffle(shuffled)
        for arm in shuffled:
            yield name, arm, seed


def summarize(pairs, contrasts=(("A+", "J"), ("A+", "G"), ("G", "J"))):
    """Preserve variant pairs and treat latent families as resampling units."""
    groups = {}
    for row in pairs:
        groups.setdefault(row["family"], []).append(row)
    if len(groups) != 10 or any(len(rows) != 4 for rows in groups.values()):
        raise ValueError("Missing variants or families in confirmation analysis")
    results = {}
    for comparator, treatment in contrasts:
        def difference(row):
            return Fraction(row["costs_exact"][comparator]) - Fraction(row["costs_exact"][treatment])

        def pp(row):
            return 100 * difference(row) / Fraction(row["C0_exact"])

        def wtl(values):
            return [sum(v > 0 for v in values), sum(v == 0 for v in values), sum(v < 0 for v in values)]

        family = {name: sum(map(pp, rows)) / len(rows) for name, rows in groups.items()}
        values = list(family.values())
        rng = random.Random(20261229)
        draws = sorted(sum(rng.choices(values, k=len(values))) / len(values) for _ in range(10000))
        results[f"{treatment}_vs_{comparator}"] = {
            "mean_family_pp": float(sum(values) / len(values)),
            "median_family_pp": float(median(values)),
            "bootstrap_95_percentile_pp": [float(draws[249]), float(draws[9749])],
            "family_pp": {name: float(value) for name, value in family.items()},
            "family_w_t_l": wtl(values),
            "file_w_t_l": wtl([difference(row) for row in pairs]),
            "median_file_gain_cost": float(median(map(difference, pairs))),
            "mean_family_pp_by_n": {
                str(n): float(sum(sum(pp(row) for row in rows if row["n"] == n) / 2
                                  for rows in groups.values()) / len(groups))
                for n in (40, 50)
            },
        }
    return results


def summarize_seeds(pairs_by_seed, contrasts):
    """Average the fixed seed set within each file before resampling families."""
    by_seed = {seed: summarize(pairs, contrasts) for seed, pairs in pairs_by_seed.items()}
    pooled = []
    for copies in zip(*pairs_by_seed.values(), strict=True):
        first = copies[0]
        metadata = ("input", "family", "n", "H", "M", "C0_exact")
        if any(any(row[key] != first[key] for key in metadata) for row in copies):
            raise ValueError("Robustness file or reference cost differs across seeds")
        costs = {arm: str(sum(Fraction(row["costs_exact"][arm]) for row in copies) / len(copies))
                 for arm in first["costs_exact"]}
        pooled.append({**{key: first[key] for key in metadata}, "costs_exact": costs})
    return by_seed, summarize(pooled, contrasts)
