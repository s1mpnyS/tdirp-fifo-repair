"""Untimed logic checks on constructed fixtures, not on the smoke inputs."""
import argparse
from itertools import permutations
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from fifo_tsp_wide import native_source_paths, optimize_route


def check(condition, label):
    if not condition:
        raise AssertionError(label)


def replay(i, route):
    t = 0
    last = 0
    for node in [*(j + 1 for j in route), 0]:
        m = t // i.step_seconds
        if m >= i.steps:
            return float("inf")
        raw = i.travel[last, node]
        t = min([t + int(raw[m])] + [z * i.step_seconds + int(raw[z]) for z in range(m+1, i.steps)])
        t += int(i.service[node-1]) if node else 0
        last = node
    return t


def small():
    rng = np.random.default_rng(20261235)
    for _ in range(4):
        i = SimpleNamespace(n=6, steps=12, step_seconds=4, deadline=48,
            service=rng.integers(0, 3, size=6), travel=rng.integers(1, 5, size=(7, 7, 12)))
        expected = min(replay(i, route) for route in permutations(range(i.n)))
        answer = optimize_route(i, reversed(range(i.n)), 3)
        check(answer["optimal"] and answer["completion"] == expected, "Small TD exhaustive optimum")
        check(replay(i, answer["route"]) == expected, "Small TD returned route")
        i.deadline = expected - 1
        answer = optimize_route(i, range(i.n), 3)
        check(answer["infeasibility_proven"] and answer["route"] is None, "Strict cutoff")
    return 8


def wide():
    for n in (31, 32, 50):
        i = SimpleNamespace(n=n, steps=1, step_seconds=1000, deadline=5*n+2,
            service=np.full(n, 3), travel=np.full((n+1,n+1,1), 2))
        answer = optimize_route(i, reversed(range(n)), 0.8)
        check(answer.get("executable_sha256") and answer["completion"] == 5*n+2,
              f"Native wide incumbent {n}")
        check(answer["status"] in {"optimal", "time_limit"}
              and (answer["status"] == "optimal") == answer["optimal"]
              and not answer["infeasibility_proven"], f"Wide certificate scope {n}")
        check(len(set(answer["route"])) == n and replay(i, answer["route"]) == 5*n+2, f"Wide witness {n}")
    # Finite incumbent survives an exhausted allowance without any certificate.
    answer = optimize_route(i, reversed(range(i.n)), 0)
    check(answer["status"] == "time_limit" and not answer["optimal"]
          and replay(i, answer["route"]) == 5*i.n+2, "No budget must fail closed")
    return 4


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    mask = 1 | 1 << 32
    check((mask << 5) | 1 == (mask << 5) | 33, "Historical collision example")
    check((mask << 6) | 1 != (mask << 6) | 33, "Wide key separation")
    report = {"status": "PASS", "toy_checks": small()+wide()+2,
        "scientific_inputs_used": False,
        "hashes": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in native_source_paths()}}
    with args.output.open("x", encoding="utf-8") as out:
        json.dump(report, out, indent=2)
    print(json.dumps(report))


if __name__ == "__main__":
    main()
