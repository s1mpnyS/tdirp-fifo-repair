"""Two-stage restart helpers that preserve the static physical model."""
from dataclasses import replace
import hashlib


def restart_seed(seed, index):
    raw = hashlib.sha256(f"confirm-Aplus|{seed}|{index}".encode()).digest()
    return int.from_bytes(raw[:4], "big") % 2147483647


def customer_order(n, seed):
    """New-to-original mapping, identical across Python versions."""
    return sorted(range(n), key=lambda k: hashlib.sha256(f"{seed}|{k}".encode()).digest())


def solve_reordered(i, initial, deadline, seed, *, solve):
    """Permute static variables, solve the same instance, then undo labels."""
    order = customer_order(i.n, seed)
    inverse = [0] * i.n
    for new, old in enumerate(order):
        inverse[old] = new
    nodes = [0, *(k + 1 for k in order)]
    permuted = replace(
        i, initial=i.initial[order], maximum=i.maximum[order], minimum=i.minimum[order],
        demand=i.demand[:, order], holding=i.holding[order], service=i.service[order],
        travel=i.travel[nodes][:, nodes, :],
    )
    warm = {
        "routes": [[inverse[k] for k in route] for route in initial["routes"]],
        "quantities": [[q[k] for k in order] for q in initial["quantities"]],
    }
    answer = solve(permuted, warm, deadline, seed)
    if answer["success"]:
        answer = {
            **answer,
            "routes": [[order[k] for k in route] for route in answer["routes"]],
            "quantities": [[q[k] for k in inverse] for q in answer["quantities"]],
        }
    return answer
