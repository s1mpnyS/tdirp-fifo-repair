"""Observed server environment and fail-closed, single-logical-CPU affinity.

This module does not optimize an instance. Numerical imports occur only in the
explicit fingerprint command, after affinity and thread environment are set.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

THREAD_ENV = {name: "1" for name in (
    "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")}


def pin_logical_cpu(cpu=2):
    """Set and read back one logical CPU before importing numerical libraries."""
    if isinstance(cpu, bool) or not isinstance(cpu, int) or cpu < 0:
        raise ValueError("A nonnegative integral logical CPU is required")
    import psutil
    process = psutil.Process()
    available = process.cpu_affinity()
    if cpu not in available:
        raise RuntimeError(f"CPU {cpu} unavailable in inherited affinity {available}")
    process.cpu_affinity([cpu])
    observed = process.cpu_affinity()
    if observed != [cpu]:
        raise RuntimeError(f"Affinity readback failed: {observed}")
    os.environ.update(THREAD_ENV)
    return {"logical_cpu": cpu, "affinity_readback": observed,
            "thread_environment_readback": {name: os.environ.get(name) for name in THREAD_ENV},
            "pid": os.getpid()}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def capture_runtime(cpu=2):
    affinity = pin_logical_cpu(cpu)
    import psutil
    import numpy
    import scipy
    import scipy.optimize._highspy._core as highs
    from threadpoolctl import threadpool_info

    cpu_name = platform.processor()
    if os.name == "nt":
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as key:
            cpu_name = winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
    elif sys.platform == "linux":
        cpu_name = next((line.split(":", 1)[1].strip()
                         for line in Path("/proc/cpuinfo").read_text().splitlines()
                         if line.startswith("model name") and ":" in line), cpu_name)
    try:
        power = subprocess.run(["powercfg", "/getactivescheme"], capture_output=True,
                               text=True, timeout=10, check=False)
        power = {"exit_code": power.returncode, "stdout": power.stdout.strip(),
                 "stderr": power.stderr.strip()}
    except (OSError, subprocess.TimeoutExpired) as exc:
        power = {"unavailable": type(exc).__name__}
    battery = psutil.sensors_battery()
    battery = None if battery is None else {
        "percent": battery.percent, "power_plugged": battery.power_plugged,
        "seconds_left": battery.secsleft}
    pools = threadpool_info()
    if any(pool["num_threads"] != 1 for pool in pools):
        raise RuntimeError("Loaded numerical threadpool is not single-threaded")
    return {
        "status": "OBSERVED_NO_OPTIMIZATION", "captured_utc": datetime.now(timezone.utc).isoformat(),
        "cohort": "v17_exploratory_n50_server",
        "cpu_name": cpu_name, "physical_cores": psutil.cpu_count(logical=False),
        "logical_processors": psutil.cpu_count(logical=True),
        "ram_bytes": psutil.virtual_memory().total,
        "os": platform.platform(), "kernel_release": platform.release(), "kernel_version": platform.version(),
        "windows_version_readback": str(sys.getwindowsversion()) if os.name == "nt" else None,
        "python": sys.version, "python_executable": sys.executable,
        "python_executable_sha256": sha(sys.executable),
        "numpy": numpy.__version__, "scipy": scipy.__version__,
        "psutil": importlib.metadata.version("psutil"),
        "threadpoolctl": importlib.metadata.version("threadpoolctl"),
        "highs_version_loaded": ".".join(str(getattr(highs, "HIGHS_VERSION_" + name))
                                         for name in ("MAJOR", "MINOR", "PATCH")),
        "highs_extension": highs.__file__, "highs_extension_sha256": sha(highs.__file__),
        "affinity": affinity, "loaded_threadpools": pools,
        "power_scheme": power, "battery": battery,
        "limitations": ["One logical CPU affinity does not reserve its physical core",
                        "Timing results are a separate exploratory cohort"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cpu", type=int, default=2)
    args = parser.parse_args()
    path = Path(args.output)
    result = capture_runtime(args.cpu)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(path.resolve()), "sha256": sha(path),
                      "cpu": result["cpu_name"], "highs": result["highs_version_loaded"],
                      "affinity": result["affinity"]["affinity_readback"]}))


if __name__ == "__main__":
    main()
