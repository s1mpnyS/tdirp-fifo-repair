"""One directed K6 call on an independently replayed singleton endpoint."""
import hashlib
import math
from pathlib import Path
import time

import runner
from replay import preserves_outside_order


SINGLETON_SECONDS = 1.
AUDIT_SECONDS = 20.
JOINT_SECONDS = 6.
PARENT_SECONDS = 32.
OBJECTIVE_MATCH_TOLERANCE = 1e-5  # Existing valued-repair numerical contract.


def order(record, seed):
    return sorted(range(record["n"]), key=lambda customer: hashlib.sha256(
        f"sensitivity-probe|{record['schedule_sha256']}|{seed}|{customer}".encode()).digest())


def source_identity(path, plan, cell):
    path = Path(path)
    source = runner.load(path)
    assigned = next(item for item in plan["cells"] if item["cell_id"] == cell["source_cell"])
    if (source["cell"] != assigned or assigned["arm"] != "K1" or assigned["input"] != cell["input"]
            or assigned["seed"] != cell["seed"] or source["identity"]["plan_sha256"] != plan["plan_sha256"]
            or not source.get("clean_resource_timing") or "fixed_handoff" not in source["phase_records"]):
        raise ValueError("Directed probe requires the eligible K1 endpoint of the exact frozen assignment")
    return {"source_result_sha256": runner.sha(path),
            "source_endpoint_sha256": runner.physical_signature(source["retained"])}


def source_endpoint(path, plan, cell, verifier, instance):
    identity = source_identity(path, plan, cell)
    source = runner.load(path)
    point = source["retained"]
    checked = verifier.verify_physical(instance, point)
    anchor = verifier.verify_physical(instance, plan["warm_starts"][cell["input"]]["point"])
    if (checked != point or runner.physical_signature(checked) != identity["source_endpoint_sha256"]
            or source["initial"] != anchor or source["phase_records"]["fixed_handoff"]["physical_sha256"]
            != runner.physical_signature(anchor)):
        raise ValueError("Literal K1 endpoint did not independently replay")
    selected_file = source["retained_checkpoint_file"]
    if selected_file is None:
        if checked != anchor:
            raise ValueError("K1 endpoint has no receipt or verified anchor")
    else:
        observed = next(item for item in source["publications"] if item["file"] == selected_file)
        payload, receipt = runner.load(selected_file), runner.load(observed["receipt_file"])
        if (observed["rejections"] or observed["payload"] != payload or observed["verified"] != checked
                or runner.checkpoint_rejections(payload, receipt, source["identity"],
                    observed["observed_elapsed_seconds"], source["budget_seconds"], checked)):
            raise ValueError("Selected K1 checkpoint receipt did not independently replay")
    return checked


def audit(instance, state, cell, work_end, verifier, physical_instance):
    from valued_repair import one_repair

    def evaluate(block, deadline):
        repair = one_repair(instance, state, block, "fifo", deadline, decoder="fifo_free_exact")
        candidate = None
        if repair["candidate_eligible"]:
            candidate = verifier.verify_physical(physical_instance, {"routes": repair["raw_routes"],
                "quantities": repair["raw_quantities"], "exact_feasible_objective": repair["raw_exact_objective"]})
            if not preserves_outside_order(state, candidate, block):
                raise ValueError("Probe returned a candidate outside the fixed-order neighbourhood")
        timely = time.perf_counter() < deadline
        delta = None if candidate is None else runner.exact(candidate) - runner.exact(state)
        improves = timely and delta is not None and delta < 0
        certified = timely and delta == 0 and repair["raw_conditional_optimum_verified"]
        evidence = {"block": block, "certified": certified, "improves": improves,
            "candidate": candidate, "status": repair["status"], "timely": timely,
            "master_status": repair["raw_status"], "solver_objective": repair.get("raw_solver_objective"),
            "master_lower_bound": repair["raw_master_lower_bound"],
            "conditional_optimum": repair["raw_conditional_optimum_verified"],
            "candidate_eligible": repair["candidate_eligible"]}
        return evidence

    order = cell["singleton_order"]
    audit_end = min(work_end - JOINT_SECONDS, time.perf_counter() + AUDIT_SECONDS)
    trials = []
    for customer in order:
        started = time.perf_counter()
        if started >= audit_end:
            break
        trial = evaluate([customer], min(audit_end, started + SINGLETON_SECONDS))
        trials.append(trial)
        if trial["improves"]:
            break
    singleton = "unresolved"
    if any(trial["improves"] for trial in trials):
        singleton = "improving"
    elif len(trials) == len(order) and all(trial["certified"] for trial in trials):
        singleton = "certified"
    joint_start = time.perf_counter()
    joint = None if joint_start >= work_end else evaluate(cell["first_block"], min(work_end, joint_start + JOINT_SECONDS))
    report = {"endpoint_physical_sha256": runner.physical_signature(state),
              "endpoint_exact_cost": state["exact_feasible_objective"],
              "singleton_status": singleton, "singleton_trials": trials, "joint_trial": joint}
    return report, joint["candidate"] if joint and joint["improves"] else state


def replay(probe, k1, report, verifier, instance):
    state = k1["retained"]
    if (probe["initial"] != state or report["endpoint_exact_cost"] != state["exact_feasible_objective"]
            or probe["identity"]["source_endpoint_sha256"] != runner.physical_signature(state)
            or report["endpoint_physical_sha256"] != runner.physical_signature(state)):
        raise ValueError("Probe does not replay the K1 endpoint")
    latest = next(item for item in probe["publications"] if item["file"] == probe["latest_eligible_checkpoint_file"])
    payload = runner.load(latest["file"])
    receipt = runner.load(latest["receipt_file"])
    verified = verifier.verify_physical(instance, payload["point"])
    if (payload != latest["payload"] or verified != probe["retained"] or payload["stage"] != "probe_return"
            or payload["phase_records"]["probe"] != report or runner.checkpoint_rejections(payload, receipt,
                probe["identity"], latest["observed_elapsed_seconds"], probe["budget_seconds"], verified)):
        raise ValueError("Probe receipt does not replay")

    def check(trial, block):
        if trial["block"] != block:
            raise ValueError("Probe departed from its frozen block order")
        candidate = trial["candidate"]
        if candidate is not None and (verifier.verify_physical(instance, candidate) != candidate
                                      or not preserves_outside_order(state, candidate, block)):
            raise ValueError("Probe candidate failed exact physical or neighbourhood replay")
        if trial["candidate_eligible"] != (candidate is not None):
            raise ValueError("Probe evidence omits an eligible candidate")
        delta = None if candidate is None else runner.exact(candidate) - runner.exact(state)
        improves = trial["timely"] and delta is not None and delta < 0
        solver_cost = trial["solver_objective"]
        if trial["conditional_optimum"] and (trial["master_status"] != 0 or candidate is None
                or solver_cost is None or not math.isfinite(solver_cost)
                or abs(solver_cost - float(runner.exact(candidate))) > OBJECTIVE_MATCH_TOLERANCE):
            raise ValueError("Probe recorded an unsupported numerical certificate")
        certified = trial["timely"] and delta == 0 and trial["conditional_optimum"]
        if (improves, certified) != (trial["improves"], trial["certified"]):
            raise ValueError("Probe gain or certificate conflicts with its evidence")
        return improves, certified

    order = probe["cell"]["singleton_order"]
    trials = report["singleton_trials"]
    if len(trials) > len(order):
        raise ValueError("Extra singleton trials")
    observed = [check(trial, [customer]) for trial, customer in zip(trials, order)]
    if any(improved for improved, _ in observed):
        status = "improving"
    elif len(observed) == len(order) and all(certified for _, certified in observed):
        status = "certified"
    else:
        status = "unresolved"
    joint = report["joint_trial"]
    hit = bool(joint and check(joint, probe["cell"]["first_block"])[0])
    expected = joint["candidate"] if hit else state
    if status != report["singleton_status"] or probe["retained"] != expected:
        raise ValueError("Probe outcome conflicts with independently replayed evidence")
    return status, hit, joint is not None, bool(joint and not joint["timely"])
