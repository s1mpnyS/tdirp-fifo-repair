// Complete fixed-membership FIFO TSP search. No inventory decisions are made.
// The FIFO clock is the literal frozen fifo_probe.FifoNetwork arrival rule.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#elif defined(__APPLE__)
#include <mach/mach_time.h>
#else
#include <time.h>
#endif

namespace {
using Clock = std::chrono::steady_clock;
constexpr unsigned LAST_BITS = 6;
constexpr int MAX_CUSTOMERS = 50;
static_assert(MAX_CUSTOMERS + LAST_BITS <= std::numeric_limits<std::uint64_t>::digits);
static_assert(MAX_CUSTOMERS < (1U << LAST_BITS));
constexpr double INF = std::numeric_limits<double>::infinity();
// These are the same OS counters used by Python's perf_counter. Passing an
// absolute reading charges child startup and stdin parsing to the parent clock.
double parent_clock_seconds() {
#ifdef _WIN32
    LARGE_INTEGER ticks, frequency;
    QueryPerformanceCounter(&ticks); QueryPerformanceFrequency(&frequency);
    return static_cast<double>(ticks.QuadPart)/frequency.QuadPart;
#elif defined(__APPLE__)
    mach_timebase_info_data_t scale; mach_timebase_info(&scale);
    return static_cast<double>(mach_absolute_time())*scale.numer/scale.denom/1e9;
#else
    timespec now; clock_gettime(CLOCK_MONOTONIC,&now);
    return static_cast<double>(now.tv_sec)+now.tv_nsec/1e9;
#endif
}
struct Search {
    int n = 0, bins = 0, size = 0;
    double step = 0., cutoff = INF, seconds = 0., parent_stop = 0., best = INF, root_bound = 0.;
    double best_found_at = 0.;
    std::size_t cache_limit = 0;
    std::uint64_t seed = 0, nodes = 0, dominance_prunes = 0, bound_prunes = 0;
    std::uint64_t cutoff_prunes = 0, cache_skipped = 0, incumbent_updates = 0;
    std::uint64_t full = 0;
    bool timed_out = false;
    Clock::time_point started = Clock::now(), stop;
    std::vector<double> raw, suffix, service, minimum;
    std::vector<int> path, best_route;
    std::unordered_map<std::uint64_t, double> labels;

    double elapsed() const { return std::chrono::duration<double>(Clock::now()-started).count(); }
    bool expired() {
        if (timed_out || Clock::now() >= stop || parent_clock_seconds() >= parent_stop) {
            timed_out = true; return true;
        }
        return false;
    }
    std::size_t arc(int a, int b) const { return std::size_t(a)*size+b; }
    double arrival(int a, int b, double t) const {
        if (!std::isfinite(t)) return INF;
        if (a == b) return t;
        // CPython's float // uses fmod before rounding the quotient. floor(t /
        // step) alone disagrees at some binary floating-point boundaries.
        const double quotient = (t-std::fmod(t,step))/step;
        double bin = std::floor(quotient);
        if (quotient-bin > .5) bin += 1.;
        if (bin < 0. || bin >= bins) return INF; // Never extrapolate past supplied bins.
        const int m = static_cast<int>(bin);
        return std::min(t+raw[arc(a,b)*bins+m], suffix[arc(a,b)*(bins+1)+m+1]);
    }
    double finish(const std::vector<int>& route) const {
        if (route.empty()) return 0.;
        double t = 0.; int last = 0;
        for (int v : route) { t = arrival(last,v,t)+service[v]; last = v; }
        return arrival(last,0,t);
    }
    void consider(const std::vector<int>& route) {
        const double value = finish(route);
        if (std::isfinite(value) && value <= cutoff && value < best) {
            best = value; best_route = route; best_found_at = parent_clock_seconds();
            ++incumbent_updates; emit_incumbent();
        }
    }
    void emit_incumbent() const {
        std::cout<<std::setprecision(17)<<"{\"protocol\":\"V17_FIFO_TSP_WIDE_1\",\"event\":\"incumbent\",\"completion\":"
            <<best<<",\"discovered_parent_perf\":"<<best_found_at<<",\"route\":[";
        for (std::size_t k=0;k<best_route.size();++k) { if(k)std::cout<<',';std::cout<<best_route[k]-1; }
        std::cout<<"],\"nodes\":"<<nodes<<",\"states\":"<<labels.size()
            <<",\"native_wall_seconds\":"<<elapsed()<<"}\n"; std::cout.flush();
    }
    // Every future arc costs at least its minimum raw-bin duration, including
    // implicit waiting. Relax degree constraints independently, allowing cycles.
    // The max of outgoing/incoming relaxations is still a lower bound. The
    // downward rounding allowance only weakens pruning, never feasibility.
    double lower_bound(std::uint64_t mask, int last, double t) const {
        std::vector<int> left;
        for (int j=1;j<=n;++j) if (!(mask & (std::uint64_t(1)<<(j-1)))) left.push_back(j);
        if (left.empty()) return arrival(last,0,t);
        long double services = 0., outgoing = INF, incoming = INF;
        for (int j : left) {
            services += service[j];
            outgoing = std::min(outgoing, static_cast<long double>(minimum[arc(last,j)]));
            incoming = std::min(incoming, static_cast<long double>(minimum[arc(j,0)]));
        }
        for (int u : left) {
            double out = minimum[arc(u,0)], in = minimum[arc(last,u)];
            for (int v : left) if (v != u) {
                out = std::min(out,minimum[arc(u,v)]);
                in = std::min(in,minimum[arc(v,u)]);
            }
            outgoing += out; incoming += in;
        }
        const long double value = static_cast<long double>(t)+services+std::max(outgoing,incoming);
        const long double guard = 64.L*std::numeric_limits<double>::epsilon()*(n+2)*std::max(1.L,std::fabs(value));
        return std::nextafter(static_cast<double>(value-guard),-INF);
    }
    void dfs(std::uint64_t mask, int last, double t) {
        ++nodes;
        if (expired()) return;
        if (!std::isfinite(t) || t > cutoff) { ++cutoff_prunes; return; }
        if (mask == full) {
            const double value = arrival(last,0,t);
            if (std::isfinite(value) && value <= cutoff && value < best) {
                best = value; best_route = path; best_found_at = parent_clock_seconds();
                ++incumbent_updates; emit_incumbent();
            }
            return;
        }
        const std::uint64_t key = (mask<<LAST_BITS)|static_cast<std::uint64_t>(last);
        auto found = labels.find(key);
        if (found != labels.end()) {
            if (found->second <= t) { ++dominance_prunes; return; }
            found->second = t;
        } else if (labels.size() < cache_limit) labels.emplace(key,t);
        else ++cache_skipped; // Missing labels merely disable pruning.
        const double bound = lower_bound(mask,last,t);
        if (bound > cutoff || bound >= best) { ++bound_prunes; return; }
        std::vector<std::pair<double,int>> next;
        for (int j=1;j<=n;++j) if (!(mask & (std::uint64_t(1)<<(j-1)))) {
            const double at = arrival(last,j,t)+service[j];
            if (std::isfinite(at) && at <= cutoff) next.emplace_back(at,j);
        }
        std::sort(next.begin(),next.end());
        for (const auto& item : next) {
            if (expired()) return;
            path.push_back(item.second);
            dfs(mask | (std::uint64_t(1)<<(item.second-1)),item.second,item.first);
            path.pop_back();
        }
    }
    void read() {
        std::string protocol;
        if (!(std::cin>>protocol>>n>>bins>>step>>cutoff>>seconds>>parent_stop>>cache_limit>>seed)
            || protocol != "V17_FIFO_TSP_WIDE_1" || n < 0 || n > MAX_CUSTOMERS || bins <= 0
            || !std::isfinite(step) || step <= 0. || !std::isfinite(seconds) || seconds < 0.
            || !std::isfinite(parent_stop))
            throw std::runtime_error("Invalid FIFO TSP header");
        if (cutoff == -1.) cutoff = INF;
        if (std::isnan(cutoff) || cutoff < 0.) throw std::runtime_error("Invalid return cutoff");
        stop = started+std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(seconds));
        size = n+1; full = (std::uint64_t(1)<<n)-1;
        service.assign(size,0.);
        for (int j=1;j<=n;++j) if (!(std::cin>>service[j]) || !std::isfinite(service[j]) || service[j]<0.)
            throw std::runtime_error("Invalid service duration");
        raw.resize(std::size_t(size)*size*bins);
        for (double& value : raw) if (!(std::cin>>value) || !std::isfinite(value) || value<0.)
            throw std::runtime_error("Invalid raw travel duration");
        suffix.assign(std::size_t(size)*size*(bins+1),INF);
        minimum.assign(std::size_t(size)*size,INF);
        for (int a=0;a<size;++a) for (int b=0;b<size;++b) {
            const auto r = arc(a,b)*bins, s = arc(a,b)*(bins+1);
            for (int m=0;m<bins;++m) minimum[arc(a,b)] = std::min(minimum[arc(a,b)],raw[r+m]);
            for (int m=bins-1;m>=1;--m) {
                const double drop = raw[r+m-1]>raw[r+m] ? m*step+raw[r+m] : INF;
                suffix[s+m] = std::min(drop,suffix[s+m+1]);
            }
        }
    }
    void run() {
        std::vector<int> route(n); std::iota(route.begin(),route.end(),1);
        consider(route); // The supplied stage-I ordering is retained independently.
        if (n == 0) { root_bound=0.; return; }
        root_bound = lower_bound(0,0,0.);
        if (expired()) return;
        // One inexpensive FIFO nearest-arrival upper bound. No quota is reserved
        // for a separate static phase and there is no inventory recourse.
        route.clear(); std::uint64_t used=0; int last=0; double t=0.;
        std::mt19937_64 rng(seed);
        std::vector<int> tie_order(n); std::iota(tie_order.begin(),tie_order.end(),1);
        std::shuffle(tie_order.begin(),tie_order.end(),rng);
        for (int p=0;p<n;++p) {
            if (expired()) return;
            int chosen=-1; double earliest=INF;
            for (int j : tie_order) if (!(used & (std::uint64_t(1)<<(j-1)))) {
                const double at=arrival(last,j,t)+service[j];
                if (at<earliest) { earliest=at; chosen=j; }
            }
            if (chosen<0) break;
            route.push_back(chosen); used |= std::uint64_t(1)<<(chosen-1); last=chosen; t=earliest;
        }
        if (int(route.size())==n) consider(route);
        if (!expired()) dfs(0,0,0.);
    }
    void output() const {
        const bool feasible = std::isfinite(best);
        const char* status = timed_out ? "time_limit" : feasible ? "optimal" : "no_feasible";
        std::cout<<std::setprecision(17)<<"{\"protocol\":\"V17_FIFO_TSP_WIDE_1\",\"event\":\"result\",\"status\":\""<<status
            <<"\",\"optimal\":"<<(!timed_out && feasible ? "true":"false")
            <<",\"search_complete\":"<<(!timed_out ? "true":"false")
            <<",\"infeasibility_proven\":"<<(!timed_out && !feasible ? "true":"false")
            <<",\"completion\":";
        if (feasible) std::cout<<best; else std::cout<<"null";
        std::cout<<",\"route\":";
        if (!feasible) std::cout<<"null";
        else { std::cout<<'['; for (std::size_t k=0;k<best_route.size();++k) {if(k)std::cout<<',';std::cout<<best_route[k]-1;} std::cout<<']'; }
        std::cout<<",\"nodes\":"<<nodes<<",\"states\":"<<labels.size()
            <<",\"dominance_prunes\":"<<dominance_prunes<<",\"bound_prunes\":"<<bound_prunes
            <<",\"cutoff_prunes\":"<<cutoff_prunes<<",\"cache_skipped\":"<<cache_skipped
            <<",\"cache_limit\":"<<cache_limit<<",\"incumbent_updates\":"<<incumbent_updates
            <<",\"discovered_parent_perf\":"<<best_found_at
            <<",\"parent_search_deadline\":"<<parent_stop
            <<",\"root_lower_bound\":";
        if (std::isfinite(root_bound)) std::cout<<root_bound; else std::cout<<"null";
        std::cout<<",\"native_wall_seconds\":"<<elapsed()<<"}\n";
    }
};
}
int main() {
    std::ios::sync_with_stdio(false); std::cin.tie(nullptr);
    try { Search search; search.read(); search.run(); search.expired(); search.output(); return 0; }
    catch (const std::exception& error) { std::cerr<<"FIFO_TSP_ERROR "<<error.what()<<'\n'; return 2; }
}
