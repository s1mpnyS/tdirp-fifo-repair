"""Prepare, externally seal, and execute the fixed-handoff sensitivity study."""
import argparse
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
import random
import zipfile

import cell_evidence
import coordination
import runner
import sensitivity_analysis
import sensitivity_inputs
import sensitivity_probe
import timestamp


PROTOCOL = runner.HERE / "SENSITIVITY.md"
SEEDS = (20261271, 20261272)
ORDER_SEED = 20261273
BUDGET = 90.


def grid(files):
    rng = random.Random(ORDER_SEED)
    pairs = [(name, seed) for name, record in files.items() if record["alias_of"] is None for seed in SEEDS]
    rng.shuffle(pairs)
    cells, probes = [], []
    for name, seed in pairs:
        record = files[name]
        arms = list(coordination.BLOCK_SIZES)
        rng.shuffle(arms)
        for arm in arms:
            k = coordination.BLOCK_SIZES[arm]
            cell = {"cell_id": f"{len(cells):04d}", "input": name, "arm": arm, "valuation": "fifo",
                    "seed": seed, "decoder": "fifo_free_exact", "k": k, "budget_seconds": BUDGET,
                    "first_block": coordination.block_for(record, 0, k, seed=seed)}
            cells.append(cell)
            if arm == "K1":
                order = sensitivity_probe.order(record, seed)
                probes.append({**cell, "cell_id": f"p{len(probes):04d}", "source_cell": cell["cell_id"],
                               "arm": "P", "k": 6, "first_block": order[:6], "singleton_order": order,
                               "budget_seconds": sensitivity_probe.PARENT_SECONDS})
    return cells + probes


def validate_design(plan):
    files = sensitivity_inputs.inputs(plan["sensitivity_manifest"])
    if (plan["sensitivity_files"] != files or plan["cases"] != list(files) or plan["cells"] != grid(files)
            or plan["resources"] != resources(plan["resources"]["logical_cpu"])
            or Path(plan["protocol"]) != PROTOCOL or set(plan["warm_starts"]) != set(files)
            or any(plan["warm_starts"][name]["physical_sha256"] != row["physical_sha256"]
                   or plan["warm_starts"][name]["point"]["exact_feasible_objective"] != row["anchor_cost"]["objective_exact"]
                   for name, row in files.items())):
        raise ValueError("Sensitivity input roster, shared anchors, clocks or assignments differ")


def resources(cpu):
    return {"parent_seconds": BUDGET, "global_work_seconds": BUDGET - runner.RESERVE_SECONDS,
            "reserve_seconds": runner.RESERVE_SECONDS, "local_repair_cap_seconds": 6., "threads": 1,
            "logical_cpu": cpu, "tree_rss_mib": 1024., "sampling_seconds": .1, "max_monitor_gap_seconds": 1.}


def prepare(output, cpu):
    from runtime import capture_runtime

    output.mkdir(parents=True, exist_ok=False)
    source_manifest = sensitivity_inputs.generate(output / "data")
    archive = output / "sensitivity_inputs.zip"
    files, points = sensitivity_inputs.prepare_inputs(archive, source_manifest, runner.independent_verifier())
    observed = capture_runtime(cpu)
    runtime_record = output / "runtime_observed.json"
    runner.atomic(runtime_record, observed)
    binaries = {str(Path(observed[key]).resolve()): observed[key + "_sha256"]
                for key in ("python_executable", "highs_extension")}
    binaries.update({str(Path(pool["filepath"]).resolve()): runner.sha(pool["filepath"])
                     for pool in observed["loaded_threadpools"]})
    bound = {str(path): runner.sha(path) for path in runner.computational_sources()}
    bound.update({str(runner.CODE / path): sha for path, sha in sensitivity_inputs.source_hashes().items()})
    bound[str(source_manifest)] = runner.sha(source_manifest)
    plan = {"format": runner.FORMAT, "status": "PREPARED_NOT_EXTERNALLY_TIMESTAMPED", "scientific_calls_executed": 0,
            "created_utc": datetime.now(timezone.utc).isoformat(), "cohort": "sensitivity",
            "scope": "Independent fixed-handoff capacity, holding and directed escape study",
            "archive": str(archive), "archive_sha256": runner.sha(archive), "cases": list(files),
            "warm_starts": {name: {"point": point, "physical_sha256": runner.physical_signature(point)}
                            for name, point in points.items()},
            "sensitivity_manifest": str(source_manifest), "sensitivity_files": files, "cells": grid(files),
            "evidence_storage": cell_evidence.FORMAT,
            "protocol": str(PROTOCOL), "protocol_sha256": runner.sha(PROTOCOL), "resources": resources(cpu),
            "runtime_record": str(runtime_record), "runtime_record_sha256": runner.sha(runtime_record),
            "runtime_binary_sha256": binaries, "source_sha256": bound}
    plan["plan_sha256"] = runner.digest(plan)
    runner.validate_plan(plan)
    plan_path, manifest = output / "plan.json", output / "execution_freeze.json"
    runner.atomic(plan_path, plan)
    freeze_sha = timestamp.freeze(manifest, [plan_path, archive, runtime_record, PROTOCOL, *bound, *binaries],
                                  scope=plan["scope"])
    print(f"Prepared {len(plan['cells'])} real assignments. Execution manifest SHA-256 {freeze_sha}", flush=True)


def components(instance, point):
    fields = sensitivity_inputs.cost_components(instance, point)
    return {"route_completion": fields["route_completion"], "customer_inventory_units": fields["customer_inventory_units"],
            "customer_holding": fields["customer_holding_cost"], "depot_holding": fields["supplier_holding_cost"]}


def cost_row(record, instance, start, cell, parent):
    row = {"family": record["family"], "input": record["base_input"], "treatment": record["treatment"],
           "seed": cell["seed"], "arm": cell["arm"], "alias_of": record["alias_of"], "capacity": record["Q"],
           "start_cost": start["exact_feasible_objective"], "final_cost": None, "status": "not_run",
           "start_period_loads": record["anchor_loads"], "start_period_load_slack": record["anchor_load_slack"],
           **{"start_" + key: value for key, value in components(instance, start).items()}}
    if parent is None:
        return row
    point = parent["retained"]
    tail = parent["phase_records"].get("tail", {})
    cpu = tail.get("repair_process_cpu_ns")
    stop = parent["external_stop"]
    status = "complete"
    if parent["execution_error"] or (parent["worker_exit_code"] != 0 and stop is None):
        status = "technical_failure"
    elif stop:
        status = stop
    elif not parent["clean_resource_timing"]:
        status = "resource_timing_flag"
    elif not parent["retained_from_eligible_worker"]:
        status = "verified_anchor_retained"
    attempts = parent["attempts"]
    loads = list(map(sum, point["quantities"]))
    row.update(final_cost=point["exact_feasible_objective"], status=status, peak_load=max(loads), period_loads=loads,
               repair_cpu_s=None if cpu is None else str(Fraction(cpu, 10**9)),
               attempted_repairs=tail.get("returned_repairs"), completed_repairs=len(attempts),
               full_profile_builds=sum(a["tables_complete"] for a in attempts),
               certified_repairs=sum(a["raw_conditional_optimum_verified"] for a in attempts),
               accepted_moves=sum(a["strict_raw_gain"] for a in attempts),
               wall_seconds=parent["full_parent_seconds"], resource_timing_clean=parent["clean_resource_timing"],
               **components(instance, point))
    return row


def analyze(output, plan, index):
    verifier = runner.independent_verifier()
    cells = {(c["input"], c["seed"], c["arm"]): c for c in plan["cells"]}
    verified_archives = set()

    def load_result(cell):
        cell_id = cell["cell_id"]
        entry = index.get(cell_id)
        if not entry or "sha256" not in entry:
            return None
        path = output / "run" / "cells" / cell_id / "parent_result.json"
        if plan.get("evidence_storage") == cell_evidence.FORMAT and cell_id not in verified_archives:
            cell_evidence.verify(path.parent, entry)
            verified_archives.add(cell_id)
        if runner.sha(path) != entry["sha256"]:
            raise ValueError(f"Parent evidence drift for {cell_id}")
        row = runner.load(path)
        if row["cell"] != cell or row["identity"]["plan_sha256"] != plan["plan_sha256"]:
            raise ValueError(f"Parent evidence assignment drift for {cell_id}")
        return row

    rows, probes = [], []
    with zipfile.ZipFile(plan["archive"]) as archive:
        for name, record in plan["sensitivity_files"].items():
            instance = verifier.parse_instance(archive.read(name))
            start = verifier.verify_physical(instance, plan["warm_starts"][name]["point"])
            origin = record["alias_of"] or name
            for seed in SEEDS:
                for arm in coordination.BLOCK_SIZES:
                    cell = cells[origin, seed, arm]
                    parent = load_result(cell)
                    if parent and verifier.verify_physical(instance, parent["retained"]) != parent["retained"]:
                        raise ValueError("Retained endpoint failed independent replay")
                    rows.append(cost_row(record, instance, start, cell, parent))
                probe = load_result(cells[origin, seed, "P"])
                if probe and probe["clean_resource_timing"] and "probe" in probe["phase_records"]:
                    k1 = load_result(cells[origin, seed, "K1"])
                    if probe["identity"]["source_result_sha256"] != index[k1["cell"]["cell_id"]]["sha256"]:
                        raise ValueError("Probe source digest differs from indexed K1 evidence")
                    evidence = probe["phase_records"]["probe"]
                    status, hit, attempted, deadline = sensitivity_probe.replay(probe, k1, evidence, verifier, instance)
                    probes.append({"family": record["family"], "input": record["base_input"], "seed": seed,
                                   "treatment": record["treatment"], "singleton_status": status,
                                   "joint_hit": hit, "joint_attempted": attempted, "joint_deadline": deadline})
    report = sensitivity_analysis.summarize(rows, probes)
    return {"plan_sha256": plan["plan_sha256"], "assigned_cells": len(plan["cells"]),
            "recorded_cells": len(index), "rows": rows, "probes": probes, "analysis": report}


def execute(output):
    plan_path, manifest = output / "plan.json", output / "execution_freeze.json"
    plan = runner.load(plan_path)
    runner.validate_plan(plan)
    run = output / "run"
    run.mkdir(exist_ok=False)
    receipt = output / "receipt"
    print("Requesting timestamp for the frozen SHA-256 digest", flush=True)
    timestamp.stamp(manifest, receipt)
    runner.atomic(run / "external_timestamp_verified_before_first_scientific_cell.json",
                  runner.external_freeze(plan_path, plan, manifest, receipt))
    index = {}
    for cell in plan["cells"]:
        runner.validate_plan(plan)
        cell_id = cell["cell_id"]
        folder = run / "cells" / cell_id
        source = None
        if cell["arm"] == "P":
            source = run / "cells" / cell["source_cell"] / "parent_result.json"
            if runner.sha(source) != index[cell["source_cell"]]["sha256"]:
                raise ValueError("K1 source evidence changed before probing")
            try:
                sensitivity_probe.source_identity(source, plan, cell)
            except ValueError as exc:
                index[cell_id] = {"status": "probe_endpoint_unavailable", "reason": str(exc)}
                runner.atomic(run / "progress.json", index)
                continue
        row = runner.run_one(plan_path, plan, cell, folder, manifest, receipt, probe_source=source)
        entry = {"sha256": runner.sha(folder / "parent_result.json")}
        if plan.get("evidence_storage") == cell_evidence.FORMAT:
            entry.update(cell_evidence.pack(folder))
        index[cell_id] = entry
        runner.atomic(run / "progress.json", index)
        print(f"{cell_id} {cell['arm']} {cell['seed']} {cell['input']} {row['retained']['objective_decimal']} "
              f"exit={row['worker_exit_code']} stop={row['external_stop']}", flush=True)
    runner.atomic(output / "analysis.json", analyze(output, plan, index))
    print(output / "analysis.json", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("prepare", "run", "analyze"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cpu", type=int, help="Logical CPU used during preparation and all workers")
    args = parser.parse_args()
    output = args.output.resolve()
    if args.stage == "prepare":
        import os
        import psutil
        os.environ.update(runner.THREAD_ENV)
        available = psutil.Process().cpu_affinity()
        cpu = min(available) if args.cpu is None else args.cpu
        if cpu not in available:
            parser.error(f"CPU {cpu} is unavailable in {available}")
        prepare(output, cpu)
    elif args.stage == "run":
        execute(output)
    else:
        plan = runner.load(output / "plan.json")
        runner.validate_plan(plan)
        runner.external_freeze(output / "plan.json", plan, output / "execution_freeze.json", output / "receipt")
        index = runner.load(output / "run" / "progress.json")
        runner.atomic(output / "analysis.json", analyze(output, plan, index))


if __name__ == "__main__":
    main()
