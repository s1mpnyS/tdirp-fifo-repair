"""Native complete FIFO TSP for a fixed visit set, with no inventory decisions.

Build explicitly before timing workers: ``build_executable()``. The content-hashed
binary and manifest live under the separate pilot native_build folder. A worker
never compiles or downloads anything. ``native_source_paths()`` gives the exact
source/binary/manifest closure for an outer frozen study.

``optimize_route(i, route, seconds, seed=0)`` preserves membership and uses the
frozen FifoNetwork completion clock, including service and implicit waiting.
``optimal`` certifies only this fixed-membership route problem, never the IRP.
An exhausted bounded dominance cache skips new entries without truncating DFS.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np

BASE = Path(__file__).resolve().parent
SOURCE = BASE / "fifo_tsp.cpp"
RUNTIME = Path(os.environ.get("TDIRP_N50_NATIVE_BUILD", BASE / "build")).resolve()
PROTOCOL = "V17_FIFO_TSP_WIDE_1"


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def executable_path() -> Path:
    suffix = ".exe" if os.name == "nt" else ""
    return RUNTIME / ("fifo_tsp_" + _sha(SOURCE)[:20] + suffix)


def build_manifest_path() -> Path:
    return executable_path().with_suffix(".build.json")


def native_source_paths():
    return [Path(__file__).resolve(), SOURCE, executable_path(), build_manifest_path()]


def build_executable(compiler=None) -> Path:
    """Explicit local C++17 build; never called by optimize_route."""
    executable = executable_path()
    manifest = build_manifest_path()
    if executable.is_file() and manifest.is_file():
        record = json.loads(manifest.read_text(encoding="utf-8"))
        if record.get("source_sha256") == _sha(SOURCE) and record.get("executable_sha256") == _sha(executable):
            return executable
    compiler = compiler or os.environ.get("TDIRP_CXX") or shutil.which("g++") or shutil.which("clang++")
    if not compiler:
        raise RuntimeError("C++17 compiler unavailable; pass compiler= or set TDIRP_CXX before building")
    RUNTIME.mkdir(parents=True, exist_ok=True)
    command = [str(compiler), "-std=c++17", "-O2", "-DNDEBUG", str(SOURCE), "-o", str(executable)]
    # MinGW's standalone binary must not depend on a caller's compiler DLL PATH.
    if os.name == "nt":
        command[1:1] = ["-static", "-static-libgcc", "-static-libstdc++"]
    started = time.perf_counter()
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    if result.returncode:
        raise RuntimeError("FIFO TSP compilation failed: " + result.stderr[-6000:])
    version = subprocess.run([str(compiler), "--version"], capture_output=True, text=True, check=True).stdout.splitlines()[0]
    record = {"protocol": PROTOCOL, "source_sha256": _sha(SOURCE),
              "executable_sha256": _sha(executable), "compiler_version": version,
              "command": command, "build_wall_seconds": time.perf_counter()-started,
              "commercial_solver_required": False}
    manifest.write_text(json.dumps(record, indent=2)+"\n", encoding="utf-8")
    return executable


def _completion(raw, suffix, service, step, route):
    """Independent Python copy of the literal frozen arrival rule."""
    def arrival(a, b, now):
        if math.isinf(now):
            return math.inf
        if a == b:
            return now
        m = int(now // step)
        if m < 0 or m >= raw.shape[2]:
            return math.inf
        return min(now+float(raw[a, b, m]), float(suffix[a, b, m+1]))
    now = 0.
    last = 0
    for customer in route:
        node = customer+1
        now = arrival(last, node, now)+float(service[customer])
        last = node
    return arrival(last, 0, now) if route else 0.


def optimize_route(i, route, seconds, seed=0, *, absolute_deadline=None, cache_states=1_000_000):
    """Return a verified best route, or a transparent incomplete/infeasible result.

    ``seconds`` includes validation, input/output, child startup and search.
    ``absolute_deadline`` optionally tightens that allowance in perf_counter time.
    The parent must still enforce its whole-worker process-tree limits. Native
    children inherit that job/process group; no breakaway flags are requested.
    """
    started = time.perf_counter()
    seconds = float(seconds)
    if not math.isfinite(seconds) or seconds < 0.:
        raise ValueError("seconds must be finite and nonnegative")
    end = started+seconds
    if absolute_deadline is not None:
        if not math.isfinite(float(absolute_deadline)):
            raise ValueError("absolute_deadline must be finite")
        end = min(end, float(absolute_deadline))
    selected = list(route)
    if len(selected) > 50 or any(isinstance(j, (bool, np.bool_)) or not isinstance(j, (int, np.integer)) or j < 0 or j >= i.n for j in selected) or len(set(selected)) != len(selected):
        raise ValueError("route must contain at most 50 unique valid customer indices")
    selected = [int(j) for j in selected]
    if isinstance(cache_states, bool) or int(cache_states) != cache_states or cache_states < 0:
        raise ValueError("cache_states must be a nonnegative integer")
    cache_states = int(cache_states)
    step = float(i.step_seconds)
    cutoff = float(i.deadline)
    steps = int(i.steps)
    if not math.isfinite(step) or step <= 0. or steps <= 0 or steps != i.steps or math.isnan(cutoff) or cutoff < 0.:
        raise ValueError("Invalid time-bin geometry or return cutoff")
    source_raw = np.asarray(i.travel)
    if source_raw.shape != (i.n+1, i.n+1, steps):
        raise ValueError("Raw travel dimensions do not match the instance")
    indices = [0]+[j+1 for j in selected]
    raw = np.asarray(source_raw[np.ix_(indices, indices, range(steps))], dtype=float)
    service = np.asarray(i.service, dtype=float)[selected]
    if np.any(~np.isfinite(raw)) or np.any(raw < 0.) or np.any(~np.isfinite(service)) or np.any(service < 0.):
        raise ValueError("Travel and service durations must be finite and nonnegative")
    drops = np.full((len(indices), len(indices), steps+1), np.inf)
    for m in range(1, steps):
        drops[:, :, m] = np.where(raw[:, :, m-1] > raw[:, :, m], m*step+raw[:, :, m], np.inf)
    suffix = np.minimum.accumulate(drops[:, :, ::-1], axis=2)[:, :, ::-1]
    seed_local = list(range(len(selected)))
    seed_completion = _completion(raw, suffix, service, step, seed_local)
    seed_feasible = math.isfinite(seed_completion) and seed_completion <= cutoff

    def fallback(reason, **extra):
        result = {"protocol": PROTOCOL, "status": "time_limit", "optimal": False,
                  "search_complete": False, "infeasibility_proven": False,
                  "route": selected[:] if seed_feasible else None,
                  "completion": seed_completion if seed_feasible else None,
                  "nodes": 0, "states": 0, "fallback_used": True,
                  "stop_reason": reason, "wall_seconds": time.perf_counter()-started,
                  "scope": "fixed_membership_fifo_completion_only", "membership": selected[:],
                  "requested_seconds": seconds, "absolute_deadline": end,
                  "clock": "frozen_FifoNetwork_raw_drop_suffix_no_extrapolation",
                  "whole_call_deadline_exceeded": time.perf_counter() > end}
        result.update(extra)
        return result

    if time.perf_counter() >= end:
        return fallback("allowance_exhausted_before_native")
    executable = executable_path()
    manifest = build_manifest_path()
    if not executable.is_file() or not manifest.is_file():
        raise RuntimeError("FIFO TSP binary unavailable; call build_executable() before timing workers")
    build = json.loads(manifest.read_text(encoding="utf-8"))
    if build.get("source_sha256") != _sha(SOURCE) or build.get("executable_sha256") != _sha(executable):
        raise RuntimeError("FIFO TSP source/binary does not match its local build manifest")
    body = " ".join(format(float(x), ".17g") for x in service)+"\n"
    body += " ".join(format(float(x), ".17g") for x in raw.ravel())+"\n"
    remaining = end-time.perf_counter()
    if remaining <= .02:
        return fallback("allowance_exhausted_during_input")
    # Leave a small declared receipt/verification allowance, never extend end.
    native_seconds = remaining-.02
    header = f"{PROTOCOL} {len(selected)} {steps} {step:.17g} {cutoff if math.isfinite(cutoff) else -1.:.17g} {native_seconds:.17g} {end-.02:.17g} {cache_states} {int(seed) & ((1 << 64)-1)}\n"
    process = subprocess.Popen([str(executable)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    watchdog_stop = False
    try:
        stdout, stderr = process.communicate(header+body, timeout=max(.001, end-time.perf_counter()))
    except subprocess.TimeoutExpired:
        process.kill()
        stdout, stderr = process.communicate()
        watchdog_stop = True
    except BaseException:
        process.kill()
        process.communicate()
        raise
    if process.returncode and not watchdog_stop:
        raise RuntimeError(f"FIFO TSP child exited {process.returncode}: {stderr[-2000:]}")
    records = []
    lines = stdout.splitlines()
    for index, line in enumerate(lines):
        try:
            record = json.loads(line)
        except json.JSONDecodeError as error:
            if watchdog_stop and index == len(lines)-1 and not stdout.endswith("\n"):
                continue  # A partial killed write cannot supply a candidate.
            raise RuntimeError("Malformed FIFO TSP native result") from error
        if not isinstance(record, dict) or record.get("protocol") != PROTOCOL or record.get("event") not in {"incumbent", "result"}:
            raise RuntimeError("Unexpected output in FIFO TSP native stream")
        records.append(record)
    if watchdog_stop:
        candidates = [r for r in records if r.get("event") == "incumbent"
                      and isinstance(r.get("discovered_parent_perf"), (int, float))
                      and math.isfinite(r["discovered_parent_perf"])
                      and r["discovered_parent_perf"] <= end]
        if not candidates:
            return fallback("python_deadline", native_exit_code=process.returncode,
                            native_seconds=native_seconds, counters_complete=False)
        result = min(candidates, key=lambda r: r["completion"]).copy()
        result.update(status="time_limit", optimal=False, search_complete=False,
                      infeasibility_proven=False, stop_reason="python_deadline",
                      counters_complete=False)
    else:
        if not records or records[-1].get("event") != "result":
            raise RuntimeError("FIFO TSP native stream lacks its final result")
        result = records[-1]
        result["counters_complete"] = True
        if result.get("parent_search_deadline") != end-.02:
            raise RuntimeError("Native FIFO TSP changed its absolute deadline")
    if result.get("protocol") != PROTOCOL or result.get("status") not in {"optimal", "time_limit", "no_feasible"}:
        raise RuntimeError("Invalid FIFO TSP native result contract")
    returned = result.get("route")
    status = result["status"]
    if (status == "optimal" and (returned is None or not result.get("optimal") or not result.get("search_complete"))) or (status == "no_feasible" and (returned is not None or not result.get("infeasibility_proven") or not result.get("search_complete") or seed_feasible)) or (status == "time_limit" and (result.get("optimal") or result.get("infeasibility_proven"))):
        raise RuntimeError("Contradictory FIFO TSP status/certificate")
    if returned is not None:
        discovered = result.get("discovered_parent_perf")
        if not isinstance(discovered, (int, float)) or not math.isfinite(discovered) or discovered > end:
            return fallback("late_or_invalid_native_incumbent", native_exit_code=process.returncode)
        if not isinstance(returned, list) or any(type(j) is not int for j in returned) or sorted(returned) != seed_local:
            raise RuntimeError("Native FIFO TSP changed route membership")
        value = _completion(raw, suffix, service, step, returned)
        if not math.isfinite(value) or value > cutoff or value != result.get("completion"):
            raise RuntimeError("Native completion disagrees with the frozen FIFO clock")
        if seed_feasible and value > seed_completion:
            raise RuntimeError("Native FIFO TSP lost the feasible seed incumbent")
        result["route"] = [selected[j] for j in returned]
    elif result.get("completion") is not None or result.get("optimal"):
        raise RuntimeError("Native FIFO TSP claimed an invalid solution")
    result.update({"native_exit_code": process.returncode, "fallback_used": False,
                   "native_seconds": native_seconds, "requested_seconds": seconds,
                   "absolute_deadline": end, "membership": selected[:],
                   "scope": "fixed_membership_fifo_completion_only",
                   "clock": "frozen_FifoNetwork_raw_drop_suffix_no_extrapolation",
                   "executable_sha256": build["executable_sha256"],
                   "whole_call_deadline_exceeded": time.perf_counter() > end})
    result["wall_seconds"] = time.perf_counter()-started
    if time.perf_counter() > end:
        result.update(status="time_limit", optimal=False, search_complete=False,
                      infeasibility_proven=False, stop_reason="python_deadline_after_verification")
    return result


if __name__ == "__main__":
    if sys.argv[1:] == ["--build"]:
        print(build_executable())
    else:
        raise SystemExit("Use --build explicitly, or import optimize_route for a fixed-membership solve")
