"""Complete two-stage assign-and-route workflow under the common FIFO model.

Independent adaptation of Touzout et al. (2022), Section 6/Algorithm 4:
full static IRP first, then fixed-membership, fixed-quantity FIFO TSPs.
The original source's moving-cost/waiting model, unavailable M=1 inputs,
Gurobi branch-and-cut and time-allocation settings are not reproduced.
"""
from __future__ import annotations

import math
from pathlib import Path
import sys
import time

BASE = Path(__file__).resolve().parent
for directory in (BASE, BASE.parent/"tdirp_newalgo", BASE.parent/"tdirp_math_audit"):
    if str(directory) not in sys.path:
        sys.path.insert(0,str(directory))
from schedule_repair import verify_routes
from static_irp import solve_static
from fifo_tsp_wide import optimize_route

METHOD = "two_stage_irp_fifo"
STATIC_SHARE = .50
SCOPE = ("independent implementation of the complete static-IRP then fixed-y/q/I FIFO-routing workflow; "
         "common completion model, reconstructed raw-bin static means and 50% static-phase cap; "
         "not the authors' software, original moving-cost model or published result reproduction")


def optimize(i, initial, method=METHOD, seed=20261151, deadline=None, publish=None, *, static_solver=solve_static):
    if method != METHOD or deadline is None or not math.isfinite(deadline):
        raise ValueError("Expected the declared method and finite absolute deadline")
    started = time.perf_counter()
    verified = verify_routes(i,initial["routes"],initial["quantities"],"completion")
    if not verified.get("checked") or abs(verified["objective_decimal"]-initial["objective"]) > 1e-7:
        raise ValueError("Full common start failed literal verification")
    best = verified
    phase_one = None
    phase_one_plan = None
    best_origin = "common_start"
    period_reports = []
    fixed_quantities = None
    fixed_membership = None
    completed = False
    candidate_available = False
    last_candidate = None
    last_candidate_plan = None
    failure = None
    counters = {"static_irp_calls":0,"static_feasible_solutions":0,"td_tsp_calls":0,
                "td_tsp_optimal_returns":0,"td_tsp_time_limits":0,"td_tsp_nodes":0,
                "td_tsp_states":0,"verified_complete_candidates":0,"accepted_complete_candidates":0,
                "inventory_recourse_calls_in_phase_two":0}

    def record(status):
        return {"method":METHOD,"seed":seed,"status":status,"scope":SCOPE,
                "objective":best["objective_decimal"],"routes":best["routes"],
                "quantities":best["quantities"],"independent_verification":best,
                "initial_objective":initial["objective"],"global_bound":None,"global_gap":None,
                "conditional_lower_bound":None,"conditional_optimum_verified":False,
                "iterations":counters["td_tsp_calls"],"improvements":counters["accepted_complete_candidates"],
                "counters":dict(counters),"phase_one_report":phase_one,
                "phase_one_plan":phase_one_plan,"retained_origin":best_origin,
                "phase_two_periods":[dict(row) for row in period_reports],
                "workflow_completed":completed,"baseline_candidate_available":candidate_available,
                "last_complete_candidate_objective":last_candidate,"pipeline_failure_reason":failure,
                "last_complete_candidate_plan":last_candidate_plan,
                "static_phase_fraction":STATIC_SHARE,"quantities_fixed_in_phase_two":True,
                "visits_fixed_in_phase_two":True,"inventories_fixed_in_phase_two":True,
                "search_wall_seconds":time.perf_counter()-started}

    def emit(status):
        if publish is not None:
            public_status = status if status in {"initialized","complete","pipeline_unavailable","time_limit"} else "searching"
            value = record(public_status)
            value["workflow_phase"] = status
            publish(value)

    def consider(routes, quantities, status):
        nonlocal best,candidate_available,last_candidate,best_origin,last_candidate_plan
        checked = verify_routes(i,routes,quantities,"completion")
        if not checked.get("checked"):
            return False
        candidate_available = True
        last_candidate = checked["objective_decimal"]
        last_candidate_plan = checked
        counters["verified_complete_candidates"] += 1
        if checked["objective_decimal"] < best["objective_decimal"]-1e-7:
            best = checked
            best_origin = "static_phase" if status == "phase_one_verified" else "routing_phase"
            counters["accepted_complete_candidates"] += 1
        emit(status)
        return True

    emit("initialized")
    if time.perf_counter() >= deadline:
        failure = "no_search_allowance_after_setup"
        emit("time_limit")
        return record("time_limit")
    phase_deadline = started+STATIC_SHARE*max(0.,deadline-started)
    counters["static_irp_calls"] += 1
    solved = static_solver(i,initial,phase_deadline,seed)
    phase_one = {key:value for key,value in solved.items() if key not in
                 {"routes","quantities","inventory","inventories","matrix","solution","model"}}
    if not solved.get("success"):
        failure = "static_phase_no_feasible_plan"
        emit("pipeline_unavailable")
        return record("pipeline_unavailable")
    counters["static_feasible_solutions"] += 1
    routes = [[int(k) for k in route] for route in solved["routes"]]
    if any(not math.isfinite(float(v)) or abs(float(v)-round(float(v))) > 1e-6
           for row in solved["quantities"] for v in row):
        raise ValueError("Static phase returned nonintegral physical deliveries")
    fixed_quantities = [[int(round(float(v))) for v in row] for row in solved["quantities"]]
    phase_one_plan = {"routes":[list(route) for route in routes],
                      "quantities":[list(row) for row in fixed_quantities]}
    fixed_membership = [frozenset(route) for route in routes]
    if len(routes) != i.horizon or len(fixed_quantities) != i.horizon:
        raise ValueError("Static phase returned a wrong horizon")
    consider(routes,fixed_quantities,"phase_one_verified")
    for period in range(i.horizon):
        remaining = deadline-time.perf_counter()
        if remaining <= .01:
            failure = "phase_two_budget_exhausted_before_all_periods"
            break
        # Recomputing this quota redistributes time saved on every earlier period.
        quota = remaining/(i.horizon-period)
        answer = optimize_route(i,routes[period],quota,seed+period,
                                absolute_deadline=deadline)
        counters["td_tsp_calls"] += 1
        counters["td_tsp_nodes"] += int(answer.get("nodes",0))
        counters["td_tsp_states"] += int(answer.get("states",0))
        counters["td_tsp_optimal_returns"] += bool(answer.get("optimal"))
        counters["td_tsp_time_limits"] += answer.get("status") == "time_limit"
        period_reports.append({"period":period,"quota_seconds":quota,
                               **{k:v for k,v in answer.items() if k not in {"route","command"}}})
        route = answer.get("route")
        if route is None:
            failure = "fixed_membership_route_unavailable_in_declared_quota"
            break
        route = [int(k) for k in route]
        if len(route) != len(fixed_membership[period]) or frozenset(route) != fixed_membership[period]:
            raise ValueError("Phase two changed a fixed membership")
        routes[period] = route
        consider(routes,fixed_quantities,"phase_two_verified")
    else:
        completed = consider(routes,fixed_quantities,"workflow_candidate_verified")
        if not completed:
            failure = "complete_fixed_quantity_plan_failed_literal_verification"
    emit("complete" if completed else "pipeline_unavailable")
    return record("complete" if completed else "pipeline_unavailable")
