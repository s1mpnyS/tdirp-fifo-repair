"""Monitored full workflow and matched-budget two-stage comparisons."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
from fractions import Fraction
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PureWindowsPath
import random
import subprocess
import sys
import time
import zipfile

import cell_evidence
import confirmation
import coordination

HERE = Path(__file__).resolve().parent
CODE = HERE.parents[1]
ART = CODE / "research_artifacts"
FORMAT = "tdirp_v17_n50_server_v1"
RESERVE_SECONDS = 3.
CASE_COUNT = 2
COHORTS = {"valuation": {"J": "fifo", "S": "static"}, "matched": {"A": None, "J": "fifo"},
           "decoder": {"J": "fifo", "G": "fifo"}, "confirmation": {"A+": None, "G": "fifo", "J": "fifo"},
           "coordination": {arm: "fifo" for arm in coordination.BLOCK_SIZES}}
INDEXED_COHORTS = {"confirmation": confirmation.BUDGET, "coordination": coordination.BUDGET}
REPAIR_DECODERS = {"J": "fifo_free_exact", "S": "fifo_free_exact", "G": "fifo_greedy_legacy",
                   "K1": "fifo_free_exact", "K6": "fifo_free_exact"}
ALGORITHM_SEED, ORDER_SEED = 20261233, 20261234
THREAD_ENV = {name: "1" for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
                                      "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    with cell_evidence.open_bytes(path) as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    path = Path(path)
    opener = gzip.open(path, "rb") if path.suffix == ".gz" else cell_evidence.open_bytes(path)
    with opener as stream:
        return json.load(stream)


def atomic(path, value, *, compact=False):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=None if compact else 2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def module_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def independent_verifier():
    return module_file("_v13_independent_physical", CODE / "validate_v10_reference.py")


def exact(point):
    return Fraction(point["exact_feasible_objective"])


def physical_signature(point):
    return digest({name: point[name] for name in ("routes", "quantities")})


def block_for(case, attempt, record=None, *, seed=confirmation.SEED):
    if type(attempt) is not int or attempt < 0:
        raise ValueError("Nonnegative repair-return ordinal required")
    if record is not None:
        n, key = record["n"], f"confirm|{seed}|{record['sha256']}"
    else:
        n, key = int(case.split("/")[1].split("_")[1]), f"v16-n50|{ALGORITHM_SEED}|{case}"
    return sorted(range(n), key=lambda customer: hashlib.sha256(
        f"{key}|{attempt}|{customer}".encode()).digest())[:6]


def build_cells(cases, cohort, budget, files=None, *, robustness=False):
    fixed = cohort == "coordination"
    if cohort in INDEXED_COHORTS:
        settings = coordination if fixed else confirmation
        arms = COHORTS[cohort]
        if robustness:
            ordered = confirmation.robustness_order(cases, arms, settings.ROBUSTNESS_SEEDS,
                                                   settings.ROBUSTNESS_ORDER_SEED)
        else:
            ordered = ((case, arm, settings.SEED)
                       for case, arm in confirmation.order(cases, arms, settings.ORDER_SEED))
    else:
        if robustness:
            raise ValueError("Robustness is defined only for confirmation and coordination")
        ordered = [(case, arm, ALGORITHM_SEED) for case in cases for arm in COHORTS[cohort]]
        random.Random(ORDER_SEED).shuffle(ordered)
    cells = []
    for index, (case, arm, seed) in enumerate(ordered):
        k = coordination.BLOCK_SIZES[arm] if fixed else 6
        record = None if files is None else files[case]
        first = (coordination.block_for(record, 0, k, seed=seed) if fixed else
                 block_for(case, 0, record, seed=seed))
        cells.append({"cell_id": f"{index:04d}", "input": case, "arm": arm,
                      "valuation": COHORTS[cohort][arm], "seed": seed, "decoder": REPAIR_DECODERS.get(arm),
                      "k": k, "budget_seconds": budget, "first_block": first})
    return cells


def phase_work_deadline(parent_start, phase_start, global_work_seconds, phase_cap, reserve):
    """No phase clock reset can extend the global scientific deadline."""
    numbers = (parent_start, phase_start, global_work_seconds, phase_cap, reserve)
    if any(type(value) not in (int, float) or not math.isfinite(value) for value in numbers):
        raise ValueError("Finite phase clocks required")
    if min(global_work_seconds, phase_cap) <= 0 or not 0 <= reserve < phase_cap:
        raise ValueError("Invalid phase budget/reserve")
    return min(parent_start + global_work_seconds, phase_start + phase_cap - reserve)


def computational_sources():
    paths = list((CODE / "tdirp_v11").glob("*.py"))
    for folder in ("tdirp_math_audit", "tdirp_v8", "tdirp_v9"):
        paths += list((ART / folder).glob("*.py"))
    paths += [ART / "tdirp_newalgo/schedule_repair.py", ART / "tdirp_newalgo/routing_initializer.py",
              ART / "tdirp_v3/frozen_start.py", ART / "tdirp_v3/joint_repair.py",
              ART / "tdirp_v10/execution.py", CODE / "validate_v10_reference.py", ART / "tdirp_v9/fifo_tsp.cpp"]
    paths += list(HERE.glob("*.py"))
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError("Incomplete scientific source/runtime closure: " + ", ".join(missing))
    return sorted(set(path.resolve() for path in paths))


def pilot_inputs():
    materials = HERE / "data"
    archive, provenance = materials / "synthetic_inputs.zip", materials / "input_manifest.json"
    data = load(provenance)
    if (data["status"] != "VERIFIED_SYNTHETIC_WITNESSES" or data["optimizer_called"]
            or sha(archive) != data["archive_sha256"]):
        raise ValueError("Synthetic material provenance mismatch")
    verifier = independent_verifier()
    warm = {}
    with zipfile.ZipFile(archive) as zipped:
        for row in data["records"]:
            case = row["input"]
            payload = zipped.read(case)
            if row["n"] != 50 or hashlib.sha256(payload).hexdigest() != row["input_sha256"]:
                raise ValueError("Input identity differs")
            point = verifier.verify_physical(verifier.parse_instance(payload), row["point"])
            if point != row["point"]:
                raise ValueError("Fixed witness failed replay")
            warm[case] = point
    if len(warm) != CASE_COUNT:
        raise ValueError("Unexpected smoke cohort size")
    bound = {str(provenance): sha(provenance)}
    for historical_path, expected in data["bound_sources"].items():
        name = PureWindowsPath(historical_path).name
        if name == "assignment_matrix.json":
            # Historical V15 separation check, retained in the input provenance.
            continue
        source = str(materials / name)
        if sha(source) != expected:
            raise ValueError("Synthetic generator provenance drift")
        bound[source] = expected
    return archive, warm, bound


def prepare(path, cohort, budget, cpu, source_run=None, *, robustness=False):
    path = Path(path).resolve()
    if path.exists():
        raise FileExistsError("Refusing to overwrite prepared plan")
    if cohort not in COHORTS or not math.isfinite(budget) or budget < 60:
        raise ValueError("Choose a declared cohort and a budget of at least 60 seconds")
    if robustness and cohort not in INDEXED_COHORTS:
        raise ValueError("Robustness is defined only for confirmation and coordination")
    if (cohort == "coordination") != (source_run is not None):
        raise ValueError("Pass the original confirmation run only for coordination")
    files, start_sources = None, None
    protocol, scope = HERE / "README.md", "Exploratory server run on two reused synthetic n=50 inputs"
    if cohort in INDEXED_COHORTS:
        if budget != INDEXED_COHORTS[cohort]:
            raise ValueError(f"Incorrect frozen budget for {cohort}")
        archive = path.with_name("confirmation_inputs.zip")
        files, points = confirmation.prepare_inputs(archive, independent_verifier())
        data_files = (confirmation.MANIFEST, confirmation.DATA / "generation_manifest.json")
        data_hashes = {str(source): sha(source) for source in data_files}
        protocol = confirmation.PROTOCOL
        scope = "Prospective A+/G/J comparison on 40 synthetic variants from 10 latent families"
        if cohort == "coordination":
            points, start_sources = coordination.load_starts(source_run, files, independent_verifier())
            data_hashes[str(coordination.REFERENCE)] = coordination.REFERENCE_SHA256
            protocol = coordination.PROTOCOL
            scope = "Fixed-handoff K1/K6 follow-up on the 40 reused synthetic confirmation inputs"
    else:
        archive, points, data_hashes = pilot_inputs()
    warm = {name: {"point": point, "physical_sha256": physical_signature(point)}
            for name, point in points.items()}
    cases = list(warm)
    runtime_record = path.with_name("runtime_observed.json")
    runtime = load(runtime_record)
    if runtime["affinity"]["affinity_readback"] != [cpu]:
        raise ValueError("Runtime capture does not match the selected CPU")
    binaries = {str(Path(runtime[key]).resolve()): runtime[key + "_sha256"]
                for key in ("python_executable", "highs_extension")}
    binaries.update({str(Path(pool["filepath"]).resolve()): sha(pool["filepath"])
                     for pool in runtime["loaded_threadpools"]})
    bound = {str(source): sha(source) for source in computational_sources()}
    bound.update(data_hashes)
    if robustness:
        bound[str(confirmation.ROBUSTNESS_PROTOCOL)] = sha(confirmation.ROBUSTNESS_PROTOCOL)
        scope += ". Two prespecified additional algorithm seeds"
    if cohort != "coordination":
        native_check = path.with_name("native_check.json")
        check = load(native_check)
        if check["status"] != "PASS" or check["scientific_inputs_used"]:
            raise ValueError("Wide TSP verification unavailable")
        for source, expected in check["hashes"].items():
            if sha(source) != expected:
                raise ValueError("Verified native module or build changed")
            bound[source] = expected
        bound[str(native_check)] = sha(native_check)
    plan = {
        "format": FORMAT, "status": "PREPARED_NOT_EXTERNALLY_TIMESTAMPED", "scientific_calls_executed": 0,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": scope,
        "cohort": cohort,
        "archive": str(archive), "archive_sha256": sha(archive), "cases": cases, "warm_starts": warm,
        "protocol": str(protocol), "protocol_sha256": sha(protocol),
        "cells": build_cells(cases, cohort, budget, files, robustness=robustness),
        "resources": {"parent_seconds": budget, "global_work_seconds": budget - RESERVE_SECONDS,
            "reserve_seconds": RESERVE_SECONDS, "local_repair_cap_seconds": 6., "threads": 1, "logical_cpu": cpu,
            "tree_rss_mib": 1024., "sampling_seconds": .1, "max_monitor_gap_seconds": 1.},
        "policy": {"constructor_seed": 20261141, "A_seed": 20261196, "constructor_max_patterns": 8,
            "constructor_route_starts": 8, "constructor_cap": 10., "A_cap": 30.},
        "runtime_record": str(runtime_record), "runtime_record_sha256": sha(runtime_record),
        "runtime_binary_sha256": binaries, "source_sha256": bound,
    }
    if files is not None:
        plan["confirmation_files"] = files
        plan["policy"].update(constructor_seed=confirmation.SEED, A_seed=confirmation.SEED)
    if start_sources is not None:
        plan["coordination_handoffs"] = start_sources
    if robustness:
        plan["robustness"] = True
        plan["evidence_storage"] = cell_evidence.FORMAT
    plan["plan_sha256"] = digest(plan)
    validate_plan(plan)
    atomic(path, plan)
    return plan


def validate_plan(plan):
    if plan.get("format") != FORMAT or digest({name: value for name, value in plan.items() if name != "plan_sha256"}) != plan.get("plan_sha256"):
        raise ValueError("Protocol format/content digest changed")
    if plan.get("evidence_storage") not in (None, cell_evidence.FORMAT):
        raise ValueError("Unknown cell evidence storage policy")
    if plan.get("cohort") == "sensitivity":
        from sensitivity import validate_design
        validate_design(plan)
    else:
        validate_existing_design(plan)
    if plan.get("scientific_calls_executed") != 0:
        raise ValueError("Frozen protocol must remain the pre-outcome document")
    checks = {**plan["source_sha256"], **plan["runtime_binary_sha256"],
        plan["archive"]: plan["archive_sha256"], plan["runtime_record"]: plan["runtime_record_sha256"],
        plan["protocol"]: plan["protocol_sha256"]}
    for path, expected in checks.items():
        if sha(path) != expected:
            raise ValueError("Frozen source/data/provenance/runtime changed: " + path)
    for item in plan["warm_starts"].values():
        if physical_signature(item["point"]) != item["physical_sha256"]:
            raise ValueError("Fixed known warm start changed")
    if plan["cohort"] == "coordination":
        imported = plan["coordination_handoffs"]
        if set(imported) != set(plan["cases"]) or any(
                record["physical_sha256"] != plan["warm_starts"][name]["physical_sha256"]
                or record["objective_exact"] != plan["warm_starts"][name]["point"]["exact_feasible_objective"]
                for name, record in imported.items()):
            raise ValueError("Coordination handoff provenance differs")


def validate_existing_design(plan):
    files = plan.get("confirmation_files")
    budget = plan["resources"]["parent_seconds"]
    robustness = plan.get("robustness", False)
    if type(robustness) is not bool or (robustness and (
            str(confirmation.ROBUSTNESS_PROTOCOL) not in plan["source_sha256"]
            or plan["cohort"] not in INDEXED_COHORTS)):
        raise ValueError("Missing or invalid robustness policy")
    if plan["cohort"] in INDEXED_COHORTS:
        locked = confirmation.inputs()
        if budget != INDEXED_COHORTS[plan["cohort"]] or files != locked or plan["cases"] != list(locked):
            raise ValueError("Indexed cohort inputs or budget changed")
    elif len(plan["cases"]) != CASE_COUNT or files is not None:
        raise ValueError("Unexpected pilot input selection")
    if plan["cells"] != build_cells(plan["cases"], plan["cohort"], budget, files, robustness=robustness):
        raise ValueError("Assigned grid changed")


def external_freeze(plan_path, plan, manifest_path, receipt_folder):
    manifest = load(manifest_path)
    members = {str(Path(item["path"]).resolve()): item["sha256"] for item in manifest.get("members", [])}
    required = {str(Path(plan_path).resolve()): sha(plan_path), **plan["source_sha256"], **plan["runtime_binary_sha256"],
        plan["archive"]: plan["archive_sha256"], plan["runtime_record"]: plan["runtime_record_sha256"],
        plan["protocol"]: plan["protocol_sha256"]}
    if any(members.get(path) != expected for path, expected in required.items()):
        raise ValueError("External freeze does not bind exact n50 protocol/source/known-start closure")
    timestamp = module_file("_v13_external_timestamp", HERE / "timestamp.py")
    proof = timestamp.verify(manifest_path, receipt_folder)
    if proof.get("status") != "VERIFIED_EXTERNAL_TIMESTAMP_AND_MEMBER_BYTES":
        raise ValueError("Cryptographic external freeze verification unavailable")
    return proof


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def assignment(args, plan):
    matches = [cell for cell in plan["cells"] if cell["cell_id"] == args.cell_id]
    if len(matches) != 1 or not _finite(args.parent_start):
        raise ValueError("Scientific assignment not in frozen grid")
    cell = matches[0]
    result = {"cell": cell, "parent_start": args.parent_start, "budget_seconds": cell["budget_seconds"],
              "plan_sha256": plan["plan_sha256"], "warm_physical_sha256": plan["warm_starts"][cell["input"]]["physical_sha256"]}
    if cell["arm"] == "P":
        from sensitivity_probe import source_identity
        result.update(source_identity(args.probe_source, plan, cell))
    return result


def validate_assignment(args, plan, gate):
    expected = assignment(args, plan)
    if gate.get("job_attached") is not True or gate.get("assignment") != expected:
        raise ValueError("Job assignment identity or known warm start differs")
    if not gate.get("manifest_path") or not gate.get("receipt_folder"):
        raise ValueError("Verified external freeze context required")
    return expected["cell"]


def checkpoint_rejections(payload, receipt, identity, elapsed, budget, verified=None):
    rejected = []
    if not isinstance(payload, dict) or not isinstance(receipt, dict):
        return ["malformed_checkpoint_or_receipt"]
    if receipt.get("payload_sha256") != digest(payload):
        rejected.append("receipt_digest_mismatch")
    if payload.get("identity") != identity:
        rejected.append("assignment_identity_mismatch")
    completed = payload.get("completed_elapsed_since_parent")
    if not _finite(completed) or not 0 <= completed < budget:
        rejected.append("worker_completion_outside_global_budget")
    if not _finite(elapsed) or not 0 <= elapsed < budget:
        rejected.append("parent_replay_outside_global_budget")
    point = payload.get("point")
    if not isinstance(point, dict) or not isinstance(verified, dict) or verified.get("checked") is not True:
        rejected.append("independent_physical_replay_unavailable")
    elif point.get("routes") != verified.get("routes") or point.get("quantities") != verified.get("quantities"):
        rejected.append("independent_physical_plan_mismatch")
    elif point.get("exact_feasible_objective") != verified.get("exact_feasible_objective"):
        rejected.append("independent_exact_cost_mismatch")
    return rejected


def select_publication(publications, fallback):
    eligible = [record for record in publications if not record["rejections"]]
    choices = [(exact(record["verified"]), index, record) for index, record in enumerate(eligible)]
    choices.append((exact(fallback), -1, None))
    _, _, selected = min(choices, key=lambda choice: (choice[0], choice[1]))
    return (copy.deepcopy(fallback), None) if selected is None else (copy.deepcopy(selected["verified"]), selected)


def scientific_dependencies(archive):
    for path in (CODE, ART / "tdirp_math_audit", ART / "tdirp_newalgo", ART / "tdirp_v3", ART / "tdirp_v8", ART / "tdirp_v9"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    import model_probe
    import frozen_start
    model_probe.ARCHIVE = frozen_start.ARCHIVE = Path(archive)
    return model_probe


def compact_attempt(result):
    excluded = {"period_profiles", "raw_routes", "raw_quantities", "raw_verification",
                "input_verification", "retained_routes", "retained_quantities"}
    answer = {name: value for name, value in result.items() if name not in excluded}
    arrays = {"values", "routes", "static_values_exact", "valuation_values_exact"}
    answer["period_profiles"] = [{name: value for name, value in table.items() if name not in arrays}
                                for table in result.get("period_profiles", [])]
    return answer


def run_two_stage_restarts(i, two_stage, current, publish, record, directory,
                           cell, parent_start, work_end, allowance):
    from functools import partial
    from continuation import customer_order, restart_seed, solve_reordered

    static_solver = partial(solve_reordered, solve=two_stage.solve_static)
    restarts = directory / "restarts"
    restarts.mkdir(exist_ok=False)
    seen = set()
    while work_end - time.perf_counter() >= .25:
        started = time.perf_counter()
        index = len(record["restarts"])
        seed = restart_seed(cell["seed"], index)
        deadline = min(work_end, started + allowance)
        before = current()

        def progress(report):
            publish(report, "Aplus_candidate", {"restart": index, "phase": report["workflow_phase"]})

        result = two_stage.optimize(i, {**before, "objective": before["objective_decimal"]}, seed=seed,
                                    deadline=deadline, publish=progress, static_solver=static_solver)
        publish(result, "Aplus_candidate", {"restart": index, "phase": "restart_return"})
        path = restarts / f"{index:04d}.json"
        atomic(path, result, compact=True)
        after = current()
        proxy = result["phase_one_report"] or {}
        diag = proxy.get("diag", {})
        static_plan = result["phase_one_plan"]
        membership = (None if static_plan is None else
                      digest([sorted(route) for route in static_plan["routes"]]))
        record["restarts"].append({
            "index": index, "seed": seed, "customer_order_sha256": digest(customer_order(i.n, seed)),
            "start_elapsed": started - parent_start, "allowance_seconds": deadline - started,
            "return_elapsed": time.perf_counter() - parent_start,
            "input_exact": before["exact_feasible_objective"], "retained_exact": after["exact_feasible_objective"],
            "input_physical_sha256": physical_signature(before), "retained_physical_sha256": physical_signature(after),
            "static_membership_sha256": membership, "repeat_membership": membership is not None and membership in seen,
            "completed": result["workflow_completed"], "counters": result["counters"],
            "static_status": proxy.get("status"), "static_nodes": diag.get("mip_node_count"),
            "static_start_accepted": diag.get("seed_accepted"),
            "artifact": str(path), "artifact_sha256": sha(path),
        })
        if membership is not None:
            seen.add(membership)
        publish(after, "Aplus_restart_return", {"restart": index})
    record["returned_elapsed_seconds"] = time.perf_counter() - parent_start
    publish(current(), "pipeline_return")


def worker(args):
    plan = load(args.plan)
    resources = plan["resources"]
    compact = plan["cohort"] in INDEXED_COHORTS or plan["cohort"] == "sensitivity"
    assigned = next(cell for cell in plan["cells"] if cell["cell_id"] == args.cell_id)
    budget = assigned["budget_seconds"]
    reserve = resources["reserve_seconds"]
    work_seconds = budget - reserve
    runtime = module_file("_v13_runtime_contract", HERE / "runtime.py")
    affinity = runtime.pin_logical_cpu(resources["logical_cpu"])
    while not Path(args.gate).is_file():
        if time.perf_counter() >= args.parent_start + budget:
            raise TimeoutError("Process-group assignment gate unavailable")
        time.sleep(.005)
    gate = load(args.gate)
    cell = validate_assignment(args, plan, gate)
    validate_plan(plan)
    external_freeze(args.plan, plan, gate["manifest_path"], gate["receipt_folder"])
    # Every operation above and below debits the one original parent clock.
    end, work_end = args.parent_start + budget, args.parent_start + work_seconds
    directory = Path(args.folder)
    (directory / "checkpoints").mkdir(exist_ok=False)
    (directory / "attempts").mkdir(exist_ok=False)
    verifier = independent_verifier()
    with zipfile.ZipFile(plan["archive"]) as zipped:
        physical_instance = verifier.parse_instance(zipped.read(cell["input"]))
    best = cell_start(plan, cell, args, verifier, physical_instance)
    identity = assignment(args, plan)
    sequence, phase_records = 0, {}
    software = None

    def publish(point, stage, detail=None, attempt_event=None):
        nonlocal best, sequence
        checked = verifier.verify_physical(physical_instance, point)
        if time.perf_counter() >= end:
            return False
        if exact(checked) < exact(best):
            best = checked
        sequence += 1
        payload = {"identity": identity, "sequence": sequence, "stage": stage,
            "point": copy.deepcopy(best), "detail": detail, "attempt_event": attempt_event,
            "phase_records": copy.deepcopy(phase_records), "affinity": affinity, "software": software,
            "completed_elapsed_since_parent": time.perf_counter() - args.parent_start}
        path = directory / "checkpoints" / f"{sequence:06d}.json"
        atomic(path, payload, compact=compact)
        atomic(str(path) + ".commit.json", {"payload_sha256": digest(payload)})
        return True

    origin = {"coordination": "replayed_confirmation_handoff"}.get(plan["cohort"], "canonical_synthetic_witness")
    if cell["arm"] == "P":
        origin = "replayed_K1_endpoint"
    publish(best, "prior_known_warm_start", {"origin": origin, "new_feasibility_discovery_claimed": False})
    i = scientific_dependencies(plan["archive"]).read_instance(cell["input"])
    import numpy
    import scipy
    import scipy.optimize._highspy._core as highs
    from threadpoolctl import threadpool_info
    pools = threadpool_info()
    if any(pool["num_threads"] != 1 for pool in pools):
        raise RuntimeError("Numerical threadpool differs from one-thread protocol")
    expected_runtime = load(plan["runtime_record"])
    software = {"python": sys.version, "numpy": numpy.__version__, "scipy": scipy.__version__,
        "highs_version_loaded": ".".join(str(getattr(highs, "HIGHS_VERSION_" + name)) for name in ("MAJOR", "MINOR", "PATCH")),
        "loaded_threadpools": pools}
    if any(software[name] != expected_runtime[name] for name in ("numpy", "scipy", "highs_version_loaded")):
        raise RuntimeError("Loaded numerical version differs from frozen runtime")
    for path in [Path(sys.executable).resolve(), Path(highs.__file__).resolve(), *[Path(pool["filepath"]).resolve() for pool in pools]]:
        if plan["runtime_binary_sha256"].get(str(path)) != sha(path):
            raise RuntimeError("Loaded Python/HiGHS/BLAS binary differs from frozen runtime")
    software["runtime_binary_readback_verified"] = True
    if cell["arm"] == "P":
        from sensitivity_probe import audit
        report, candidate = audit(i, best, cell, work_end, verifier, physical_instance)
        phase_records["probe"] = report
        publish(candidate, "probe_return")
        return
    if plan["cohort"] in {"coordination", "sensitivity"}:
        phase_records["fixed_handoff"] = {"physical_sha256": physical_signature(best),
                                           "exact_objective": best["exact_feasible_objective"]}
        publish(best, "fixed_handoff_verified")
        run_repair_tail(i, cell, plan, directory, args.parent_start, work_end, phase_records,
                        lambda: best, publish, identity)
        return

    # Constructor setup and imports share the first ten seconds of the cell;
    # scientific construction stops at the original parent clock + seven.
    from consolidation_start import build_consolidation_plan
    ctor_deadline = phase_work_deadline(args.parent_start, args.parent_start, work_seconds, plan["policy"]["constructor_cap"], reserve)
    constructor_started = time.perf_counter()
    value = None
    constructor_seed = cell["seed"] if plan.get("robustness") else plan["policy"]["constructor_seed"]
    if constructor_started < ctor_deadline:
        value = build_consolidation_plan(i, seconds=ctor_deadline - constructor_started, deadline=ctor_deadline,
            seed=constructor_seed, memory_limit_mib=plan["resources"]["tree_rss_mib"],
            max_patterns=plan["policy"]["constructor_max_patterns"], route_starts=plan["policy"]["constructor_route_starts"])
        if value.get("success"):
            publish(value, "fresh_constructor_candidate", {"true_candidate_exact_cost": value["exact_feasible_objective"]})
    phase_records["constructor"] = {"phase_start_elapsed_seconds": 0., "scientific_start_elapsed_seconds": constructor_started - args.parent_start,
        "scientific_deadline_elapsed_seconds": ctor_deadline - args.parent_start,
        "returned_elapsed_seconds": time.perf_counter() - args.parent_start,
        "success": bool(value and value.get("success")), "failure_reason": "no_scientific_allowance_after_setup" if value is None else value.get("reason"),
        "retained_exact_objective": best["exact_feasible_objective"], "retained_physical_sha256": physical_signature(best),
        "origin": "fresh_constructor_or_prior_known_C0_retained_by_strict_true_cost"}
    phase_records["constructor"]["phase_wall_allocation_seconds"] = 10.
    phase_records["constructor"]["phase_wall_allocation_exceeded"] = time.perf_counter() > args.parent_start + 10.
    if plan.get("robustness"):
        phase_records["constructor"]["seed"] = constructor_seed
    publish(best, "constructor_return")

    A_started = time.perf_counter()
    A_cap = budget if cell["arm"] == "A" else plan["policy"]["A_cap"]
    A_deadline = phase_work_deadline(args.parent_start, A_started, work_seconds, A_cap, reserve)
    A_input = copy.deepcopy(best)
    two_stage = module_file("_v17_two_stage_wide", HERE / "two_stage_wide.py")
    A_report = None
    A_seed = cell["seed"] if plan.get("robustness") else plan["policy"]["A_seed"]
    if time.perf_counter() < A_deadline:
        def A_callback(report):
            publish(report, "two_stage", {"workflow_phase": report.get("workflow_phase"),
                "workflow_completed": report.get("workflow_completed"), "status": report.get("status"),
                "retained_origin": report.get("retained_origin"), "counters": report.get("counters"),
                "pipeline_failure_reason": report.get("pipeline_failure_reason")})
        A_report = two_stage.optimize(i, {**A_input, "objective": A_input["objective_decimal"]},
            seed=A_seed, deadline=A_deadline, publish=A_callback)
        atomic(directory / "two_stage_report.json", A_report)
        publish(A_report, "two_stage_return_candidate")
    phase_records["A"] = {"phase_start_elapsed_seconds": A_started - args.parent_start,
        "scientific_deadline_elapsed_seconds": A_deadline - args.parent_start,
        "returned_elapsed_seconds": time.perf_counter() - args.parent_start,
        "input_exact_objective": A_input["exact_feasible_objective"], "input_physical_sha256": physical_signature(A_input),
        "retained_exact_objective": best["exact_feasible_objective"], "retained_physical_sha256": physical_signature(best),
        "workflow_completed": False if A_report is None else A_report.get("workflow_completed"),
        "failure_reason": "no_remaining_A_allowance" if A_report is None else A_report.get("pipeline_failure_reason"),
        "counters": None if A_report is None else A_report.get("counters"),
        "native_periods": [] if A_report is None else [
            {"period": report["period"], "members": len(report["membership"]), "status": report["status"],
             "optimal": report.get("optimal"), "binary_sha256": report.get("executable_sha256"),
             "completion": report.get("completion")} for report in A_report["phase_two_periods"]],
        "status": None if A_report is None else A_report.get("status")}
    phase_records["A"]["phase_wall_allocation_seconds"] = min(A_cap, end - A_started)
    phase_records["A"]["phase_wall_allocation_exceeded"] = time.perf_counter() > min(end, A_started + A_cap)
    if plan.get("robustness"):
        phase_records["A"]["seed"] = A_seed
    publish(best, "two_stage_return")

    # One immutable literal handoff, with write/read/replay charged to the parent budget.
    handoff_started = time.perf_counter()
    handoff = directory / "immutable_handoff.json"
    if handoff.exists():
        raise FileExistsError("Handoff is immutable")
    atomic(handoff, best)
    handoff_digest = sha(handoff)
    restored = load(handoff)
    if sha(handoff) != handoff_digest or restored != verifier.verify_physical(physical_instance, restored):
        raise ValueError("Immutable physical handoff failed replay")
    best = restored
    phase_records["handoff"] = {"file": str(handoff), "file_sha256": handoff_digest,
        "physical_sha256": physical_signature(best), "point": copy.deepcopy(best),
        "started_elapsed_seconds": handoff_started - args.parent_start,
        "completed_elapsed_seconds": time.perf_counter() - args.parent_start,
        "feasibility_attested": True}
    publish(best, "handoff_verified")
    if cell["arm"] == "A":
        publish(best, "pipeline_return", {"returned_repairs": 0})
        return
    if cell["arm"] == "A+":
        record = phase_records["continuation"] = {"started_elapsed_seconds": time.perf_counter() - args.parent_start,
                                                  "restarts": []}
        run_two_stage_restarts(i, two_stage, lambda: best, publish, record, directory, cell, args.parent_start,
                               work_end, plan["policy"]["A_cap"] - reserve)
        return

    run_repair_tail(i, cell, plan, directory, args.parent_start, work_end, phase_records,
                    lambda: best, publish, identity)


def run_repair_tail(i, cell, plan, directory, parent_start, work_end, phase_records, incumbent, publish, identity):
    # Imports and per-repair setup debit the common clock.
    cpu_started = time.process_time_ns()
    from valued_repair import one_repair
    attempt = 0
    compact = plan["cohort"] in INDEXED_COHORTS or plan["cohort"] == "sensitivity"
    files = plan.get("confirmation_files", plan.get("sensitivity_files"))
    record = None if files is None else files[cell["input"]]
    tail_started = time.perf_counter()
    best = incumbent()
    phase_records["tail"] = {"started_elapsed_seconds": tail_started - parent_start,
        "work_deadline_elapsed_seconds": plan["resources"]["global_work_seconds"], "valuation": cell["valuation"],
        "decoder": cell["decoder"], "k": cell["k"],
        "input_exact_objective": best["exact_feasible_objective"], "input_physical_sha256": physical_signature(best)}
    while time.perf_counter() < work_end:
        current = copy.deepcopy(incumbent())
        block = (coordination.block_for(record, attempt, cell["k"], seed=cell["seed"])
                 if plan["cohort"] in {"coordination", "sensitivity"}
                 else block_for(cell["input"], attempt, record, seed=cell["seed"]))
        local_started = time.perf_counter()
        local_end = min(work_end, local_started + plan["resources"]["local_repair_cap_seconds"])
        result = one_repair(i, current, block, valuation=cell["valuation"],
                            absolute_deadline=local_end, decoder=cell["decoder"])
        summary = {**compact_attempt(result), "attempt": attempt, "block": block, "k": cell["k"],
            "valuation": cell["valuation"], "input_exact_objective": current["exact_feasible_objective"],
            "input_physical_sha256": physical_signature(current),
            "local_start_elapsed_seconds": local_started - parent_start,
            "local_allowance_seconds": max(0., local_end - local_started),
            "returned_elapsed_seconds": time.perf_counter() - parent_start}
        summary["conditional_no_improving_true_move_verified"] = bool(cell["valuation"] == "fifo"
            and result.get("raw_conditional_optimum_verified") and result.get("candidate_eligible")
            and Fraction(result["raw_exact_objective"]) >= exact(current))
        artifact = directory / "attempts" / f"{attempt:04d}.json"
        raw_point = ({"routes": result["raw_routes"], "quantities": result["raw_quantities"],
                      "exact_feasible_objective": result["raw_exact_objective"]}
                     if result.get("candidate_verified") and result.get("raw_routes") is not None else None)
        atomic(artifact, {"summary": summary, "result": result if attempt == 0 else compact_attempt(result),
                          "raw_point": raw_point}, compact=compact)
        event = {"attempt": attempt, "artifact_file": str(artifact), "artifact_sha256": sha(artifact),
                 "summary": summary}
        retained = {"routes": result["retained_routes"], "quantities": result["retained_quantities"],
                    "exact_feasible_objective": result["retained_exact_objective"]}
        publish(retained, "repair_return", {"attempt": attempt, "strict_raw_gain": result.get("strict_raw_gain")}, event)
        attempt += 1
    best = incumbent()
    phase_records["tail"].update(returned_repairs=attempt, returned_elapsed_seconds=time.perf_counter() - parent_start,
        retained_exact_objective=best["exact_feasible_objective"],
        repair_process_cpu_ns=time.process_time_ns() - cpu_started)
    publish(best, "pipeline_return", {"returned_repairs": attempt})
    atomic(directory / "worker_return.json", {"identity": identity, "phase_records": phase_records,
        "returned_repairs": attempt, "completed_elapsed_since_parent": time.perf_counter() - parent_start})


def cell_start(plan, cell, args, verifier, instance):
    if cell["arm"] == "P":
        from sensitivity_probe import source_endpoint
        return source_endpoint(args.probe_source, plan, cell, verifier, instance)
    return verifier.verify_physical(instance, plan["warm_starts"][cell["input"]]["point"])


def run_one(plan_path, plan, cell, folder, manifest_path, receipt_folder, *, probe_source=None):
    # The budget starts before parent input replay, I/O or dynamic imports.
    started = time.perf_counter()
    folder = Path(folder).resolve()
    folder.mkdir(parents=True, exist_ok=False)
    gate_path = folder / "attached.gate"
    verifier = independent_verifier()
    with zipfile.ZipFile(plan["archive"]) as zipped:
        instance = verifier.parse_instance(zipped.read(cell["input"]))
    args = argparse.Namespace(cell_id=cell["cell_id"], parent_start=started, probe_source=probe_source)
    fallback = cell_start(plan, cell, args, verifier, instance)
    identity = assignment(args, plan)
    budget = cell["budget_seconds"]
    command = [sys.executable, "-B", str(Path(__file__).resolve()), "worker", "--plan", str(plan_path),
        "--cell-id", cell["cell_id"], "--folder", str(folder), "--gate", str(gate_path), "--parent-start", repr(started)]
    if probe_source is not None:
        command += ["--probe-source", str(probe_source)]
    if os.name == "nt":
        monitor = module_file("_v13_frozen_windows_monitor", ART / "tdirp_v10/execution.py").WindowsJob
        launch_options = {"creationflags": subprocess.CREATE_NO_WINDOW}
    else:
        from process_group import LinuxProcessGroup
        monitor = LinuxProcessGroup
        launch_options = {"start_new_session": True}
    process = job = None
    samples, publications, observed_attempts = [], [], {}
    stop = error = None

    def observe():
        while True:
            path = folder / "checkpoints" / f"{len(publications) + 1:06d}.json"
            receipt_path = Path(str(path) + ".commit.json")
            if not receipt_path.is_file():
                return
            payload = receipt = checked = None
            rejected, event = [], None
            try:
                payload, receipt = load(path), load(receipt_path)
                checked = verifier.verify_physical(instance, payload["point"])
                rejected = checkpoint_rejections(payload, receipt, identity,
                    time.perf_counter() - started, budget, checked)
                if stop == "sampled_process_tree_rss_limit":
                    rejected.append("first_observation_after_memory_violation")
                event = payload.get("attempt_event")
                if event is not None:
                    if sha(event["artifact_file"]) != event["artifact_sha256"]:
                        rejected.append("attempt_artifact_digest_mismatch")
                    elif load(event["artifact_file"])["summary"] != event["summary"]:
                        rejected.append("attempt_summary_differs_from_bound_artifact")
            except Exception as exc:
                rejected.append("checkpoint_replay_error:" + type(exc).__name__ + ":" + str(exc))
            elapsed = time.perf_counter() - started
            if elapsed >= budget and "parent_replay_outside_global_budget" not in rejected:
                rejected.append("parent_replay_outside_global_budget")
            record = {"file": str(path), "receipt_file": str(receipt_path), "observed_elapsed_seconds": elapsed,
                "payload": payload, "verified": checked, "rejections": rejected}
            publications.append(record)
            if not rejected and event is not None:
                observed_attempts[event["attempt"]] = {**event["summary"], "artifact_file": event["artifact_file"],
                    "artifact_sha256": event["artifact_sha256"], "parent_observed_elapsed_seconds": elapsed}

    try:
        job = monitor()
        with (folder / "worker.log").open("w", encoding="utf-8") as log:
            process = subprocess.Popen(command, cwd=HERE, stdout=log, stderr=subprocess.STDOUT,
                env={**os.environ, **THREAD_ENV, "PYTHONIOENCODING": "utf-8",
                     "TDIRP_N50_NATIVE_BUILD": str(Path(plan_path).parent / "build")},
                **launch_options)
            job.attach(process)
            atomic(gate_path, {"job_attached": True, "assignment": identity,
                "manifest_path": str(Path(manifest_path).resolve()), "receipt_folder": str(Path(receipt_folder).resolve())})
            while True:
                sample = job.sample()
                samples.append({"elapsed_seconds": time.perf_counter() - started, **sample})
                if sample["resident_bytes"] > plan["resources"]["tree_rss_mib"] * 2 ** 20:
                    stop = "sampled_process_tree_rss_limit"
                observe()
                if process.poll() is not None:
                    observe()
                    break
                if stop or time.perf_counter() >= started + budget:
                    stop = stop or "parent_wall_limit"
                    job.terminate()
                    break
                time.sleep(min(plan["resources"]["sampling_seconds"], max(0., started + budget - time.perf_counter())))
            process.wait(timeout=10.)
    except Exception as exc:
        error, stop = type(exc).__name__ + ":" + str(exc), stop or "worker_or_monitor_failure"
        if process is not None and process.poll() is None:
            if job is not None:
                job.terminate()
            if process.poll() is None:
                process.kill()
            process.wait(timeout=10.)
    finally:
        if job is not None:
            job.close()
    retained, selected = select_publication(publications, fallback)
    eligible = [record for record in publications if not record["rejections"]]
    latest = None if not eligible else eligible[-1]["payload"]
    end_elapsed = time.perf_counter() - started
    times = [0., *[sample["elapsed_seconds"] for sample in samples], end_elapsed]
    max_gap = max((b - a for a, b in zip(times, times[1:])), default=None)
    peak = max((sample["resident_bytes"] for sample in samples), default=None)
    clean = bool(samples and error is None and max_gap <= plan["resources"]["max_monitor_gap_seconds"]
        and peak <= plan["resources"]["tree_rss_mib"] * 2 ** 20)
    first_gain = next((record["observed_elapsed_seconds"] for record in eligible if exact(record["verified"]) < exact(fallback)), None)
    target = exact(fallback) * Fraction(998, 1000)
    hit = next((record["observed_elapsed_seconds"] for record in eligible if exact(record["verified"]) <= target), None)
    phases = {} if latest is None else latest["phase_records"]
    origin = {"coordination": "fixed_replayed_two_stage_handoff"}.get(plan["cohort"], "fixed_canonical_synthetic_witness_C0")
    if cell["arm"] == "P":
        origin = "fixed_replayed_K1_endpoint"
    row = {"cell": cell, "identity": identity, "initial": fallback, "retained": retained,
        "normalizer_origin": origin, "warm_start_was_previously_available": True,
        "publication_eligible": bool(eligible), "retained_from_eligible_worker": selected is not None,
        "fallback_to_fixed_C0": selected is None, "retained_checkpoint_file": None if selected is None else selected["file"],
        "latest_eligible_checkpoint_file": None if not eligible else eligible[-1]["file"],
        "phase_records": phases, "attempts": [observed_attempts[index] for index in sorted(observed_attempts)],
        "returned_repairs_observed_by_parent": len(observed_attempts), "attempt_counter_scope": "returned repairs with timely parent-observed receipt; started-but-killed repairs unknown",
        "publications": publications, "worker_attempted": process is not None,
        "first_true_improvement_observed_seconds": first_gain, "time_to_target_seconds": hit,
        "time_to_target_censored": hit is None, "time_to_target_censor_seconds": budget,
        "budget_seconds": budget, "worker_exit_code": None if process is None else process.returncode,
        "execution_error": error, "external_stop": stop, "full_parent_seconds": end_elapsed,
        "peak_sampled_tree_rss_bytes": peak, "observed_max_sampling_gap_seconds": max_gap,
        "clean_resource_timing": clean, "samples": samples}
    atomic(folder / "parent_result.json", row, compact=plan["cohort"] in INDEXED_COHORTS or plan["cohort"] == "sensitivity")
    return row


def execute(plan_path, output, manifest_path, receipt_folder):
    plan_path, output = Path(plan_path).resolve(), Path(output).resolve()
    plan = load(plan_path)
    validate_plan(plan)
    if os.name != "nt" and sys.platform != "linux":
        raise RuntimeError("Use Linux or Windows for monitored execution")
    proof = external_freeze(plan_path, plan, manifest_path, receipt_folder)
    output.mkdir(parents=True, exist_ok=False)
    atomic(output / "external_timestamp_verified_before_first_scientific_cell.json", proof)
    indexed = plan["cohort"] in INDEXED_COHORTS
    packed = plan.get("evidence_storage") == cell_evidence.FORMAT
    rows = []
    packed_bytes = 0
    for cell in plan["cells"]:
        validate_plan(plan)
        folder = output / "cells" / cell["cell_id"]
        row = run_one(plan_path, plan, cell, folder, manifest_path, receipt_folder)
        record = {"cell_id": cell["cell_id"], "parent_result_sha256": sha(folder / "parent_result.json")} if indexed else row
        progress = {"status": "RUNNING", "planned_cells": len(plan["cells"]),
                    "completed_cells": len(rows) + 1, "last_cell_id": cell["cell_id"]}
        if packed:
            record.update(cell_evidence.pack(folder))
            packed_bytes += record["evidence_zip_bytes"]
            progress.update(packed_evidence_bytes=packed_bytes, last_cell_evidence_bytes=record["evidence_zip_bytes"])
        rows.append(record)
        if packed:
            atomic(output / "row_index.json", rows, compact=True)
        atomic(output / "progress.json", progress)
        print(json.dumps({"cell": cell["cell_id"], "arm": cell["arm"], "input": cell["input"],
                          "cost": row["retained"]["objective_decimal"],
                          "worker_exit_code": row["worker_exit_code"]}), flush=True)
        if indexed and (row["execution_error"] or
                        (row["worker_exit_code"] != 0 and row["external_stop"] is None)):
            atomic(output / "progress.json", {"status": "ABORTED_TECHNICAL_FAILURE",
                   "planned_cells": len(plan["cells"]), "completed_cells": len(rows),
                   "last_cell_id": cell["cell_id"], "worker_log": str(folder / "worker.log")})
            raise RuntimeError(f"Stopped after technical failure in {cell['cell_id']}. See {folder / 'worker.log'}")
    result = {"status": "COMPLETED", "plan_sha256": plan["plan_sha256"], "planned_cells": len(plan["cells"]),
        ("row_index" if indexed else "rows"): rows,
        "external_timestamp_verification": proof, "completed_utc": datetime.now(timezone.utc).isoformat()}
    atomic(output / "results.json", result)
    completed = {"status": "COMPLETED", "planned_cells": len(plan["cells"]), "completed_cells": len(rows)}
    if packed:
        completed["packed_evidence_bytes"] = packed_bytes
    atomic(output / "progress.json", completed)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare", help="Bind generated material and runtime; no optimizer")
    prep.add_argument("--plan", required=True)
    prep.add_argument("--cohort", choices=COHORTS, required=True)
    prep.add_argument("--seconds", type=float, required=True)
    prep.add_argument("--cpu", type=int, required=True)
    prep.add_argument("--source-run", type=Path)
    prep.add_argument("--robustness", action="store_true", help="Prepare the sealed two-new-seed grid")
    valid = sub.add_parser("validate", help="No optimization")
    valid.add_argument("--plan", required=True)
    run = sub.add_parser("run", help="Scientific execution after cryptographic external freeze")
    for name in ("plan", "output", "manifest", "receipt-folder"):
        run.add_argument("--" + name, required=True)
    run.add_argument("--execute", action="store_true", required=True)
    child = sub.add_parser("worker", help=argparse.SUPPRESS)
    for name in ("plan", "cell-id", "folder", "gate"):
        child.add_argument("--" + name, required=True)
    child.add_argument("--parent-start", type=float, required=True)
    child.add_argument("--probe-source", type=Path)
    args = parser.parse_args()
    if args.command == "prepare":
        value = prepare(args.plan, args.cohort, args.seconds, args.cpu, args.source_run, robustness=args.robustness)
        print(json.dumps({"status": value["status"], "cells": len(value["cells"]), "plan_sha256": value["plan_sha256"]}))
    elif args.command == "validate":
        value = load(args.plan)
        validate_plan(value)
        print(json.dumps({"status": "PASS", "scientific_calls_executed": 0, "plan_sha256": value["plan_sha256"]}))
    elif args.command == "worker":
        worker(args)
    else:
        value = execute(args.plan, args.output, args.manifest, args.receipt_folder)
        print(json.dumps({"status": value["status"], "cells": value["planned_cells"]}))


if __name__ == "__main__":
    main()
