"""Build, freeze and run a server cohort in a fresh output directory."""
import argparse
import math
import os
from pathlib import Path
import subprocess
import sys

import psutil
import runner
import timestamp


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cohort", choices=runner.COHORTS, default="matched")
    parser.add_argument("--seconds", type=float, default=60)
    parser.add_argument("--cpu", type=int, help="Logical CPU in the current affinity mask")
    parser.add_argument("--source-run", type=Path, help="Original confirmation output for coordination handoffs")
    parser.add_argument("--robustness", action="store_true", help="Run the sealed two-new-seed grid")
    args = parser.parse_args()
    if not math.isfinite(args.seconds) or args.seconds < 60:
        parser.error("--seconds must be finite and at least 60")
    if args.cohort in runner.INDEXED_COHORTS and args.seconds != runner.INDEXED_COHORTS[args.cohort]:
        parser.error(f"{args.cohort} requires --seconds {runner.INDEXED_COHORTS[args.cohort]:g}")
    if (args.cohort == "coordination") != (args.source_run is not None):
        parser.error("pass --source-run only for coordination")
    if args.robustness and args.cohort not in runner.INDEXED_COHORTS:
        parser.error("--robustness requires --cohort confirmation or coordination")
    if sys.platform not in {"linux", "win32"}:
        parser.error("Use Linux or Windows for monitored execution")
    available = psutil.Process().cpu_affinity()
    cpu = min(available) if args.cpu is None else args.cpu
    if cpu not in available:
        parser.error(f"CPU {cpu} is unavailable in the inherited affinity {available}")

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    env = {**os.environ, **runner.THREAD_ENV, "TDIRP_N50_NATIVE_BUILD": str(output / "build")}

    def prepare_step(module, *arguments):
        subprocess.run([sys.executable, "-B", str(runner.HERE / module), *map(str, arguments)],
                       env=env, check=True)

    if args.cohort != "coordination":
        prepare_step("fifo_tsp_wide.py", "--build")
        prepare_step("check_native.py", "--output", output / "native_check.json")
    prepare_step("runtime.py", "--output", output / "runtime_observed.json", "--cpu", cpu)
    plan_path = output / "plan.json"
    plan = runner.prepare(plan_path, args.cohort, args.seconds, cpu, args.source_run, robustness=args.robustness)
    manifest = output / "execution_freeze.json"
    receipt = output / "receipt"
    timestamp.freeze(manifest, [plan_path, plan["archive"], plan["runtime_record"], plan["protocol"],
                                *plan["source_sha256"], *plan["runtime_binary_sha256"]], scope=plan["scope"])
    print("Requesting timestamp for the frozen SHA-256 digest", flush=True)
    timestamp.stamp(manifest, receipt)
    runner.execute(plan_path, output / "run", manifest, receipt)
    print(output / "run" / "results.json", flush=True)


if __name__ == "__main__":
    main()
