"""Paired fixed-handoff sensitivity and directed escape summaries."""

from collections import Counter, defaultdict
from fractions import Fraction
import random
from statistics import median


ARMS = ("K1", "K6")
TREATMENTS = ("base", "q_mid", "q_low", "h_0_5", "h_2", "h_5")
HOLDING_MULTIPLIERS = {"h_0_5": Fraction(1, 2), "h_2": Fraction(2), "h_5": Fraction(5)}
PROBE_STATUSES = ("certified", "improving", "unresolved")
BOOTSTRAP_DRAWS = 10_000
BOOTSTRAP_SEED = 20261277
COMPONENTS = ("route_completion", "customer_inventory_units", "customer_holding", "depot_holding")
ACTIVITY = ("attempted_repairs", "completed_repairs", "full_profile_builds", "certified_repairs", "accepted_moves")


def number(value):
    return None if value is None else Fraction(str(value))


def mean(values):
    return sum(values) / len(values) if values else None


def as_float(value):
    return None if value is None else float(value)


def wtl(values):
    return [sum(value > 0 for value in values), sum(value == 0 for value in values),
            sum(value < 0 for value in values)]


def percentile_interval(values):
    if not values:
        return None
    values.sort()
    return [values[(len(values) * 25 - 1) // 1000],
            values[(len(values) * 975 - 1) // 1000]]


def bootstrap(family_values, *, ratio=False):
    """Resample entire families. A ratio draw without a denominator is undefined."""
    if not family_values:
        return None, 0
    rng = random.Random(BOOTSTRAP_SEED)
    draws = []
    for _ in range(BOOTSTRAP_DRAWS):
        sample = rng.choices(family_values, k=len(family_values))
        if ratio:
            denominator = sum(value[1] for value in sample)
            if denominator:
                draws.append(sum(value[0] for value in sample) / denominator)
        else:
            draws.append(sum(sample) / len(sample))
    return percentile_interval(draws), BOOTSTRAP_DRAWS - len(draws)


def paired_summary(values, assigned_keys, *, inference=True):
    """Average seeds within family, then weight the observed families equally."""
    by_family, by_seed = defaultdict(list), defaultdict(list)
    for (family, _, seed, _), value in sorted(values.items()):
        by_family[family].append(value)
        by_seed[seed].append(value)
    family = {name: mean(items) for name, items in by_family.items()}
    family_values = list(family.values())
    assigned_counts = Counter(key[0] for key in assigned_keys)
    available = len(values) == len(assigned_keys)
    ci = bootstrap([float(value) for value in family_values])[0] if inference else None
    return {"assigned_pairs": len(assigned_keys), "available_pairs": len(values),
            "full_grid_available": available,
            "estimate_scope": "full_grid" if available else "available_pairs_only",
            "mean_family": as_float(mean(family_values)),
            "median_family": as_float(median(family_values)) if family_values else None,
            "bootstrap_95_percentile": ci,
            "family_means": {name: float(value) for name, value in family.items()},
            "family_available_assigned_pairs": {
                name: [len(by_family[name]), assigned_counts[name]] for name in sorted(assigned_counts)},
            "seed_means": {str(seed): float(mean(items)) for seed, items in sorted(by_seed.items())},
            "family_w_t_l": wtl(family_values), "file_seed_w_t_l": wtl(list(values.values()))}


def row_key(row):
    return row["family"], row["input"], row["seed"], row["treatment"]


def prepare_pairs(rows):
    pairs, files, seeds = defaultdict(dict), {}, set()
    for row in rows:
        family, name, seed, treatment = key = row_key(row)
        arm = row["arm"]
        if arm not in ARMS or treatment not in TREATMENTS or arm in pairs[key]:
            raise ValueError(f"Unexpected or repeated arm assignment: {key}, {arm}")
        if files.setdefault(family, name) != name or type(seed) is not int:
            raise ValueError(f"Expected one original file per family and integer seeds: {key}")
        seeds.add(seed)
        pairs[key][arm] = row
    expected = {(family, name, seed, treatment) for family, name in files.items()
                for seed in seeds for treatment in TREATMENTS}
    if (not pairs or len(files) != len(set(files.values())) or set(pairs) != expected
            or any(set(arms) != set(ARMS) for arms in pairs.values())):
        raise ValueError("Sensitivity rows must enumerate the entire paired assignment grid, including failures")
    return pairs


def paired_cost(arms):
    starts = [number(arms[arm].get("start_cost")) for arm in ARMS]
    finals = [number(arms[arm].get("final_cost")) for arm in ARMS]
    if any(start is not None and (start <= 0 or (final is not None and final > start))
           for start, final in zip(starts, finals)):
        raise ValueError("An arm violates positive start objective or verified retention")
    if None in starts or None in finals:
        return None
    if starts[0] != starts[1]:
        raise ValueError("Paired endpoint objectives violate the common start")
    return starts[0], finals[0] - finals[1]


def arm_summary(rows):
    by_metric = defaultdict(list)
    measures = ("start_cost", "final_cost", "repair_cpu_s", "capacity", "peak_load", *COMPONENTS,
                *["start_" + key for key in COMPONENTS], *ACTIVITY)
    for row in rows:
        values = {key: number(row.get(key)) for key in measures}
        start, final, cpu = (values[key] for key in ("start_cost", "final_cost", "repair_cpu_s"))
        if start is not None and final is not None:
            values["objective_reduction"] = start - final
            if cpu is not None and cpu > 0:
                values["repair_efficiency_cost_per_cpu_s"] = (start - final) / cpu
                if start > 0:
                    values["repair_efficiency_pp_per_cpu_s"] = 100 * (start - final) / (start * cpu)
        for key, value in values.items():
            if value is not None:
                by_metric[key].append(value)
    all_measures = (*measures, "objective_reduction", "repair_efficiency_cost_per_cpu_s",
                    "repair_efficiency_pp_per_cpu_s")
    return {"assigned": len(rows), "status_counts": dict(Counter(row["status"] for row in rows)),
            "metrics": {key: {"available": len(by_metric[key]), "mean": as_float(mean(by_metric[key])),
                              "median": as_float(median(by_metric[key])) if by_metric[key] else None}
                        for key in all_measures}}


def escape_summary(keys, probes):
    rows = [probes.get(key, {}) for key in keys]
    statuses = Counter(row.get("singleton_status", "unresolved") for row in rows)
    grouped = defaultdict(lambda: [0, 0, 0])
    for key, row in zip(keys, rows):
        group = grouped[key[0]]
        certified = row.get("singleton_status") == "certified"
        group[0] += int(certified and row["joint_hit"])
        group[1] += int(certified)
        group[2] += 1
    by_family = [grouped[key] for key in sorted(grouped)]
    hits, certified, assigned = map(sum, zip(*by_family))
    ci_cert, undefined = bootstrap([(h / n, c / n) for h, c, n in by_family], ratio=True)
    ci_all, _ = bootstrap([h / n for h, _, n in by_family])
    joint_hits = sum(row.get("joint_hit", False) for row in rows)
    joint_attempts = sum(row.get("joint_attempted", row.get("joint_hit", False)) for row in rows)
    return {"assigned_states": assigned, "reported_probes": sum(bool(row) for row in rows),
            "singleton_status_counts": {key: statuses[key] for key in PROBE_STATUSES},
            "joint_attempts": joint_attempts, "joint_not_attempted": assigned - joint_attempts,
            "joint_hits_without_singleton_certificate": joint_hits - hits,
            "joint_deadline_returns": sum(bool(row.get("joint_deadline")) for row in rows),
            "certified_joint_hits": hits, "certification_coverage": certified / assigned,
            "escape_given_certified": hits / certified if certified else None,
            "escape_given_certified_bootstrap_95_percentile": ci_cert,
            "undefined_conditional_bootstrap_draws": undefined,
            "verified_hit_per_assigned": hits / assigned,
            "verified_hit_per_assigned_bootstrap_95_percentile": ci_all,
            "family_hit_certified_assigned": dict(sorted(grouped.items()))}


def summarize(rows, probes=None):
    """Summarize one-factor contrasts, retaining failures and duplicate-dose aliases."""
    pairs = prepare_pairs(rows)
    probe_lookup = {}
    for row in () if probes is None else probes:
        key = row_key(row)
        if (key not in pairs or key in probe_lookup or row.get("singleton_status") not in PROBE_STATUSES
                or type(row.get("joint_hit")) is not bool):
            raise ValueError(f"Invalid or duplicate directed probe: {key}")
        probe_lookup[key] = row
    costs = {key: paired_cost(arms) for key, arms in pairs.items()}
    by_treatment = {}
    for treatment in TREATMENTS:
        keys = sorted(key for key in pairs if key[3] == treatment)
        raw, gains, deltas, decomposition = {}, {}, {}, defaultdict(dict)
        for key in keys:
            if costs[key] is None:
                continue
            start, difference = costs[key]
            raw[key], gains[key] = difference, 100 * difference / start
            base_key = (*key[:3], "base")
            if treatment == "base" or costs[base_key] is None:
                continue
            base_start, base_difference = costs[base_key]
            deltas[key] = gains[key] - 100 * base_difference / base_start
            if treatment not in HOLDING_MULTIPLIERS:
                continue
            h1, h6 = (number(pairs[key][arm].get("customer_holding")) for arm in ARMS)
            if h1 is not None and h6 is not None:
                alpha = HOLDING_MULTIPLIERS[treatment]
                price_difference = (h1 - h6) * (1 - 1 / alpha)
                decomposition["plan_gap_at_base_prices_pp"][key] = (
                    100 * (difference - price_difference - base_difference) / base_start)
                decomposition["direct_price_effect_pp"][key] = 100 * price_difference / base_start
                decomposition["normalization_effect_pp"][key] = 100 * difference * (1 / start - 1 / base_start)
        report = {"joint_gain_pp": paired_summary(gains, keys),
                  "raw_objective_advantage": paired_summary(raw, keys, inference=False),
                  "paired_increment_vs_base_pp": None if treatment == "base" else paired_summary(deltas, keys),
                  "endpoint_component_advantages": {},
                  "arms": {arm: arm_summary([pairs[key][arm] for key in keys]) for arm in ARMS},
                  "pairs": [{"family": key[0], "input": key[1], "seed": key[2],
                             "joint_gain_pp": as_float(gains.get(key)),
                             "raw_objective_advantage": as_float(raw.get(key)),
                             "paired_increment_vs_base_pp": as_float(deltas.get(key)),
                             "capacity": pairs[key]["K1"].get("capacity"),
                             "start_period_loads": pairs[key]["K1"].get("start_period_loads"),
                             "alias_of": pairs[key]["K1"].get("alias_of"),
                             "status_by_arm": {arm: pairs[key][arm]["status"] for arm in ARMS}}
                            for key in keys]}
        report["alias_pairs"] = sum(row["alias_of"] is not None for row in report["pairs"])
        for component in COMPONENTS:
            differences = {}
            for key in raw:
                k1, k6 = (number(pairs[key][arm].get(component)) for arm in ARMS)
                if k1 is not None and k6 is not None:
                    differences[key] = k1 - k6
            report["endpoint_component_advantages"][component] = paired_summary(differences, keys, inference=False)
        if treatment in HOLDING_MULTIPLIERS:
            report["holding_increment_decomposition"] = {
                key: paired_summary(decomposition[key], keys, inference=False)
                for key in ("plan_gap_at_base_prices_pp", "direct_price_effect_pp", "normalization_effect_pp")}
        if probes is not None:
            report["directed_escape"] = escape_summary(keys, probe_lookup)
        by_treatment[treatment] = report
    return {"bootstrap_draws": BOOTSTRAP_DRAWS, "bootstrap_seed": BOOTSTRAP_SEED,
            "bootstrap_unit": "latent_family_with_all_seed_and_arm_pairs",
            "assigned_arm_rows": 2 * len(pairs), "treatments": by_treatment}
