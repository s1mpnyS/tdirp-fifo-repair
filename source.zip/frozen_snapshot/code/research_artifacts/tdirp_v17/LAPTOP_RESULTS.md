# Full n=50 laptop pilot

Both arms ran the visit-first constructor, the two-stage assign-and-route
adaptation, a verified handoff, and the joint repair tail. J prices the
repair profiles by FIFO completion. S prices the same type of profiles
with static arc means. Both use the true completion-plus-holding objective
for acceptance. The 60-second parent budget includes a three-second
reserve. Each input has a preverified all-visit fallback.

## Endpoints

| Synthetic input | Fallback C0 | Post-constructor | Verified two-stage handoff | Final J | Final S | J gain from handoff | S gain from handoff |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| H3, M30, generator seed 20261231 | 49,954.09 | 23,999.32 | 23,856.32 | 23,432.39 | 23,452.26 | 423.93 (1.78%) | 404.06 (1.69%) |
| H6, M120, generator seed 20261232 | 94,063.09 | 94,063.09 | 74,839.09 | 45,900.92 | 44,392.00 | 28,938.17 (38.67%) | 30,447.09 (40.68%) |

Percentages use the verified handoff cost. The physical handoff hash
matches across J and S on each input. J is lower by 19.87 on H3. S is
lower by 1,508.92 on H6. Both improve the retained handoff in the
remaining time. The experiment holds the repair structure fixed and
varies its pricing. It contains no separate greedy or matched 60-second
two-stage-only arm.

| Input | Arm | Handoff, s | Parent wall, s | Returned repair receipts | Sampled peak tree RSS, MiB | Maximum sampling gap, s |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| H3/M30 | J | 29.56 | 57.34 | 57 | 166.18 | 0.52 |
| H3/M30 | S | 28.70 | 57.35 | 60 | 164.68 | 0.48 |
| H6/M120 | J | 33.98 | 57.31 | 17 | 206.67 | 1.64 |
| H6/M120 | S | 33.90 | 57.16 | 19 | 205.15 | 2.11 |

All workers returned normally. Both H6 cells exceeded the frozen
one-second sampling-gap threshold before the first sample, so their
endpoint costs are reported with a resource-monitoring flag. Their
sampled peaks cannot establish continuous compliance.

## What ran at 50 customers

The widened native solver uses six bits for the last-node field and
keeps the state key within 64 bits. All 14 native checks passed. Both H3
cells ran native routes with 44, 30, and 20 customers. The first two
returned feasible tours at the time limit. The 20-customer tour was
certified optimal. Both H6 constructors reached their initialization
limit and used the preverified fallback. Their two-stage workflows
completed all six fixed-membership routing calls, each with 50 customers.
All 12 calls returned feasible tours at the time limit. Each H6 handoff
still visited all 50 customers in every period. Repair could then change
the membership and quantities. J reduced the sum of return times from
70,290 to 40,919, and S reduced it to 39,373, with holding cost increasing
in both cases. This explains the large post-handoff savings in this
particular pilot.

All four retained plans, immutable handoffs, complete two-stage
candidates, and eligible publication receipts passed the separate
physical replay. The replay also checked that the routing stage kept the
static membership and quantities and matched the returned period clocks.
The two synthetic files and one algorithm seed support an engineering
result and a descriptive comparison.

## External comparison

The primary algorithmic reference is Touzout, Ladier, and Hadj-Hamou
(2022), *An assign-and-route matheuristic for the time-dependent
inventory routing problem*, EJOR 300(3), 1081–1097. Its Section 6 first
fixes period visits and quantities in a static IRP and then solves the
period routing problems. Our two-stage prefix implements that
decomposition under our shared FIFO completion objective. Their
moving-time objective, free waiting, cutoff conventions, and original
solver configuration require separate alignment before comparing their
published cost values. The direct follow-up is a two-stage-only arm
that can spend the full budget on its own solver, with the same start,
instance, objective, resource rules, and independent verifier.
[Publisher](https://doi.org/10.1016/j.ejor.2021.09.025)

The same authors' 2026 *Computers & Operations Research* paper,
*Comparing four MILP formulations for the time-dependent inventory
routing problem with FIFO-compliant travel times*, is a formulation
reference for matched small-instance exact checks. Published values
need a verified mapping of the objective, holding convention, cutoff,
and input before use as a bound or benchmark.
[Publisher](https://doi.org/10.1016/j.cor.2026.107577)

The original laptop freeze and worker journals are retained in the local
research workspace. See the [server runner instructions](README.md) for
an independent execution on the same inputs.
