"""Frozen common starts and block schedules for the block-size comparison."""
import hashlib
from pathlib import Path

import confirmation


PROTOCOL = confirmation.HERE / "COORDINATION.md"
REFERENCE = confirmation.HERE.parents[1] / "reference/v17/confirmation-120-20261109T150546Z/analysis.json"
REFERENCE_SHA256 = "ad64b65ffba9eb288327989a8f362c3576e0b5f194e4ef3c39a315b435ef613b"
BUDGET, SEED, ORDER_SEED = 90., 20261241, 20261242
ROBUSTNESS_SEEDS, ROBUSTNESS_ORDER_SEED = (20261243, 20261244), 20261245
BLOCK_SIZES = {"K1": 1, "K6": 6}


def block_for(record, attempt, k, *, seed=SEED):
    """Visit every customer each sweep, wrapping its last block if needed."""
    n = record["n"]
    if type(attempt) is not int or attempt < 0 or k not in BLOCK_SIZES.values() or n < k or type(seed) is not int:
        raise ValueError("Invalid coordination attempt, block size or seed")
    sweep, batch = divmod(attempt, (n + k - 1) // k)
    schedule_sha256 = record.get("schedule_sha256", record["sha256"])
    order = sorted(range(n), key=lambda j: hashlib.sha256(
        f"coordination|{seed}|{schedule_sha256}|{sweep}|{j}".encode()).digest())
    return [order[(batch * k + j) % n] for j in range(k)]


def load_starts(source_run, files, verifier):
    """Import only pre-repair J handoffs, tied to the pinned server analysis."""
    import runner

    if runner.sha(REFERENCE) != REFERENCE_SHA256:
        raise ValueError("Pinned confirmation analysis changed")
    source = runner.load(REFERENCE)
    if source["status"] != "N50_FULL_PIPELINE_PHYSICAL_REPLAY_PASS":
        raise ValueError("Source confirmation did not pass replay")
    rows = [r for r in source["rows"] if r["arm"] == "J"]
    if len(rows) != len(files) or {r["input"] for r in rows} != set(files):
        raise ValueError("Source confirmation coverage differs")
    points, provenance = {}, {}
    for row in rows:
        name = row["input"]
        path = Path(source_run) / "run/cells" / row["cell_id"] / "immutable_handoff.json"
        if not path.is_file():
            raise FileNotFoundError(f"Original confirmation handoff required: {path}")
        payload = (confirmation.DATA / name).read_bytes()
        if confirmation.sha(payload) != files[name]["sha256"]:
            raise ValueError("Source input bytes differ: " + name)
        saved = runner.load(path)
        point = verifier.verify_physical(verifier.parse_instance(payload), saved)
        signature = runner.physical_signature(point)
        if (point != saved or not row["handoff_verified"] or row["first_repair"] is None
                or signature != row["first_repair"]["input_physical_sha256"]
                or point["objective_decimal"] != row["handoff_cost"]):
            raise ValueError("Imported handoff differs from the server replay: " + name)
        points[name] = point
        provenance[name] = {"source_cell": row["cell_id"], "source_file_sha256": runner.sha(path),
                            "physical_sha256": signature, "objective_exact": point["exact_feasible_objective"]}
    return {name: points[name] for name in files}, provenance
