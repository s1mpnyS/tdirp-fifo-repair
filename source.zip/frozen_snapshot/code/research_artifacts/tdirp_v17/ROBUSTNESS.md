# Two-seed robustness of the principal server comparisons

Keep the original 40 files, four variants per latent family, ten
families, objective, fallbacks, phases, and wall allocations in the
[coordination](COORDINATION.md) and [confirmation](CONFIRMATION.md)
protocols. This is a prespecified replication on the same families.
The previously reported seed for each cohort remains a historical
comparison and is shown separately from the new results.

| Cohort | Algorithm seeds | Assignment shuffle | Arms | Wall allocation |
| --- | --- | --- | --- | --- |
| Coordination | 20261243, 20261244 | 20261245 | K1, K6 | 90 s |
| Confirmation | 20261223, 20261224 | 20261228 | A+, G, J | 120 s |

Shuffle `(file, seed)` blocks, then shuffle arms within a block. Every
coordination block uses the original verified pre-repair J handoff and
the common seed for the customer sweep. Confirmation uses the common
cell seed in the constructor, first static solve, A+ restart schedule,
and G/J block draws. The cold prefix remains part of the confirmation
clock. Handoffs can differ under the wall limit. The original protocols
govern all other scheduling, feasibility and acceptance decisions.

The primary outcomes are the same paired differences as in the
original cohorts, normalized by the imported handoff for coordination
and by the verified canonical witness for confirmation. Report every
assignment and its fallback or resource status. For each new seed
report the matched estimate, paired whole-family interval and file and
family wins, ties and losses. For the combined new-seed estimate,
average the two matched differences per file, weight the four files
equally within each family, then weight families equally. Apply the
original 10,000 percentile bootstrap draws over complete families with
seed 20261229, keeping all paired outcomes together. Intervals describe
family-level variation conditional on these two seeds. Report the span
of their mean estimates, whether signs differ, and whether the span
reaches 0.2 percentage points. A sign reversal or a span of at least
0.2 points merits separate seed-dependent interpretation. These two
seeds give a first robustness check and provide limited information
about variation over the seed distribution. Keep same-state decoder
timing and trajectory witness counts separate by seed.

The new grids contain 160 coordination assignments and 240 confirmation
assignments, for four and eight hours of nominal sequential solve time,
respectively. Launch coordination first. Each output directory has its
own manifest and RFC 3161 timestamp binding input bytes, starts, cell
assignments, protocol, source and runtime before the first solve.
Keep all observed fallbacks and resource stops in the primary analysis.
Technical failures preserve partial evidence and abort the cohort under
the existing launcher rule. Document any interrupted run and recovery
as a deviation. The launcher provides no automatic reruns.

New robustness plans freeze a per-cell lossless evidence format. The
worker and parent retain the original receipt gate during the cell.
After the cell closes, the parent writes a ZIP of the result, attempts,
checkpoints, receipts and restart artifacts. It verifies the archive
before releasing those loose files. Replay reads the same logical
paths directly from each archive and checks both the archive hash and
the existing evidence digests. Packing is outside the measured wall
budget. `run/progress.json` reports cumulative packed bytes and the
last cell's archive size. `run/row_index.json` retains the completed
archive and parent-result hashes if the campaign is interrupted.
Leave temporary space for the next loose cell and its ZIP. A campaign
started with an older source freeze uses its original checkout and
layout. A fresh run uses a new output path.

```bash
P=code/research_artifacts/tdirp_v17
SOURCE=code/runs/confirmation-120-20261109T150546Z
OUT="code/runs/robust-coordination-$(date -u +%Y%m%dT%H%M%SZ)"
python -B "$P/run.py" --robustness --cohort coordination --seconds 90 --source-run "$SOURCE" --output "$OUT" && python -B "$P/replay.py" "$OUT"
OUT="code/runs/robust-confirmation-$(date -u +%Y%m%dT%H%M%SZ)"
python -B "$P/run.py" --robustness --cohort confirmation --seconds 120 --output "$OUT" && python -B "$P/replay.py" "$OUT"
```

Set `SOURCE` to the preserved original server output containing
`run/cells`. The tracked confirmation analysis binds the imported
starts. Keep each run in its original checkout and path for replay.
