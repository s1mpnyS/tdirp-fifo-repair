"""Frozen-config geometric TDIRP stress-set generator; standard library only.

--prepare emits ONLY a source/config freeze. --generate refuses an absent or
drifted freeze and never overwrites an output directory. No solver is imported.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from decimal import Decimal, localcontext, ROUND_CEILING
from fractions import Fraction
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import sys


DEFAULT_CONFIG = Path(__file__).with_name('synthetic_stress_v1.json')
DEFAULT_VALIDATOR = Path('D:/PyCharm/tdirp-conditional-fifo-profiles/code/validate_v10_reference.py')
SCHEMA = 'tdirp_synthetic_geometric_twopeak_v1'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ceil_fraction(value):
    value = Fraction(value)
    return -(-value.numerator // value.denominator)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')


def load_config(path):
    cfg = json.loads(Path(path).read_text(encoding='utf-8'))
    require(cfg['schema'] == SCHEMA, 'Unknown synthetic schema')
    require(cfg['n_values'] == [40, 50] and cfg['H_values'] == [3, 6] and cfg['M_values'] == [30, 120], 'Unexpected factorial grid')
    require(cfg['latent_n'] == 50 and cfg['latent_H'] == 6 and cfg['latent_M'] == 120, 'Unexpected latent dimensions')
    require(cfg['traffic_day_seconds'] == 43200 and cfg['coordinate_integer_grid'] == 1000000, 'Unexpected geometry/time domain')
    require(cfg['decimal_precision'] == 70 and cfg['raw_arc_upper_bound_seconds'] == 600, 'Unexpected arithmetic/bound')
    require(cfg['customer_service_seconds'] == 180 and cfg['minimum_inventory'] == 0, 'Unexpected service/minimum')
    seeds = cfg['family_seeds']
    require(len(seeds) == 10 and len(set(seeds)) == 10 and all(type(x) is int for x in seeds), 'Expected ten distinct integral seeds')
    return cfg


def arrival_raw(raw, step, departure):
    """Exact rational earliest-arrival waiting closure on [0,M*step)."""
    require(type(step) is int and step > 0 and raw and all(type(c) is int and c >= 0 for c in raw), 'Invalid raw arc')
    t = Fraction(departure)
    require(0 <= t < len(raw)*step, 'Departure outside traffic domain')
    b = int(t // step)
    return min([t+raw[b]] + [Fraction(j*step+raw[j]) for j in range(b+1, len(raw))])


def certify_fifo(raw, step):
    """Check ALL analytic pieces, not just departure samples.

    For t in bin b, A(t)=min(t+c_b,C_b), with C_b=min_{j>b}(j*d+c_j).
    Each piece has slope 0 or 1. Its sole potential breakpoint is C_b-c_b.
    At boundary B=(b+1)d the preceding left limit is <= the right value.
    Exact Fraction endpoint/breakpoint checks certify every half-open bin.
    """
    require(type(step) is int and step > 0 and raw and all(type(c) is int and c >= 0 for c in raw), 'Invalid raw arc')
    future = None
    breakpoints = 0
    previous_right_limit = None
    for b in range(len(raw)-1, -1, -1):
        low, high = Fraction(b*step), Fraction((b+1)*step)
        c = raw[b]
        right_value = low+c if future is None else min(low+c, future)
        left_limit = high+c if future is None else min(high+c, future)
        require(right_value <= left_limit, 'Negative slope within bin')
        if previous_right_limit is not None:
            require(left_limit <= previous_right_limit, 'Downward jump at bin boundary')
        if future is not None:
            event = future-c
            if low < event < high:
                # Both analytic branches coincide at the exact breakpoint.
                require(event+c == future and right_value <= future <= left_limit, 'Invalid ramp event')
                breakpoints += 1
        # Recurrence includes the current bin as the next bin's wait candidate.
        previous_right_limit = right_value
        candidate = low+c
        future = candidate if future is None else min(candidate, future)
    require(arrival_raw(raw, step, Fraction(0)) >= 0, 'Negative arrival')
    return {'bins': len(raw), 'interior_breakpoints': breakpoints,
            'boundary_checks': len(raw)-1, 'domain_end': len(raw)*step,
            'terminal_policy': 'Unavailable at domain end; final left limit checked analytically.',
            'proof': 'Exact all-piece slope and boundary inequalities; no epsilon or sampling grid.'}


def triangle(position, center, width):
    return max(Fraction(0), 1-abs(position-center)/width)


def draw_family(cfg, seed, n_override=None):
    """In-memory deterministic draw. Full CLI generation is freeze-gated."""
    rng = random.Random(seed)
    n = cfg['latent_n'] if n_override is None else n_override
    grid = cfg['coordinate_integer_grid']
    coordinates = [[rng.randint(0, grid), rng.randint(0, grid)] for _ in range(n+1)]
    first = Fraction(rng.randint(*cfg['first_peak_center_per_mille_inclusive']), 1000)
    second = Fraction(rng.randint(*cfg['second_peak_center_per_mille_inclusive']), 1000)
    width = Fraction(cfg['peak_half_width_per_mille'], 1000)
    heights = [Fraction(rng.randint(*cfg['peak_height_per_mille_inclusive']), 1000) for _ in range(2)]
    require(second-first >= 2*width, 'Peak supports overlap')
    peaks = [sum(h*triangle(Fraction(2*b+1, 2*cfg['latent_M']), center, width)
                 for h, center in zip(heights, (first, second))) for b in range(cfg['latent_M'])]
    # Fixed draw order: geometry, family peaks, customer attributes, directed arcs.
    supplier_holding = rng.randint(*cfg['supplier_holding_cents_inclusive'])
    customers = []
    for _ in range(n):
        base = rng.randint(*cfg['demand_base_inclusive'])
        demand = [ceil_fraction(Fraction(base*rng.randint(*cfg['demand_period_percent_inclusive']), 100)) for _ in range(cfg['latent_H'])]
        maximum_demand = max(demand)
        customers.append({'base': base, 'demand': demand, 'initial': rng.randint(0, maximum_demand),
                          'maximum': 2*maximum_demand, 'minimum': 0,
                          'holding_cents': rng.randint(*cfg['customer_holding_cents_inclusive'])})
    travel = []
    directions, loads = [], []
    with localcontext() as context:
        context.prec = cfg['decimal_precision']
        for u in range(n+1):
            for v in range(n+1):
                if u == v:
                    travel.append([0]*cfg['latent_M'])
                    directions.append(None); loads.append(None)
                    continue
                factor = rng.randint(*cfg['direction_factor_per_mille_inclusive'])
                load = rng.randint(*cfg['arc_peak_load_per_mille_inclusive'])
                squared = sum((coordinates[u][d]-coordinates[v][d])**2 for d in (0, 1))
                normalized = (Decimal(squared)/Decimal(2*grid*grid)).sqrt()
                base = Decimal(25)+Decimal(225)*normalized
                values = []
                for peak in peaks:
                    multiplier = 1+Fraction(load, 1000)*peak
                    seconds = base*Decimal(factor)/1000*Decimal(multiplier.numerator)/Decimal(multiplier.denominator)
                    values.append(int(seconds.to_integral_value(rounding=ROUND_CEILING)))
                require(max(values) <= cfg['raw_arc_upper_bound_seconds'], 'Raw travel bound exceeded')
                travel.append(values); directions.append(factor); loads.append(load)
    return {'seed': seed, 'latent_n': n, 'coordinates_integer_grid': coordinates,
            'peak_centers': [str(first), str(second)], 'peak_heights': list(map(str, heights)),
            'peak_half_width': str(width), 'supplier_holding_cents': supplier_holding,
            'customers': customers, 'travel_M120': travel,
            'direction_factors_per_mille': directions, 'arc_loads_per_mille': loads}


def restrict_travel(family, n, M):
    old_nodes = family['latent_n']+1
    require(0 < n <= family['latent_n'] and M in (30, 120), 'Invalid restriction')
    result = []
    for u, v in itertools.product(range(n+1), repeat=2):
        raw = family['travel_M120'][u*old_nodes+v]
        result.append(list(raw) if M == 120 else [(sum(raw[b:b+4])+2)//4 for b in range(0, 120, 4)])
    return result


def completion(travel, n, M, service):
    now, previous = Fraction(0), 0
    for node in range(1, n+1):
        now = arrival_raw(travel[previous*(n+1)+node], 43200//M, now)+service
        previous = node
    return arrival_raw(travel[previous*(n+1)], 43200//M, now)


def cents(value):
    return f'{value//100}.{value%100:02d}'


def serialize_variant(cfg, family, n, H, M, return_limit, travel):
    customers = family['customers'][:n]
    totals = [sum(c['demand'][p] for c in customers) for p in range(6)]
    initial = max(totals)
    production = ceil_fraction(Fraction(sum(totals), 6))
    capacity = ceil_fraction(Fraction(115*max(totals), 100))
    require(all(initial+(p+1)*production-sum(totals[:p+1]) >= 0 for p in range(6)), 'Insufficient supplier prefix supply')
    rows = [[n+1, H, capacity, M, 43200//M, return_limit],
            [1, initial]+[production]*H+[cents(family['supplier_holding_cents'])]]
    for j, customer in enumerate(customers, 2):
        rows.append([j, customer['initial'], customer['maximum'], customer['minimum']]
                    +customer['demand'][:H]+[cents(customer['holding_cents']), cfg['customer_service_seconds']])
    rows.extend(travel)
    return ('\n'.join(' '.join(map(str, row)) for row in rows)+'\n').encode('ascii')


def canonical_witness(family, n, H):
    stock = [c['initial'] for c in family['customers'][:n]]
    quantities = []
    for p in range(H):
        delivery = [max(0, c['demand'][p]-s) for c, s in zip(family['customers'][:n], stock)]
        stock = [s+q-c['demand'][p] for c, s, q in zip(family['customers'][:n], stock, delivery)]
        quantities.append(delivery)
    return {'routes': [list(range(n)) for _ in range(H)], 'quantities': quantities}


def strict_schema_check(payload, n, H, M):
    rows = [line.split() for line in payload.decode('ascii').splitlines()]
    require(len(rows) == 2+n+(n+1)**2 and len(rows[0]) == 6, 'Wrong serialized row count/header')
    require(list(map(int, rows[0][:2])) == [n+1, H] and int(rows[0][3]) == M, 'Header identity mismatch')
    require(len(rows[1]) == H+3 and rows[1][0] == '1', 'Wrong supplier ID/width')
    for j, row in enumerate(rows[2:n+2], 2):
        require(row[0] == str(j) and len(row) == H+6, 'Wrong customer ID/width')
    require(all(len(row) == M for row in rows[n+2:]), 'Wrong arc row width')


def prepare(config, validator, destination):
    cfg = load_config(config)
    require(not destination.exists(), 'Freeze destination already exists')
    source = Path(__file__).resolve()
    data = {'schema': 'tdirp_synthetic_source_freeze_v1', 'prepared_utc': datetime.now(timezone.utc).isoformat(),
            'config': str(config.resolve()), 'config_sha256': sha(config),
            'generator': str(source), 'generator_sha256': sha(source),
            'independent_validator': str(validator.resolve()), 'independent_validator_sha256': sha(validator),
            'planned_files': len(cfg['family_seeds'])*len(cfg['n_values'])*len(cfg['H_values'])*len(cfg['M_values']),
            'planned_families': len(cfg['family_seeds']), 'generated_files': 0,
            'purpose': 'Source/config freeze before dataset generation; not a scientific experiment preregistration.'}
    write_json(destination, data)
    print(json.dumps({'freeze': str(destination), 'sha256': sha(destination), 'generated_files': 0}))


def validate_freeze(freeze, expected):
    require(len(expected) == 64 and sha(freeze) == expected, 'Freeze bytes do not match supplied digest')
    data = json.loads(freeze.read_text(encoding='utf-8'))
    require(data['schema'] == 'tdirp_synthetic_source_freeze_v1', 'Wrong source freeze schema')
    require(Path(data['generator']).resolve() == Path(__file__).resolve(), 'Freeze binds another generator')
    for stem in ('config', 'generator', 'independent_validator'):
        require(sha(Path(data[stem])) == data[stem+'_sha256'], 'Frozen source drift: '+stem)
    require(datetime.fromisoformat(data['prepared_utc']) <= datetime.now(timezone.utc), 'Freeze timestamp is in future')
    return data


def generate(freeze, expected, destination):
    data = validate_freeze(freeze, expected)
    require(not destination.exists(), 'Generation directory exists; never overwrite or replace a seed')
    cfg = load_config(data['config'])
    spec = importlib.util.spec_from_file_location('_independent_physical', data['independent_validator'])
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    destination.mkdir(parents=True)
    files, proofs = [], []
    # Preserve partial artifacts if any assertion fails; no automatic retry or seed replacement.
    write_json(destination/'generation_started.json', {'started_utc': datetime.now(timezone.utc).isoformat(), 'freeze_sha256': expected})
    for seed in cfg['family_seeds']:
        family = draw_family(cfg, seed)
        latent_path = destination/f'family_{seed}.json'
        write_json(latent_path, family)
        files.append({'path': latent_path.name, 'sha256': sha(latent_path), 'kind': 'latent_family'})
        for n in cfg['n_values']:
            travels = {M: restrict_travel(family, n, M) for M in cfg['M_values']}
            returns = {M: completion(travels[M], n, M, cfg['customer_service_seconds']) for M in cfg['M_values']}
            limit = ceil_fraction(Fraction(105, 100)*max(returns.values()))
            require(limit < cfg['traffic_day_seconds'], 'Canonical cutoff outside traffic day')
            for M, travel in travels.items():
                certs = [certify_fifo(raw, cfg['traffic_day_seconds']//M) for raw in travel]
                proofs.append({'family_seed': seed, 'n': n, 'M': M, 'arcs': len(certs),
                               'bins_checked': sum(c['bins'] for c in certs),
                               'boundary_checks': sum(c['boundary_checks'] for c in certs),
                               'interior_breakpoints': sum(c['interior_breakpoints'] for c in certs)})
            for H, M in itertools.product(cfg['H_values'], cfg['M_values']):
                payload = serialize_variant(cfg, family, n, H, M, limit, travels[M])
                strict_schema_check(payload, n, H, M)
                instance = validator.parse_instance(payload)
                point = canonical_witness(family, n, H)
                checked = validator.verify_physical(instance, point)
                require(checked['return_times'] == [int(returns[M])]*H, 'Independent clock differs from constructive clock')
                name = f'synthetic_seed{seed}_H{H}_n{n}_M{M}.txt'
                path = destination/name
                path.write_bytes(payload)
                witness_path = destination/(name+'.witness.json')
                write_json(witness_path, checked)
                files.extend([{'path': name, 'sha256': sha(path), 'kind': 'synthetic_instance', 'family_seed': seed, 'n': n, 'H': H, 'M': M},
                              {'path': witness_path.name, 'sha256': sha(witness_path), 'kind': 'physical_witness'}])
    count = sum(row['kind'] == 'synthetic_instance' for row in files)
    require(count == data['planned_files'] == 80, 'Incomplete material generation')
    write_json(destination/'generation_manifest.json', {'status': 'COMPLETE_VALIDATED',
               'finished_utc': datetime.now(timezone.utc).isoformat(), 'freeze_sha256': expected,
               'provenance': cfg['provenance'], 'family_count': len(cfg['family_seeds']),
               'instance_count': count, 'files': files, 'fifo_certificates': proofs,
               'optimizer_called': False, 'independent_validator_sha256': data['independent_validator_sha256']})
    print(json.dumps({'status': 'COMPLETE_VALIDATED', 'instances': count, 'families': len(cfg['family_seeds'])}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare', action='store_true')
    mode.add_argument('--generate', action='store_true')
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--validator', type=Path, default=DEFAULT_VALIDATOR)
    parser.add_argument('--freeze', type=Path, required=True)
    parser.add_argument('--expected-freeze-sha256')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.prepare:
        prepare(args.config, args.validator, args.freeze)
    else:
        require(args.expected_freeze_sha256 and args.output, '--generate requires expected freeze digest and output')
        generate(args.freeze, args.expected_freeze_sha256, args.output)


if __name__ == '__main__':
    main()
