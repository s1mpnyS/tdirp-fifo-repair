"""Freeze file hashes and obtain/verify a digest-only FreeTSA RFC3161 token.

This is an external existence timestamp, not a public OSF registration or a
registered report. A local JSON status is never sufficient: verify executes
OpenSSL on the token, request nonce, manifest digest, and all member bytes.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import urllib.request

OPENSSL = os.environ.get("TDIRP_OPENSSL", "openssl")
ENDPOINT = "https://freetsa.org/tsr"
CERTIFICATES = {
    "tsa.crt": "8bfb0305bb64e2571ca507552ef3245cb1c2fee8728e0ff8689225081ea13467",
    "cacert.pem": "2151b61137ffa86bf664691ba67e7da0b19f98c758e3d228d5d8ebf27e044438"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def manifest_members(paths):
    paths = [Path(path).resolve(strict=True) for path in paths]
    if len(set(paths)) != len(paths):
        raise ValueError("Duplicate manifest paths")
    if any(not path.is_file() for path in paths):
        raise ValueError("Manifest members must be regular files")
    return [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}
            for path in sorted(paths)]


def verify_members(manifest):
    members = manifest.get("members")
    if not isinstance(members, list) or not members:
        raise ValueError("Nonempty member list required")
    seen = set()
    for item in members:
        path = Path(item["path"]).resolve(strict=True)
        if path in seen or not path.is_file():
            raise ValueError("Duplicate or non-file member")
        seen.add(path)
        if path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
            raise ValueError("Frozen file changed: " + str(path))
    return len(members)


def command(arguments):
    result = subprocess.run([str(OPENSSL), *map(str, arguments)], capture_output=True,
                            text=True, timeout=30, check=False)
    if result.returncode:
        raise RuntimeError("OpenSSL verification/command failed: " + result.stderr.strip())
    return {"argv": [str(OPENSSL), *map(str, arguments)], "exit_code": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def freeze(output, files, *, scope="Exploratory n50 server cohort; externally timestamped frozen protocol"):
    manifest = {"schema": "tdirp_v13_external_digest_freeze_v1",
                "local_created_utc": datetime.now(timezone.utc).isoformat(),
                "scope": scope,
                "members": manifest_members(files)}
    if not manifest["members"]:
        raise ValueError("Empty freeze")
    write_new(output, manifest)
    return sha(output)


def verify(manifest_path, receipt_folder):
    manifest_path, folder = Path(manifest_path).resolve(), Path(receipt_folder).resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    count = verify_members(manifest)
    for name, expected in CERTIFICATES.items():
        if sha(folder / name) != expected:
            raise ValueError("Pinned official certificate mismatch: " + name)
    # Request verification checks nonce and imprint; data verification separately
    # binds that request/response to the literal current manifest bytes.
    common = ["-in", folder / "response.tsr", "-CAfile", folder / "cacert.pem",
              "-untrusted", folder / "tsa.crt"]
    checks = [command(["ts", "-verify", *common, "-queryfile", folder / "request.tsq"]),
              command(["ts", "-verify", *common, "-data", manifest_path])]
    token = command(["ts", "-reply", "-in", folder / "response.tsr", "-text"])
    if "Status: Granted." not in token["stdout"]:
        raise ValueError("Timestamp was not granted")
    match = re.search(r"Time stamp:\s*(.+)", token["stdout"])
    if not match:
        raise ValueError("Timestamp generation time unavailable")
    return {"status": "VERIFIED_EXTERNAL_TIMESTAMP_AND_MEMBER_BYTES",
            "manifest_path": str(manifest_path), "manifest_sha256": sha(manifest_path),
            "verified_member_count": count, "external_generation_time": match.group(1).strip(),
            "response_sha256": sha(folder / "response.tsr"),
            "request_sha256": sha(folder / "request.tsq"), "openssl_verifications": checks,
            "token_text": token["stdout"], "verified_local_utc": datetime.now(timezone.utc).isoformat(),
            "registration_scope": "Digest existence/immutability timestamp; not public registration, DOI, or editorial approval"}


def stamp(manifest_path, output_folder):
    manifest_path, folder = Path(manifest_path).resolve(), Path(output_folder).resolve()
    verify_members(json.loads(manifest_path.read_text(encoding="utf-8")))
    folder.mkdir(parents=True, exist_ok=False)
    write_new(folder / "attempt.json", {"started_local_utc": datetime.now(timezone.utc).isoformat(),
              "manifest_sha256": sha(manifest_path), "endpoint": ENDPOINT,
              "uploaded_content": "RFC3161 SHA256 imprint, nonce and protocol metadata only; no member file content",
              "service_information": "https://www.freetsa.org/index_en.php",
              "usage_policy": "https://www.freetsa.org/freetsa.html"})
    try:
        version = command(["version", "-a"])
        write_new(folder / "openssl_version.json", version)
        query = command(["ts", "-query", "-data", manifest_path, "-sha256", "-cert",
                         "-out", folder / "request.tsq"])
        write_new(folder / "query_command.json", query)
        for name, expected in CERTIFICATES.items():
            with urllib.request.urlopen("https://freetsa.org/files/" + name, timeout=30) as response:
                data = response.read(1024 * 1024)
            (folder / name).write_bytes(data)
            if sha(folder / name) != expected:
                raise ValueError("Official certificate differs from browsed fingerprint: " + name)
        request = urllib.request.Request(ENDPOINT, data=(folder / "request.tsq").read_bytes(),
                  headers={"Content-Type": "application/timestamp-query", "Accept": "application/timestamp-reply"})
        with urllib.request.urlopen(request, timeout=45) as response:
            data = response.read(1024 * 1024)
            headers = dict(response.headers.items())
        (folder / "response.tsr").write_bytes(data)
        write_new(folder / "http_response.json", headers)
        receipt = verify(manifest_path, folder)
        write_new(folder / "verification.json", receipt)
        return receipt
    except Exception as exc:
        write_new(folder / "FAILED.json", {"status": "FAILED_NOT_FROZEN_FOR_EXECUTION",
                  "error": f"{type(exc).__name__}: {exc}",
                  "local_utc": datetime.now(timezone.utc).isoformat()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    create = sub.add_parser("freeze")
    create.add_argument("--output", required=True)
    create.add_argument("files", nargs="+")
    for name in ("stamp", "verify"):
        task = sub.add_parser(name)
        task.add_argument("--manifest", required=True)
        task.add_argument("--receipt-folder", required=True)
    args = parser.parse_args()
    if args.action == "freeze":
        print(json.dumps({"manifest_sha256": freeze(args.output, args.files)}))
    else:
        result = (stamp if args.action == "stamp" else verify)(args.manifest, args.receipt_folder)
        print(json.dumps({key: value for key, value in result.items()
                          if key not in ("openssl_verifications", "token_text")}))


if __name__ == "__main__":
    main()
