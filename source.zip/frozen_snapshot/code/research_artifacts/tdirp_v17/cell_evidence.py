"""Lossless per-cell evidence storage after the monitored wall clock stops."""
from contextlib import contextmanager
import hashlib
import os
from pathlib import Path
import shutil
import zipfile


FORMAT = "cell_zip_deflate_v1"
ARCHIVE = "evidence.zip"
DIRECTORIES = {"attempts", "checkpoints", "restarts"}
FILES = {"parent_result.json"}
_cached = None


def _location(path):
    if path.name in FILES:
        cell = path.parent
    elif path.parent.name in DIRECTORIES:
        cell = path.parent.parent
    else:
        return None
    if cell.parent.name != "cells":
        return None
    return cell / ARCHIVE, path.relative_to(cell).as_posix()


def _archive(path):
    global _cached
    if _cached is None or _cached[0] != path:
        if _cached is not None:
            _cached[1].close()
            _cached = None
        _cached = (path, zipfile.ZipFile(path))
    return _cached[1]


@contextmanager
def open_bytes(path):
    path = Path(path)
    try:
        stream = path.open("rb")
    except FileNotFoundError:
        location = _location(path)
        if location is None or not location[0].is_file():
            raise
        archive, member = location
        stream = _archive(archive).open(member)
    with stream:
        yield stream


def pack(folder):
    """Commit a verified ZIP before removing the original files of a completed cell."""
    folder = Path(folder).resolve(strict=True)
    if folder.parent.name != "cells" or not (folder / "parent_result.json").is_file():
        raise ValueError("Packing requires a completed cell directory")
    archive = folder / ARCHIVE
    temporary = archive.with_suffix(".zip.tmp")
    if archive.exists():
        raise FileExistsError(archive)
    directories = [folder / name for name in sorted(DIRECTORIES) if (folder / name).exists()]
    for directory in directories:
        if not directory.is_dir() or directory.resolve(strict=True) != directory:
            raise ValueError(f"Unexpected evidence directory: {directory}")
    paths = [folder / name for name in sorted(FILES)]
    paths.extend(path for directory in directories for path in sorted(directory.iterdir()))
    if any(not path.is_file() or path.resolve(strict=True) != path for path in paths):
        raise ValueError("Evidence members must be regular files inside the cell")

    expected = {path.relative_to(folder).as_posix(): path.stat().st_size for path in paths}
    with temporary.open("xb") as stream:
        with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as packed:
            for path in paths:
                packed.write(path, path.relative_to(folder).as_posix())
        stream.flush()
        os.fsync(stream.fileno())
    with zipfile.ZipFile(temporary) as packed:
        sizes = {member.filename: member.file_size for member in packed.infolist()}
        if sizes != expected or packed.testzip() is not None:
            raise ValueError(f"Evidence archive failed lossless readback: {temporary}")
    with temporary.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    archive = temporary.rename(archive)
    if os.name == "posix":
        directory_fd = os.open(folder, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)

    for directory in directories:
        shutil.rmtree(directory)
    for name in FILES:
        (folder / name).unlink()
    return {"evidence_zip_sha256": checksum, "evidence_zip_bytes": archive.stat().st_size,
            "evidence_raw_bytes": sum(expected.values())}


def verify(folder, record):
    archive = Path(folder) / ARCHIVE
    with archive.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    if checksum != record["evidence_zip_sha256"] or archive.stat().st_size != record["evidence_zip_bytes"]:
        raise ValueError(f"Indexed evidence archive changed: {archive}")
