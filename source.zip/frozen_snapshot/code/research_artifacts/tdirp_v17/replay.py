"""Replay a full-workflow server cohort without calling an optimizer."""
from fractions import Fraction
from pathlib import Path
import argparse
import json
from statistics import median
import zipfile

import cell_evidence
import confirmation
import coordination
import runner


def require(condition, message):
    if not condition:
        raise ValueError(message)


def result_rows(raw, plan, root):
    if plan["cohort"] not in runner.INDEXED_COHORTS:
        require([r["cell"] for r in raw["rows"]] == plan["cells"], "Assignment coverage differs")
        yield from raw["rows"]
        return
    index = raw["row_index"]
    require(len(index) == len(plan["cells"]), "Indexed assignment coverage differs")
    for record, cell in zip(index, plan["cells"], strict=True):
        require(record["cell_id"] == cell["cell_id"], "Indexed assignment order differs")
        path = root / "run/cells" / cell["cell_id"] / "parent_result.json"
        if plan.get("evidence_storage") == cell_evidence.FORMAT:
            cell_evidence.verify(path.parent, record)
        require(runner.sha(path) == record["parent_result_sha256"], "Indexed parent result changed")
        row = runner.load(path)
        require(row["cell"] == cell, "Indexed assignment identity differs")
        yield row


def replay_restarts(row, handoff, eligible, check, instance):
    restarts = row["phase_records"].get("continuation", {}).get("restarts", [])
    if not restarts:
        return []
    require(row["cell"]["arm"] == "A+" and handoff is not None, "Unexpected two-stage restart")
    from continuation import customer_order, restart_seed
    expected_start = handoff["physical_sha256"]
    expected_cost = runner.exact(handoff["point"])
    for index, record in enumerate(restarts):
        seed = restart_seed(row["cell"]["seed"], index)
        require(record["index"] == index and record["seed"] == seed
                and record["customer_order_sha256"] == runner.digest(customer_order(instance["n"], seed))
                and record["input_physical_sha256"] == expected_start
                and Fraction(record["input_exact"]) == expected_cost, "A+ restart lineage differs")
        require(runner.sha(record["artifact"]) == record["artifact_sha256"], "A+ artifact changed")
        artifact = runner.load(record["artifact"])
        require(artifact["counters"] == record["counters"] and artifact["workflow_completed"] == record["completed"],
                "A+ work evidence differs")
        candidate = check.verify_physical(instance, artifact)
        require(candidate["objective_decimal"] == artifact["objective"], "A+ artifact objective differs")
        expected_start = record["retained_physical_sha256"]
        cost = Fraction(record["retained_exact"])
        require(cost <= expected_cost, "A+ retained cost increased")
        expected_cost = cost
        matches = [p for p in eligible if p["payload"]["stage"] == "Aplus_restart_return"
                   and p["payload"]["detail"]["restart"] == index]
        require(len(matches) == 1
                and runner.physical_signature(matches[0]["verified"]) == expected_start
                and runner.exact(matches[0]["verified"]) == expected_cost, "A+ return checkpoint differs")
    return restarts


def confirmation_pairs(plan, exact_costs, observed, handoffs, rows, seed=confirmation.SEED):
    lookup = {(r["input"], r["arm"]): r for r in rows}
    pairs = []
    for name in plan["cases"]:
        first = {arm: lookup[name, arm]["first_repair"] for arm in ("G", "J")}
        comparable = (handoffs[name, "J", seed] is not None and handoffs[name, "J", seed] == handoffs[name, "G", seed]
                      and all(first.values())
                      and all(lookup[name, arm]["clean_resource_timing"] for arm in ("G", "J"))
                      and all(first[arm]["input_physical_sha256"] == handoffs[name, arm, seed] for arm in ("G", "J"))
                      and first["J"]["block"] == first["G"]["block"]
                      and first["J"]["local_allowance_seconds"] >= 5.999
                      and first["G"]["local_allowance_seconds"] >= 5.999)
        paired_timing = ({arm: first[arm]["profiles_seconds"] for arm in ("G", "J")} if comparable else None)
        row = plan["confirmation_files"][name]
        costs = {arm: exact_costs[name, arm, seed] for arm in confirmation.ARMS}
        pairs.append({"input": name, "family": row["family"], "n": row["n"], "H": row["H"], "M": row["M"],
                      "C0_exact": str(observed[name]),
                      "costs_exact": {arm: str(cost) for arm, cost in costs.items()},
                      "paired_gain_cost_exact": {"J_vs_A+": str(costs["A+"] - costs["J"]),
                                                 "G_vs_A+": str(costs["A+"] - costs["G"]),
                                                 "J_vs_G": str(costs["G"] - costs["J"])},
                      "same_physical_handoff": (handoffs[name, "J", seed] is not None
                                                and len({handoffs[name, arm, seed] for arm in confirmation.ARMS}) == 1),
                      "same_state_first_profiles_seconds": paired_timing})
    return pairs


def coordination_pairs(plan, exact_costs, observed, handoffs, mechanisms, seed=coordination.SEED):
    pairs = []
    for name in plan["cases"]:
        f = plan["confirmation_files"][name]
        require(handoffs[name, "K1", seed] == handoffs[name, "K6", seed] == plan["warm_starts"][name]["physical_sha256"],
                "Coordination starting states differ")
        singletons = mechanisms[name, "K1", seed]
        improvements = mechanisms[name, "K6", seed]
        witnesses = [{"state_sha256": state, "singleton_certificates": singletons[state], "joint": improvements[state]}
                     for state in sorted(singletons.keys() & improvements.keys())]
        pairs.append({"input": name, "family": f["family"], "n": f["n"], "H": f["H"], "M": f["M"],
                      "C0_exact": str(observed[name]),
                      "costs_exact": {arm: str(exact_costs[name, arm, seed]) for arm in coordination.BLOCK_SIZES},
                      "same_physical_handoff": True,
                      "K6_gain_cost_exact": str(exact_costs[name, "K1", seed] - exact_costs[name, "K6", seed]),
                      "states_with_all_singletons_certified": len(singletons),
                      "strict_joint_witnesses": witnesses})
    return pairs


def coordination_receipts(eligible):
    """Link attempts to eligible publications and earlier verified input states."""
    states, repairs = {}, {}
    for publication in eligible:
        payload, verified = publication["payload"], publication["verified"]
        event = payload.get("attempt_event")
        if event is not None:
            require(payload["stage"] == "repair_return" and event["attempt"] not in repairs,
                    "Duplicate or mislabelled coordination repair receipt")
            repairs[event["attempt"]] = (event, publication, states.get(event["summary"]["input_physical_sha256"]))
        states[runner.physical_signature(verified)] = verified
    return repairs


def preserves_outside_order(before, after, block):
    released = set(block)
    return all([j for j in left if j not in released] == [j for j in right if j not in released]
               for left, right in zip(before["routes"], after["routes"], strict=True))


def fixed_start_diagnostics(pairs):
    return {"strict_joint_witness_files": sum(bool(p["strict_joint_witnesses"]) for p in pairs),
            "singleton_exhaustion_files": sum(bool(p["states_with_all_singletons_certified"]) for p in pairs)}


def confirmation_diagnostics(pairs):
    timed = [p["same_state_first_profiles_seconds"] for p in pairs if p["same_state_first_profiles_seconds"]]
    return {"same_state_first_profiles": {"eligible_files": len(timed), "assigned_files": len(pairs),
            "median_J_over_G": median(t["J"] / t["G"] for t in timed) if timed else None}}


def robustness_summary(common, pairs, contrasts, diagnostic, historical_seed):
    by_seed, pooled = confirmation.summarize_seeds(pairs, contrasts)
    spread = {}
    for name in pooled:
        means = [seed_report[name]["mean_family_pp"] for seed_report in by_seed.values()]
        span = max(means) - min(means)
        spread[name] = {"mean_span_pp": span, "opposite_signs": min(means) < 0 < max(means),
                        "span_at_least_0_2_pp": span >= .2}
    return {**common, "historical_seed_separate": historical_seed, "paired_files_per_seed": len(next(iter(pairs.values()))),
            "family_contrasts": pooled, "seed_contrasts": by_seed, "seed_spread": spread,
            "per_seed_diagnostics": {seed: diagnostic(items) for seed, items in pairs.items()}, "pairs_by_seed": pairs}


def analyze(root):
    plan = runner.load(root / "plan.json")
    runner.validate_plan(plan)
    runner.external_freeze(root / "plan.json", plan, root / "execution_freeze.json", root / "receipt")
    raw_path = root / "run/results.json"
    raw = runner.load(raw_path)
    require(raw["status"] == "COMPLETED" and raw["plan_sha256"] == plan["plan_sha256"], "Incomplete or mismatched run")
    check = runner.independent_verifier()
    native_binaries = {value for path, value in plan["source_sha256"].items()
                       if Path(path).parent == root / "build" and Path(path).name.startswith("fifo_tsp_")
                       and Path(path).suffix in {"", ".exe"}}
    fixed_start = plan["cohort"] == "coordination"
    robustness = plan.get("robustness", False)
    require(len(native_binaries) == (0 if fixed_start else 1), "Unexpected frozen FIFO executable count")
    results, exact_costs, observed, handoffs, mechanisms = [], {}, {}, {}, {}
    with zipfile.ZipFile(plan["archive"]) as archive:
        for row in result_rows(raw, plan, root):
            c = row["cell"]
            key = (c["input"], c["arm"], c["seed"])
            instance = check.parse_instance(archive.read(c["input"]))
            initial = check.verify_physical(instance, plan["warm_starts"][c["input"]]["point"])
            final = check.verify_physical(instance, row["retained"])
            require(initial == row["initial"] and final == row["retained"], "Endpoint replay changed")
            expected = runner.select_publication(row["publications"], initial)[0]
            require(expected == final and runner.exact(final) <= runner.exact(initial), "Retention differs")
            eligible = [p for p in row["publications"] if not p["rejections"]]
            for p in eligible:
                payload, receipt = runner.load(p["file"]), runner.load(p["receipt_file"])
                verified = check.verify_physical(instance, payload["point"])
                require(payload == p["payload"] and verified == p["verified"], "Checkpoint replay changed")
                require(not runner.checkpoint_rejections(payload, receipt, row["identity"],
                    p["observed_elapsed_seconds"], c["budget_seconds"], verified), "Receipt gate differs")
            worse = improvements = verified_raw = 0
            first_repair = None
            singleton_evidence, joint_evidence = {}, {}
            repair_receipts = coordination_receipts(eligible) if fixed_start else {}
            for item in row["attempts"]:
                require(item["decoder"] == c["decoder"], "Unexpected decoder in repair evidence")
                if fixed_start:
                    record = plan["confirmation_files"][c["input"]]
                    require(item["k"] == c["k"] and item["block"] == coordination.block_for(
                            record, item["attempt"], c["k"], seed=c["seed"]),
                            "Coordination repair block differs from the frozen schedule")
                    require(item["attempt"] in repair_receipts, "Coordination attempt has no eligible receipt")
                    bound_event, publication, prior = repair_receipts[item["attempt"]]
                    require(bound_event["artifact_file"] == item["artifact_file"]
                            and bound_event["artifact_sha256"] == item["artifact_sha256"]
                            and publication["observed_elapsed_seconds"] == item["parent_observed_elapsed_seconds"],
                            "Coordination attempt differs from the eligible receipt")
                elif robustness:
                    require(item["block"] == runner.block_for(c["input"], item["attempt"],
                            plan["confirmation_files"][c["input"]], seed=c["seed"]),
                            "Confirmation repair block differs from the frozen seed schedule")
                if c["arm"] == "G":
                    require(not item["raw_conditional_optimum_verified"]
                            and not item["conditional_no_improving_true_move_verified"]
                            and item["raw_true_completion_lower_bound"] is None,
                            "Greedy master cannot certify the full FIFO neighborhood")
                path = Path(item["artifact_file"])
                require(runner.sha(path) == item["artifact_sha256"], "Attempt artifact drift")
                event = runner.load(path)
                require(all(item[key] == value for key, value in event["summary"].items()),
                        "Parent attempt summary differs from artifact")
                if fixed_start:
                    require(bound_event["summary"] == event["summary"], "Coordination receipt summary differs from artifact")
                if (item["attempt"] == 0 and item["tables_complete"] and not item["returned_after_local_deadline"]
                        and item["phase_seconds"].get("profiles", 0) > 0):
                    first_repair = {key: item[key] for key in
                                    ("input_physical_sha256", "block", "local_allowance_seconds", "wall_seconds")}
                    first_repair["profiles_seconds"] = item["phase_seconds"]["profiles"]
                point = event["raw_point"]
                if point is None:
                    continue
                point = check.verify_physical(instance, point)
                verified_raw += 1
                if item.get("candidate_eligible"):
                    delta = runner.exact(point) - Fraction(item["input_exact_objective"])
                    worse += delta > 0
                    improvements += delta < 0
                    if fixed_start and prior is not None:
                        state = item["input_physical_sha256"]
                        require(runner.exact(prior) == Fraction(item["input_exact_objective"])
                                and preserves_outside_order(prior, point, item["block"]),
                                "Coordination candidate differs from its declared neighborhood")
                        evidence = {"attempt": item["attempt"], "block": item["block"],
                                    "artifact_sha256": item["artifact_sha256"],
                                    "start_exact": item["input_exact_objective"],
                                    "candidate_exact": point["exact_feasible_objective"]}
                        if (c["arm"] == "K1" and delta == 0 and item["raw_conditional_optimum_verified"]
                                and item["conditional_no_improving_true_move_verified"]):
                            singleton_evidence.setdefault(state, {}).setdefault(item["block"][0], evidence)
                        if c["arm"] == "K6" and delta < 0 and item["strict_raw_gain"]:
                            require(publication["verified"] == point, "Strict joint candidate differs from retained receipt")
                            joint_evidence.setdefault(state, evidence)
            if fixed_start:
                mechanisms[key] = (
                    {state: list(items.values()) for state, items in singleton_evidence.items() if len(items) == instance["n"]}
                    if c["arm"] == "K1" else joint_evidence)
            ci, cf = runner.exact(initial), runner.exact(final)
            constructor = row["phase_records"].get("constructor", {})
            stage_a = row["phase_records"].get("A", {})
            if robustness and not fixed_start:
                require((not constructor or constructor["seed"] == c["seed"])
                        and (not stage_a or stage_a["seed"] == c["seed"]), "Robustness prefix seed differs")
            handoff = row["phase_records"].get("handoff")
            ch = None
            handoff_signature = None
            worker_fixed_handoff = None
            if fixed_start:
                ch, handoff_signature = ci, runner.physical_signature(initial)
                fixed = row["phase_records"].get("fixed_handoff")
                require(fixed is None or (fixed["physical_sha256"] == handoff_signature
                                         and Fraction(fixed["exact_objective"]) == ci), "Worker start differs")
                worker_fixed_handoff = any(p["payload"]["stage"] == "fixed_handoff_verified" for p in eligible)
            elif handoff is not None:
                point = check.verify_physical(instance, handoff["point"])
                require(runner.sha(handoff["file"]) == handoff["file_sha256"]
                        and runner.load(handoff["file"]) == point == handoff["point"], "Handoff replay changed")
                handoff_signature = runner.physical_signature(point)
                ch = runner.exact(point)
                require(handoff["physical_sha256"] == handoff_signature == stage_a["retained_physical_sha256"],
                        "Handoff differs from the A incumbent")
                require(ch == Fraction(stage_a["retained_exact_objective"]) and cf <= ch <= ci,
                        "Nonmonotone verified endpoint")
            periods = stage_a.get("native_periods", [])
            candidate_path = root / "run/cells" / c["cell_id"] / "two_stage_report.json"
            if stage_a.get("workflow_completed"):
                report = runner.load(candidate_path)
                candidate = check.verify_physical(instance, report["last_complete_candidate_plan"])
                static = report["phase_one_plan"]
                require(report["workflow_completed"] and len(periods) == len(static["routes"]),
                        "Incomplete fixed-membership routing")
                require(candidate["quantities"] == static["quantities"], "A changed the fixed quantities")
                for period, route, original, evidence in zip(periods, candidate["routes"], static["routes"],
                                                             report["phase_two_periods"], strict=True):
                    require(sorted(route) == sorted(original) == sorted(evidence["membership"]),
                            "A changed a fixed membership")
                    require(period["members"] == len(route) and period["binary_sha256"] == evidence.get("executable_sha256")
                            and period["status"] == evidence["status"] and period["optimal"] == evidence.get("optimal"),
                            "Native summary differs from the period evidence")
                    require(period["completion"] == candidate["return_times"][period["period"]],
                            "Native return clock differs from replay")
            require(all(p["binary_sha256"] is None or p["binary_sha256"] in native_binaries for p in periods),
                    "Undeclared native binary")
            restarts = replay_restarts(row, handoff, eligible, check, instance)
            first_tail_gain = next((p["observed_elapsed_seconds"] for p in eligible
                                    if p["payload"]["stage"] in {"repair_return", "Aplus_candidate", "Aplus_restart_return"}
                                    and ch is not None
                                    and runner.exact(p["verified"]) < ch), None)
            result = {
                "cell_id": c["cell_id"], "input": c["input"], "arm": c["arm"], "decoder": c["decoder"],
                "start": float(ci), "final": float(cf),
                "gain_pp": float(100 * (ci - cf) / ci),
                "constructor_success": constructor.get("success"),
                "constructor_retained_cost": None if not constructor else float(Fraction(constructor["retained_exact_objective"])),
                "two_stage_completed": stage_a.get("workflow_completed"),
                "two_stage_failure": stage_a.get("failure_reason"),
                "native_periods": periods,
                "handoff_cost": None if ch is None else float(ch),
                "handoff_seconds": None if handoff is None else handoff["completed_elapsed_seconds"],
                "tail_gain_cost": None if ch is None else float(ch - cf),
                "tail_gain_pp": None if ch is None else float(100 * (ch - cf) / ci),
                "first_tail_gain_observed_seconds": first_tail_gain,
                "returned_repairs": row["returned_repairs_observed_by_parent"], "verified_raw_candidates": verified_raw,
                "first_repair": first_repair,
                "two_stage_restarts": restarts,
                "fallback_to_fixed_C0": row["fallback_to_fixed_C0"],
                "median_returned_repair_seconds": median(item["wall_seconds"] for item in row["attempts"])
                if row["attempts"] else None,
                "no_improvement_certificates": sum(item["conditional_no_improving_true_move_verified"]
                                                   for item in row["attempts"]),
                "eligible_true_worse_candidates": worse, "eligible_true_improving_candidates": improvements,
                "parent_seconds": row["full_parent_seconds"],
                "peak_mib": None if row["peak_sampled_tree_rss_bytes"] is None else row["peak_sampled_tree_rss_bytes"] / 2**20,
                "max_monitor_gap_seconds": row["observed_max_sampling_gap_seconds"],
                "clean_resource_timing": row["clean_resource_timing"],
                "worker_exit_code": row["worker_exit_code"], "external_stop": row["external_stop"],
                "execution_error": row["execution_error"], "eligible_receipts": len(eligible),
                "handoff_verified": handoff_signature is not None,
                "worker_fixed_handoff_verified": worker_fixed_handoff,
            }
            if robustness:
                result["seed"] = c["seed"]
            results.append(result)
            exact_costs[key] = cf
            handoffs[key] = handoff_signature
            observed[c["input"]] = ci
    common = {"status": "N50_FULL_PIPELINE_PHYSICAL_REPLAY_PASS", "plan_sha256": plan["plan_sha256"],
              "raw_results_sha256": runner.sha(raw_path), "cohort": plan["cohort"],
              "endpoint_cells": len(results), "rows": results, "scope": plan["scope"]}
    if fixed_start:
        contrasts = (("K1", "K6"),)
        if robustness:
            pairs = {seed: coordination_pairs(plan, exact_costs, observed, handoffs, mechanisms, seed)
                     for seed in coordination.ROBUSTNESS_SEEDS}
            return robustness_summary({**common, "normalizer": "fixed_two_stage_handoff"},
                                      pairs, contrasts, fixed_start_diagnostics, coordination.SEED)
        pairs = coordination_pairs(plan, exact_costs, observed, handoffs, mechanisms)
        return {**common, "pairs": pairs, "normalizer": "fixed_two_stage_handoff",
                "family_contrasts": confirmation.summarize(pairs, contrasts), **fixed_start_diagnostics(pairs)}
    if plan["cohort"] == "confirmation":
        if robustness:
            pairs = {seed: confirmation_pairs(plan, exact_costs, observed, handoffs,
                                             [row for row in results if row["seed"] == seed], seed)
                     for seed in confirmation.ROBUSTNESS_SEEDS}
            return robustness_summary(common, pairs, (("A+", "J"), ("A+", "G"), ("G", "J")),
                                      confirmation_diagnostics, confirmation.SEED)
        pairs = confirmation_pairs(plan, exact_costs, observed, handoffs, results)
        return {**common, "pairs": pairs, "family_contrasts": confirmation.summarize(pairs),
                **confirmation_diagnostics(pairs)}
    pairs = []
    comparator = {"matched": "A", "valuation": "S", "decoder": "G"}[plan["cohort"]]
    for name in plan["cases"]:
        gain = exact_costs[name, comparator, runner.ALGORITHM_SEED] - exact_costs[name, "J", runner.ALGORITHM_SEED]
        joint_handoff = handoffs[name, "J", runner.ALGORITHM_SEED]
        pairs.append({"input": name, "comparator": comparator,
                      "same_physical_handoff": (joint_handoff is not None
                                                and joint_handoff == handoffs[name, comparator, runner.ALGORITHM_SEED]),
                      "J_advantage_exact": str(gain), "J_advantage_cost": float(gain),
                      "J_advantage_pp": float(100 * gain / observed[name])})
    return {**common, "pairs": pairs,
            "mean_paired_advantage_pp": sum(r["J_advantage_pp"] for r in pairs) / len(pairs)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="Directory passed to run.py --output")
    args = parser.parse_args()
    root = args.output.resolve()
    report = analyze(root)
    output = root / "analysis.json"
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    if report["cohort"] in runner.INDEXED_COHORTS:
        if "seed_contrasts" in report:
            extra = ("seed_contrasts", "seed_spread", "per_seed_diagnostics")
        else:
            extra = ("same_state_first_profiles",) if report["cohort"] == "confirmation" else (
                "strict_joint_witness_files", "singleton_exhaustion_files")
        keys = ("status", "endpoint_cells", "family_contrasts", *extra)
        print(json.dumps({**{key: report[key] for key in keys}, "analysis": str(output)}, indent=2))
    else:
        print(json.dumps(report, indent=2))
