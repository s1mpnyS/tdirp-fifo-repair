"""Joint repair with two FIFO decoders and two master valuations.

Both valuations use the same exact FIFO path pool. The greedy decoder uses
FIFO valuation and the same master, inventory recourse and acceptance.
"""
from __future__ import annotations

import copy
from fractions import Fraction
import math
import time

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

from tdirp_v11.profiles import DECODERS, FifoNetwork, ProfileInterrupted, build_profiles, customers
from tdirp_v11.repair import finite_or_none, validate_instance
from schedule_repair import MILP_OPTIONS, inventory_recourse, verify_routes
from root_lp_probe import base_model


CONTRACT = "completion_c1_endholding_nowait_ML_header_v1"
VALUATIONS = ("fifo", "static")
OBJECTIVE_MATCH_TOLERANCE = 1e-5


def static_path_score(i, route, arc_mean_cache=None):
    """Unrounded rational mean-bin arc cost plus service on this exact path.

    Customer indices are zero-based; the depot is index zero in raw travel data.
    This does not construct a static-optimal route or choose additional waiting.
    """
    route = customers(route, i.n, "static path")
    if not route:
        return Fraction(0)
    if isinstance(i.steps, bool) or int(i.steps) != i.steps or i.steps < 1:
        raise ValueError("Positive integer bin count required")
    cache = {} if arc_mean_cache is None else arc_mean_cache

    def arc_mean(a, b):
        if (a, b) not in cache:
            cache[a, b] = Fraction(sum(int(value) for value in i.travel[a, b, :]), int(i.steps))
        return cache[a, b]

    total, last = Fraction(0), 0
    for customer in route:
        total += arc_mean(last, customer + 1)
        last = customer + 1
    total += arc_mean(last, 0)
    return total + sum(int(i.service[customer]) for customer in route)


def profile_scores(i, table, arc_mean_cache=None):
    """Score every existing FIFO witness without changing the profile values."""
    if table.get("complete") is not True or len(table["routes"]) != len(table["values"]):
        raise ValueError("Complete aligned FIFO profile table required")
    fifo, static = [], []
    cache = {} if arc_mean_cache is None else arc_mean_cache
    for value, path in zip(table["values"], table["routes"]):
        if path is None or value is None or not math.isfinite(float(value)):
            fifo.append(None)
            static.append(None)
        else:
            fifo.append(Fraction(str(value)))
            static.append(static_path_score(i, path, cache))
    return fifo, static


def eligible_masks(table, return_limit):
    """The valuation does not enter this true-FIFO feasibility filter."""
    return [mask for mask, path in enumerate(table["routes"])
            if path is not None and table["values"][mask] is not None
            and math.isfinite(float(table["values"][mask])) and table["values"][mask] <= return_limit]


def build_master(i, routes, block, tables, valuation, arc_mean_cache=None):
    """Same free-quantity master; route-column scores are the sole change."""
    if valuation not in VALUATIONS:
        raise ValueError("Unsupported valuation")
    if len(tables) != i.horizon or any(table.get("complete") is not True for table in tables):
        raise ValueError("Every period needs a complete FIFO profile table")
    lp, y, q, inv, z = base_model(i)
    cache = {} if arc_mean_cache is None else arc_mean_cache
    zset = set(z)
    keep = [r for r, row in enumerate(lp.ub) if not zset.intersection(row)]
    lp.ub, lp.ubrhs = [lp.ub[r] for r in keep], [lp.ubrhs[r] for r in keep]
    for variable in z:
        lp.c[variable] = 0.
    columns, selected_customers, scores_by_period = [], set(block), []
    for p, route in enumerate(routes):
        present = set(route)
        for customer in range(i.n):
            lp.bounds[inv[p][customer + 1]] = (float(i.minimum[customer]), None)
            if customer not in selected_customers:
                lp.bounds[y[p][customer]] = (float(customer in present), float(customer in present))
        table = tables[p]
        fifo, static = profile_scores(i, table, cache)
        scores = fifo if valuation == "fifo" else static
        scores_by_period.append(scores)
        cols = {mask: lp.var(c=float(scores[mask])) for mask in eligible_masks(table, i.deadline)}
        columns.append(cols)
        if not cols:
            return {"infeasible_period": p, "columns": columns, "valuation": valuation}
        lp.equality({col: 1. for col in cols.values()}, 1.)
        for j, customer in enumerate(block):
            row = {y[p][customer]: -1.}
            row.update({col: 1. for mask, col in cols.items() if mask >> j & 1})
            lp.equality(row, 0.)
    integer = np.zeros(len(lp.c), dtype=np.uint8)
    for p in range(i.horizon):
        for customer in block:
            integer[y[p][customer]] = 1
    return {"lp": lp, "columns": columns, "integrality": integer,
            "valuation": valuation, "valuation_scores_exact": scores_by_period,
            "visit_variables": y, "quantity_variables": q, "inventory_variables": inv,
            "constraints": [LinearConstraint(lp.sparse(lp.eq), lp.eb, lp.eb),
                            LinearConstraint(lp.sparse(lp.ub), -np.inf, lp.ubrhs)],
            "bounds": Bounds([b[0] for b in lp.bounds],
                             [np.inf if b[1] is None else b[1] for b in lp.bounds])}


def candidate_objectives(i, verification, arc_mean_cache=None):
    """True and static candidate costs share exactly the verified holding term."""
    require_checked = verification.get("checked") is True
    if not require_checked:
        raise ValueError("Physical verification required before scoring a candidate")
    holding = Fraction(verification["holding_cost"])
    cache = {} if arc_mean_cache is None else arc_mean_cache
    static_routing = sum((static_path_score(i, route, cache) for route in verification["routes"]), Fraction(0))
    return {"true": Fraction(verification["exact_feasible_objective"]),
            "static": holding + static_routing, "holding": holding,
            "static_routing": static_routing}


def certificate_flags(valuation, status, solver_objective, objectives, *, decoder=DECODERS[0]):
    """Only a full exact FIFO pool can certify the true neighborhood."""
    if valuation not in VALUATIONS:
        raise ValueError("Unsupported valuation")
    reconstructed = objectives["true" if valuation == "fifo" else "static"]
    match = (solver_objective is not None and math.isfinite(float(solver_objective))
             and abs(float(solver_objective) - float(reconstructed)) <= OBJECTIVE_MATCH_TOLERANCE)
    optimum = bool(status == 0 and match)
    return {"selected_valuation_objective_matches_solver": bool(match),
            "raw_master_optimal": optimum, "raw_valuation_master_optimal": optimum,
            "raw_conditional_optimum_verified": bool(valuation == "fifo" and decoder == DECODERS[0] and optimum),
            "surrogate_master_optimal_bound_verified": bool(valuation == "static" and optimum)}


def strictly_improves_true_cost(candidate, incumbent):
    """Acceptance uses exact true cost, including when a static score improves."""
    return Fraction(candidate["exact_feasible_objective"]) < Fraction(incumbent["exact_feasible_objective"])


def one_repair(i, state, block, valuation, absolute_deadline, clock=time.perf_counter, *, decoder=DECODERS[0]):
    """Return separately scoped master, physical candidate and retained evidence."""
    started = clock()
    if valuation not in VALUATIONS or not math.isfinite(absolute_deadline):
        raise ValueError("Declared valuation and finite deadline required")
    if decoder not in (DECODERS[0], DECODERS[2]) or (valuation == "static" and decoder != DECODERS[0]):
        raise ValueError("Unsupported decoder and valuation combination")
    full_fifo_family = valuation == "fifo" and decoder == DECODERS[0]
    validate_instance(i)
    block = customers(block, i.n, "block")
    if len(block) > 10:
        raise ValueError("Block size exceeds 10")
    routes = [customers(route, i.n, "route") for route in state["routes"]]
    if len(routes) != i.horizon:
        raise ValueError("Route horizon mismatch")
    checked = verify_routes(i, routes, state["quantities"], "completion")
    if not checked.get("checked"):
        raise ValueError("Input state failed literal verification: " + str(checked.get("reason")))
    if state.get("exact_feasible_objective") is not None and Fraction(state["exact_feasible_objective"]) != Fraction(checked["exact_feasible_objective"]):
        raise ValueError("Frozen input objective mismatch")
    if full_fifo_family:
        scope = "free-interleaving fixed-outside-order/block true-completion family"
    elif valuation == "static":
        scope = "constructed exact FIFO representative pool with static route valuation plus true holding"
    else:
        scope = "constructed greedy FIFO profiles with incumbent augmentation"
    answer = {"contract": CONTRACT, "objective_definition": "completion", "decoder": decoder,
              "valuation": valuation, "block": block, "status": "started", "raw_status": None,
              "raw_objective": None, "raw_exact_objective": None, "raw_static_exact_objective": None,
              "raw_valuation_exact_objective": None, "raw_master_lower_bound": None,
              "raw_master_optimal": False, "raw_valuation_master_optimal": False,
              "raw_conditional_optimum_verified": False, "raw_conditional_infeasible": False,
              "conditional_no_improving_move_verified": False,
              "surrogate_master_optimal_bound_verified": False,
              "selected_valuation_objective_matches_solver": False,
              "certificate_numeric_scope": "HiGHS floating-point termination with frozen tolerances and exact feasible replay; not a rational dual proof",
              "global_bound": None, "global_gap": None, "raw_bound_scope": scope,
              "raw_bound_valuation": valuation, "raw_true_completion_lower_bound": None,
              "static_pricing_scope": "unrounded exact rational means of raw arc bins plus service on the same FIFO representatives; computed and paid in both valuations",
              "outside_quantities_free": True, "input_verification": checked,
              "input_in_raw_family": True if full_fifo_family else None,
              "retained_objective": checked["objective_decimal"],
              "retained_exact_objective": checked["exact_feasible_objective"],
              "retained_routes": copy.deepcopy(routes), "retained_quantities": copy.deepcopy(checked["quantities"]),
              "retained_origin": "input_external_fallback", "fallback_reason": None,
              "phase_seconds": {"input_verification": clock() - started}, "period_profiles": [],
              "completed_period_tables": 0, "tables_complete": False,
              "master_started": False, "candidate_verified": False, "candidate_eligible": False,
              "raw_master_evidence_eligible": False, "candidate_true_gain": False,
              "static_candidate_coverage": {"master_candidate_returned": False,
                  "physical_verified": False, "deadline_eligible": False, "true_improvement": False},
              "strict_raw_gain": False, "certificate_seconds": None, "valuation_certificate_seconds": None,
              "profile_complete_seconds": None, "local_deadline": absolute_deadline}
    static_cache = {}

    def finish(reason):
        answer["status"] = reason
        answer["fallback_reason"] = None if answer["retained_origin"] == "verified_raw_repair" else reason
        answer["static_arc_means_cached"] = len(static_cache)
        finished = clock()
        answer["wall_seconds"] = finished - started
        answer["returned_after_local_deadline"] = finished >= absolute_deadline
        if answer["returned_after_local_deadline"]:
            # A valid physical candidate remains diagnostic evidence. Neither
            # it nor a previously computed termination flag can survive a late
            # whole-operation return as eligible/retained search evidence.
            flags = ("candidate_eligible", "raw_master_evidence_eligible", "raw_master_optimal",
                     "raw_valuation_master_optimal", "raw_conditional_optimum_verified",
                     "conditional_no_improving_move_verified", "surrogate_master_optimal_bound_verified")
            answer["late_raw_evidence"] = {key: answer[key] for key in flags}
            answer["late_raw_evidence"].update(status_before_final_gate=reason,
                certificate_seconds=answer["certificate_seconds"],
                valuation_certificate_seconds=answer["valuation_certificate_seconds"],
                true_completion_lower_bound=answer["raw_true_completion_lower_bound"])
            for key in flags:
                answer[key] = False
            answer.update(status="local_deadline_return_rejected", fallback_reason="local_deadline_return_rejected",
                retained_objective=checked["objective_decimal"],
                retained_exact_objective=checked["exact_feasible_objective"],
                retained_routes=copy.deepcopy(routes), retained_quantities=copy.deepcopy(checked["quantities"]),
                retained_origin="input_external_fallback", strict_raw_gain=False,
                certificate_seconds=None, valuation_certificate_seconds=None,
                raw_true_completion_lower_bound=None)
            answer["static_candidate_coverage"]["deadline_eligible"] = False
        return answer

    if clock() >= absolute_deadline:
        return finish("input_verification_deadline")
    phase = clock()
    net = FifoNetwork(i)
    tables = []
    for route in routes:
        outside = [a for a in route if a not in set(block)]
        try:
            table = build_profiles(i, outside, block, decoder, net, route,
                                   deadline=absolute_deadline, clock=clock)
        except ProfileInterrupted as exc:
            answer["interrupted_profile_counters"] = exc.counters
            answer["phase_seconds"]["profiles"] = clock() - phase
            return finish("profile_deadline")
        tables.append(table)
        fifo, static = profile_scores(i, table, static_cache)
        scores = fifo if valuation == "fifo" else static
        evidence = {key: value for key, value in table.items() if key != "values"}
        evidence.update(values=[finite_or_none(value) for value in table["values"]], outside=outside,
                        static_values_exact=[None if value is None else str(value) for value in static],
                        valuation_values_exact=[None if value is None else str(value) for value in scores],
                        true_header_eligible_masks=eligible_masks(table, i.deadline))
        answer["period_profiles"].append(evidence)
        answer["completed_period_tables"] += 1
    answer["tables_complete"] = True
    answer["profile_complete_seconds"] = clock() - started
    answer["phase_seconds"]["profiles"] = clock() - phase
    # A constructed pool may replace the physical incumbent with another
    # representative for its membership. Check literal path containment.
    if not full_fifo_family:
        answer["input_in_raw_family"] = all(any(path == route for path in table["routes"])
                                              for route, table in zip(routes, tables))
    phase = clock()
    model = build_master(i, routes, block, tables, valuation, static_cache)
    answer["phase_seconds"]["master_build"] = clock() - phase
    answer["patterns_by_period"] = [len(cols) for cols in model["columns"]]
    if clock() >= absolute_deadline:
        return finish("master_build_deadline")
    if "infeasible_period" in model:
        answer["raw_status"] = 2
        return finish("incumbent_membership_containment_contradiction_no_period_profile")
    lp = model["lp"]
    answer.update(master_started=True, variables=len(lp.c), binary_visits=len(block) * i.horizon)
    phase = clock()
    result = milp(lp.c, integrality=model["integrality"], bounds=model["bounds"],
                  constraints=model["constraints"],
                  options={"time_limit": max(.001, absolute_deadline - clock()), **MILP_OPTIONS})
    answer["phase_seconds"]["master_solve"] = clock() - phase
    answer.update(raw_status=int(result.status), solver_message=str(result.message),
                  raw_solver_objective=finite_or_none(result.fun),
                  raw_master_lower_bound=finite_or_none(getattr(result, "mip_dual_bound", None)),
                  raw_mip_gap=finite_or_none(getattr(result, "mip_gap", None)),
                  raw_mip_node_count=finite_or_none(getattr(result, "mip_node_count", None)))
    if clock() >= absolute_deadline:
        return finish("master_solve_deadline")
    answer["raw_master_evidence_eligible"] = True
    if full_fifo_family:
        answer["raw_true_completion_lower_bound"] = answer["raw_master_lower_bound"]
    if result.status == 2:
        return finish("incumbent_membership_containment_contradiction_master_infeasible")
    if result.x is None:
        return finish("raw_master_no_candidate")
    answer["static_candidate_coverage"]["master_candidate_returned"] = True
    selected = [max(cols, key=lambda mask: result.x[cols[mask]]) for cols in model["columns"]]
    answer["selected_profile_masks"] = selected
    new_routes = [tables[p]["routes"][mask] for p, mask in enumerate(selected)]
    phase = clock()
    recourse = inventory_recourse(i, new_routes, time_limit=max(.001, absolute_deadline - clock()))
    answer["phase_seconds"]["recourse"] = clock() - phase
    answer["recourse_status"] = recourse.get("status", 0 if recourse.get("success") else None)
    if clock() >= absolute_deadline:
        return finish("recourse_deadline")
    if not recourse.get("success"):
        return finish("recourse_failure")
    phase = clock()
    verification = verify_routes(i, new_routes, recourse["quantities"], "completion")
    answer["phase_seconds"]["candidate_verification"] = clock() - phase
    answer["raw_verification"] = verification
    answer["candidate_verified"] = bool(verification.get("checked"))
    answer["static_candidate_coverage"]["physical_verified"] = answer["candidate_verified"]
    if not verification.get("checked"):
        return finish("candidate_verification_rejected")
    objectives = candidate_objectives(i, verification, static_cache)
    answer.update(raw_objective=verification["objective_decimal"],
                  raw_exact_objective=verification["exact_feasible_objective"],
                  raw_static_exact_objective=str(objectives["static"]),
                  raw_valuation_exact_objective=str(objectives["true" if valuation == "fifo" else "static"]),
                  raw_holding_exact_objective=str(objectives["holding"]),
                  raw_routes=copy.deepcopy(new_routes), raw_quantities=verification["quantities"],
                  candidate_true_gain=strictly_improves_true_cost(verification, checked))
    if clock() >= absolute_deadline:
        return finish("candidate_verification_deadline")
    answer["candidate_eligible"] = True
    answer["static_candidate_coverage"].update(deadline_eligible=True, true_improvement=answer["candidate_true_gain"])
    answer.update(certificate_flags(valuation, result.status, result.fun, objectives, decoder=decoder))
    if answer["raw_valuation_master_optimal"]:
        answer["valuation_certificate_seconds"] = clock() - started
    if answer["raw_conditional_optimum_verified"]:
        answer["certificate_seconds"] = answer["valuation_certificate_seconds"]
        answer["conditional_no_improving_move_verified"] = not answer["candidate_true_gain"]
    if answer["candidate_true_gain"]:
        answer.update(retained_objective=verification["objective_decimal"],
                      retained_exact_objective=verification["exact_feasible_objective"],
                      retained_routes=copy.deepcopy(new_routes), retained_quantities=verification["quantities"],
                      retained_origin="verified_raw_repair", strict_raw_gain=True)
        return finish("raw_strict_improvement")
    return finish("raw_verified_nonimprovement")
