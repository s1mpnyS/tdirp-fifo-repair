# A+/G/J synthetic server confirmation

This prospective cohort narrows the V15 design to one comparison of
two-stage continuation and two joint repair decoders. It is separate from
the six-arm V15 design and the two-input server pilot.

## Inputs and allocations

- Use the 40 previously selected V15 synthetic variants in
  `data/confirmation_inputs.json`. They comprise ten latent families
  with four (n,H) variants per family. The two exploratory pilot
  families are outside this grid. Freeze the exact input bytes, their
  independently replayed canonical witnesses (C_0), and this protocol.
- Each of 120 assignments has a 120-second parent cap, one logical
  CPU, one numerical thread, 1,024 MiB sampled process-tree RSS and a
  three-second final reserve. Keep the one-second monitoring-gap flag.
  The matched algorithm seed is 20261221. Shuffle file blocks and arms
  within each block with seed 20261227.
- Each arm pays for visit-first construction (ten-second allocation)
  and its first two-stage solve (30-second allocation). Both phase caps
  include three seconds of reserve. Store the physical handoff and
  actual handoff clock. Record the canonical witness if the constructor
  fails. The prefix can produce different handoffs under wall limits.
- Use one common true completion-plus-holding objective with the
  original file return limit. Independently verify every retained
  improvement. Observe and hash checkpoints before accepting them.

## Continuations

| Arm | Work after handoff |
| --- | --- |
| A+ | Repeat complete static IRP plus fixed-membership FIFO routing, warm-started from the latest verified incumbent. |
| G | Joint repair with legacy greedy FIFO representatives and incumbent augmentation. |
| J | Joint repair with exact free-interleaving FIFO representatives. |

A+ uses a deterministic restart seed and a reversible customer
permutation for the static solve. The depot stays first and physical
labels are restored before FIFO routing. Each restart can use up to 27
seconds of work and stops at the common 117-second work limit. Allow a
restart when at least 0.25 seconds remain. Static membership repeats,
solver nodes, accepted starts, verified restart artifacts, and exact
incumbent costs are recorded. Restarting keeps the same mathematical
static problem and can still yield duplicate plans. A+ is an adapted
two-stage baseline under the common model.

G/J use the same FIFO valuation, inventory master, recourse and true
acceptance. Use k=6, a six-second local work limit and a common block
sequence keyed by input hash, algorithm seed and repair ordinal.
Independent receipt and resource checks apply to all arms.

## Analysis

The paired primary contrasts are J versus A+ and G versus A+. J versus
G is the decoder contrast. Report raw cost differences and
`100*(comparator-treat)/C0`, with equal weights for the four variants
in each family and then equal weights for the ten families. Report
family mean and median, exact file and family wins/ties/losses, and a
95% percentile interval from 10,000 whole-family resamples with seed
20261229. Show all file pairs. Use the earlier +0.2 pp as a reference
for practical magnitude. Report small effects and uncertainty directly.

For decoder timing, the first repair pair qualifies when both runs
have clean resource timing, the same verified handoff and block,
at least 5.999 seconds of local allowance, and complete profile tables
with timely returns. Report the eligible denominator and median
J/G profile-build wall ratio. Keep search-trajectory medians and
repair counts separate from that fixed-state metric. Record first
eligible post-handoff improvement and exact local no-improvement
certificates under the existing numerical contract.

Preserve all assigned cells, including fallbacks and resource flags.
Use a new output directory with an externally verified execution
timestamp. A crashed campaign retains its original per-cell evidence
and lacks a complete aggregate. The launcher creates one cell directory
per assignment and provides no automatic reruns. A worker or parent
error outside a declared resource stop aborts the campaign with a log
pointer. Replay verifies the
indexed parent results and processes them one at a time. Allow about
15 GiB free for the evidence and run inside a persistent server shell.
The total solver allocation is four hours, plus preparation and replay.
