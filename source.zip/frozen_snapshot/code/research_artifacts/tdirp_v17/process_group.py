"""Linux worker process-group cleanup and sampled process-tree RSS."""
import os
import signal

import psutil


class LinuxProcessGroup:
    def __init__(self):
        self.process = None

    def attach(self, process):
        if os.getpgid(process.pid) != process.pid:
            raise RuntimeError("Worker did not enter a separate process group")
        self.process = process

    def sample(self):
        processes = []
        try:
            root = psutil.Process(self.process.pid)
            tree = [root, *root.children(recursive=True)]
        except psutil.NoSuchProcess:
            tree = []
        for member in tree:
            try:
                processes.append({"pid": member.pid, "resident_bytes": member.memory_info().rss})
            except psutil.NoSuchProcess:
                continue
        return {"resident_bytes": sum(member["resident_bytes"] for member in processes),
                "processes": processes}

    def terminate(self):
        if self.process is None:
            return
        try:
            os.killpg(self.process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    def close(self):
        self.terminate()
