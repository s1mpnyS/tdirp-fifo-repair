"""Prepare and replay the fixed-handoff sensitivity inputs without a solver."""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile


HERE = Path(__file__).resolve().parent
CODE = HERE.parents[1]
GENERATOR = HERE / "data/generate_synthetic_stress.py"
CONFIG = HERE / "data/synthetic_stress_v1.json"
VERIFIER = CODE / "validate_v10_reference.py"
SCHEMA = "tdirp_v17_sensitivity_inputs_v1"
FAMILY_SEEDS = tuple(range(20261261, 20261271))
N, H = 50, 6
TREATMENTS = {"base": "1", "q_mid": "1", "q_low": "1", "h_0_5": "1/2", "h_2": "2", "h_5": "5"}


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def require(value, message):
    if not value:
        raise ValueError(message)


def source_hashes():
    """Use checkout-relative paths so the prepared data can travel to the server."""
    paths = (Path(__file__).resolve(), GENERATOR, CONFIG, VERIFIER)
    return {path.relative_to(CODE).as_posix(): sha(path.read_bytes()) for path in paths}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def identity(seed, treatment):
    m = 30 if (seed - FAMILY_SEEDS[0]) % 2 == 0 else 120
    return f"sensitivity_seed{seed}_H{H}_n{N}_M{m}_{treatment}.txt", m


def capacities(q_base, q_low):
    q_mid = (q_base + q_low + 1) // 2
    require(0 < q_low <= q_mid <= q_base, "Invalid capacity levels")
    return {"base": q_base, "q_mid": q_mid, "q_low": q_low}


def treatment_bytes(base, q, multiplier):
    rows = [line.split() for line in base.decode("ascii").splitlines()]
    rows[0][2] = str(q)
    if multiplier != 1:
        for row in rows[2:2 + N]:
            mills = 1000 * Fraction(row[-2]) * multiplier
            require(mills.denominator == 1, "Unexpected holding precision")
            whole, remainder = divmod(mills.numerator, 1000)
            row[-2] = f"{whole}.{remainder:03d}"
    return ("\n".join(" ".join(row) for row in rows) + "\n").encode("ascii")


def cost_components(instance, checked):
    """Decompose a verified cost and recover physical end-period inventory units."""
    stock = instance["initial"]
    supplier = instance["supplier_initial"]
    customer_units = 0
    customer_cost = supplier_cost = Fraction(0)
    periods = zip(instance["demand"], checked["quantities"], instance["production"], strict=True)
    for demand, delivery, production in periods:
        stock = [s + q - d for s, q, d in zip(stock, delivery, demand, strict=True)]
        supplier += production - sum(delivery)
        customer_units += sum(stock)
        customer_cost += sum(h * s for h, s in zip(instance["holding"][1:], stock, strict=True))
        supplier_cost += instance["holding"][0] * supplier
    route = sum(checked["return_times"])
    objective = Fraction(checked["exact_feasible_objective"])
    require(customer_cost + supplier_cost + route == objective, "Verified cost decomposition mismatch")
    return {"route_completion": route, "customer_inventory_units": customer_units,
            "customer_holding_cost": str(customer_cost), "supplier_holding_cost": str(supplier_cost),
            "objective_exact": str(objective)}


def describe(base, instance, checked, seed, treatment):
    name, m = identity(seed, treatment)
    base_name, _ = identity(seed, "base")
    loads = [sum(period) for period in checked["quantities"]]
    physical = {field: checked[field] for field in ("routes", "quantities")}
    q_base = int(base.splitlines()[0].split()[2])
    q_low = max(loads)
    levels = capacities(q_base, q_low)
    alias = None
    if treatment in levels:
        earliest = next(level for level, q in levels.items() if q == levels[treatment])
        if earliest != treatment:
            alias, _ = identity(seed, earliest)
    return {"input": name, "input_name": name, "relpath": name, "base_input": base_name,
            "family": f"latent-{seed}", "family_seed": seed, "n": N, "H": H, "M": m,
            "source": "synthetic_sensitivity", "treatment": treatment,
            "schedule_sha256": sha(base), "physical_sha256": sha(canonical(physical)),
            "witness_relpath": name + ".witness.json", "Q": instance["Q"],
            "Q_base": q_base, "Q_low": q_low, "alias_of": alias,
            "return_limit": instance["deadline"], "holding_multiplier": TREATMENTS[treatment],
            "anchor_loads": loads, "anchor_load_slack": [instance["Q"] - load for load in loads],
            "anchor_cost": cost_components(instance, checked)}


def generate(destination):
    """Generate the complete prespecified roster and verify every treatment."""
    bound_sources = source_hashes()
    generator = load_module("_sensitivity_geometric_generator", GENERATOR)
    verifier = load_module("_sensitivity_independent_physical", VERIFIER)
    cfg = generator.load_config(CONFIG)
    require(not set(FAMILY_SEEDS) & set(cfg["family_seeds"]), "Sensitivity family overlaps the primary roster")
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    rows, traffic_checks = [], []
    for seed in FAMILY_SEEDS:
        _, m = identity(seed, "base")
        family = generator.draw_family(cfg, seed)
        travel = {bins: generator.restrict_travel(family, N, bins) for bins in cfg["M_values"]}
        completion = {bins: generator.completion(arcs, N, bins, cfg["customer_service_seconds"])
                      for bins, arcs in travel.items()}
        cutoff = generator.ceil_fraction(Fraction(105, 100) * max(completion.values()))
        require(cutoff < cfg["traffic_day_seconds"], "Canonical cutoff outside traffic day")
        certs = [generator.certify_fifo(arc, cfg["traffic_day_seconds"] // m) for arc in travel[m]]
        traffic_checks.append({"family_seed": seed, "M": m, "arcs": len(certs),
                               "bins_checked": sum(c["bins"] for c in certs),
                               "boundary_checks": sum(c["boundary_checks"] for c in certs)})
        base = generator.serialize_variant(cfg, family, N, H, m, cutoff, travel[m])
        anchor = generator.canonical_witness(family, N, H)
        base_instance = verifier.parse_instance(base)
        q_by_treatment = capacities(base_instance["Q"], max(map(sum, anchor["quantities"])))
        for treatment, multiplier in TREATMENTS.items():
            data = treatment_bytes(base, q_by_treatment.get(treatment, base_instance["Q"]), Fraction(multiplier))
            generator.strict_schema_check(data, N, H, m)
            instance = verifier.parse_instance(data)
            checked = verifier.verify_physical(instance, anchor)
            require(checked["return_times"] == [completion[m]] * H, "Independent clock differs from constructive clock")
            row = describe(base, instance, checked, seed, treatment)
            witness = canonical(checked) + b"\n"
            row.update(sha256=sha(data), witness_sha256=sha(witness))
            (destination / row["relpath"]).write_bytes(data)
            (destination / row["witness_relpath"]).write_bytes(witness)
            rows.append(row)
    require(source_hashes() == bound_sources, "Sensitivity source changed during generation")
    manifest = {"schema": SCHEMA, "source_sha256": bound_sources, "optimizer_called": False,
                "files": rows, "fifo_certificates": traffic_checks}
    path = destination / "manifest.json"
    path.write_bytes(canonical(manifest) + b"\n")
    return path


def inputs(manifest_path):
    manifest = json.loads(Path(manifest_path).read_bytes())
    require(manifest["schema"] == SCHEMA and manifest["optimizer_called"] is False
            and manifest["source_sha256"] == source_hashes(), "Sensitivity manifest schema/source mismatch")
    rows = manifest["files"]
    roster = [(seed, treatment) for seed in FAMILY_SEEDS for treatment in TREATMENTS]
    require(len(rows) == len(roster), "Sensitivity roster size differs")
    for row, (seed, treatment) in zip(rows, roster, strict=True):
        name, m = identity(seed, treatment)
        require((row["input"], row["input_name"], row["relpath"], row["witness_relpath"])
                == (name, name, name, name + ".witness.json")
                and (row["family_seed"], row["treatment"], row["n"], row["H"], row["M"]) == (seed, treatment, N, H, m),
                "Sensitivity assignment differs from the fixed roster")
    return {row["input"]: row for row in rows}


def prepare_inputs(archive, manifest_path, verifier):
    """Replay the exact treatments and shared physical anchors while packaging the runtime ZIP."""
    files = inputs(manifest_path)
    directory = Path(manifest_path).parent
    warm = {}
    with zipfile.ZipFile(archive, "x") as out:
        for name, row in files.items():
            payload = (directory / row["relpath"]).read_bytes()
            witness = (directory / row["witness_relpath"]).read_bytes()
            require(sha(payload) == row["sha256"] and sha(witness) == row["witness_sha256"], "Input or witness changed: " + name)
            base_name, _ = identity(row["family_seed"], "base")
            base = (directory / base_name).read_bytes()
            base_row = files[base_name]
            require(sha(base) == base_row["sha256"], "Base input changed: " + base_name)
            instance = verifier.parse_instance(payload)
            saved = json.loads(witness)
            point = verifier.verify_physical(instance, saved)
            expected = describe(base, instance, point, row["family_seed"], row["treatment"])
            q_values = capacities(expected["Q_base"], expected["Q_low"])
            require(point == saved and all(row[key] == value for key, value in expected.items())
                    and expected["physical_sha256"] == base_row["physical_sha256"]
                    and payload == treatment_bytes(base, q_values.get(row["treatment"], expected["Q_base"]),
                                                  Fraction(expected["holding_multiplier"])),
                    "Sensitivity treatment or shared handoff differs: " + name)
            warm[name] = point
            for member, data in ((name, payload), (row["witness_relpath"], witness)):
                out.writestr(zipfile.ZipInfo(member), data, compress_type=zipfile.ZIP_DEFLATED)
    return files, warm


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = generate(args.output)
    print(json.dumps({"manifest": str(manifest), "sha256": sha(manifest.read_bytes()),
                      "families": len(FAMILY_SEEDS), "settings": len(FAMILY_SEEDS) * len(TREATMENTS)}))


if __name__ == "__main__":
    main()
