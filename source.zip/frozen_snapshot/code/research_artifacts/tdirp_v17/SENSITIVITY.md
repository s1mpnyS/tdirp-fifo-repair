# Capacity and holding sensitivity from common verified plans

This prospective experiment uses ten fresh latent generator seeds
20261261–20261270, each with one 50-customer, six-period file. The bin
counts alternate between 30 and 120. No existing benchmark family is
pooled with this cohort. The constructor is the generator's canonical
witness, which visits all customers in index order and delivers only
what is needed to maintain feasibility. This deterministic start is
deliberately shared across regimes. The study estimates repair value
from that fixed start. Starting quality and end-to-end performance
under regime-specific initialization are separate questions.

## Treatments and execution

- At the original holding vector, use the original capacity `Q0`,
  `Q_low` equal to the canonical witness's peak period load, and
  `Q_mid = ceil((Q0 + Q_low)/2)`. `Q_low` has a constructive feasibility
  witness and makes no minimum-feasible-capacity claim. Fix all three
  values before running K1/K6. Independently replay every period under
  the modified capacity, including inventory and storage bounds, depot
  supply, FIFO routes and return limit. Report load and slack per period.
- At original capacity, use customer holding-price factors `0.5`, `1`,
  `2` and `5`. Depot holding stays fixed. Independently replay the same
  routes and quantities and recompute the exact objective under each
  treatment, including the start denominator. The two axes share the
  base pair. They contain no crossed treatments and estimate no
  capacity–holding interaction. An identical capacity dose shares its
  original execution and is marked as an alias in reporting.
- Use search seeds `20261271` and `20261272`. Shuffle paired blocks and
  arms with `20261273`. K1 and K6 share the exact FIFO decoder,
  seed-dependent sweep, acceptance and resource rules of [coordination](COORDINATION.md).
  The original input digest fixes sweep identity across treatments.
  Each arm receives a 90-second wall limit, including a three-second
  reserve, one pinned logical CPU, one numerical thread and a sampled
  1,024 MiB process-tree memory cap. Generation and preparation are
  outside this online budget. Return-limit sensitivity is outside this
  plan.

## Prespecified analysis

The primary outcome is `G = 100*(f(K1)-f(K6))/f(start)` under the
same treatment for all three terms. The treatment contrast is `G-G_base`
for the same file and seed. Average seed pairs within family, weight
families equally, and report pointwise 95% percentile intervals from
10,000 paired family resamples. Show individual family and seed
contrasts and coverage. Treat levels as categorical. No directional
test or monotonicity claim is prespecified. Report raw objective gaps,
route completion, customer inventory-unit-periods, and customer and
depot holding. For holding contrasts, decompose the change into plan
gap at original prices, direct repricing of the treated plans, and
the changed denominator. The decomposition is an accounting identity.

Calculate repair efficiency as the retained verified reduction from
the shared start divided by worker process CPU seconds over the repair
tail. This includes native threads in-process, profiles, MIP, recourse,
verification and attempt publication, including work on nonaccepted
attempts. It excludes worker setup before repair, parent verification,
and the final tail-summary publication. These repair calls launch no
solver subprocess. Missing final CPU readbacks remain missing. Keep
the wall budget as the matching variable. Log attempted repairs from
completed worker tails, independently received returns, full profile
builds, numerical conditional certificates, and improving moves.

Retain all scheduled arms. A resource stop or technical worker failure
retains the best timely, independently replayed checkpoint or the
verified common witness, with its status visible. An unstarted cell
has no endpoint. A parent or campaign interruption preserves the index;
it can be analyzed as incomplete. No automatic reruns. Report any later
recovery as a deviation. Use one fresh directory per campaign.

## Directed probe

Schedule one probe for each assigned K1 endpoint. A probe requires a
timely fixed-handoff record, clean resource timing and independent
replay of the retained K1 state. If absent, the probe is unresolved.
Freeze a hash-based customer order keyed by the original input digest
and seed. The first six customers in that order form the only K6 block.
Audit singletons on the same state in the fixed order, with at most one
second per call and twenty seconds in total. A verified improving
singleton suffices to classify the endpoint as improving. A certified
endpoint requires all 50 singleton calls to certify no strictly
improving move under the existing numerical termination and exact
physical replay contract. All other endpoints remain unresolved.

Apply one exact K6 repair with a six-second cap and the same exact
strict-improvement rule. Skip separate polishing. The probe is outside
the equal-wall comparison and has its own 32-second monitored parent
cap including reserve and setup. The latest timely probe receipt binds
the K1 parent result digest, source state, tested blocks and outcomes.
Report `certified joint hits / singleton-certified states` and
`certified joint hits / assigned states`, plus certification coverage,
unresolved cases and K6 attempts and deadline returns. These are rates
for the declared sampling and time policy. An unresolved or unavailable
case remains visible in the full denominator.

## Server run

From the repository root with its existing Python environment active:

```bash
P=code/research_artifacts/tdirp_v17
OUT="code/runs/sensitivity-$(date -u +%Y%m%dT%H%M%SZ)"
python -B "$P/sensitivity.py" prepare --output "$OUT" && python -B "$P/sensitivity.py" run --output "$OUT"
```

`prepare` writes the input manifest, replayed warm starts, run plan,
analysis code hashes and execution-freeze manifest without invoking a
solver. `run` obtains and verifies an RFC 3161 timestamp on the frozen
manifest before dispatch. The timestamp provides external evidence of
the digest. A public registration is a separate action. The complete
report is `analysis.json`. After an interruption, `sensitivity.py
analyze --output "$OUT"` uses the available indexed evidence in place.

The maximum nominal allocation is six hours for the 240 arm cells and
64 minutes for the 120 probes. Preparation, replay and storage are extra.
Each completed cell losslessly packs the parent result, attempts,
checkpoints and receipts after the timed phase. The packed evidence
index records compressed and original byte counts and the archive hash.
Analysis and probes read the indexed archives directly. Leave working
space for one loose cell and its ZIP in addition to the prior archives.
