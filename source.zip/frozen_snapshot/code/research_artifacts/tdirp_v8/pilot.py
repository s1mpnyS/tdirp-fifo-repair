"""Frozen source-control/initialization pilot; historical cohorts stay unchanged.

Prepare starts and the exact cell order before running any search. Commands
never retry a failed scientific cell or replace an unavailable initializer.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
import time
import traceback
import uuid
import zipfile

BASE = Path(__file__).resolve().parent
ART = BASE.parent
CODE = ART.parent
for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
                 "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[variable] = "1"
sys.path.insert(0, str(BASE))
import execution

ARCHIVE_SHA256 = "90f4b2e5705f43d1a1b2a574ea2f2ac35c443c04fedff8ebf77ac6fecb0e093c"
CASES = ("H6/inst_15_12_2.txt", "H6/inst_20_60_2.txt",
         "H3/inst_25_12_2.txt", "H3/inst_30_60_2.txt")
METHODS = execution.METHODS
STARTS = ("original", "consolidation")
SEEDS = (20261141, 20261142)
ORDER_SEED = 20261143


def now():
    return datetime.now(timezone.utc).isoformat()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def bind_archive(archive):
    for folder in ("tdirp_math_audit", "tdirp_newalgo", "tdirp_v3"):
        sys.path.insert(0, str(ART / folder))
    import model_probe
    import frozen_start
    model_probe.ARCHIVE = frozen_start.ARCHIVE = Path(archive)
    return frozen_start


def verify_historical_core():
    manifest = load(CODE / "package_manifest.json")
    # Existing frozen package files stay unchanged while new modules are added.
    for relative, entry in manifest["files"].items():
        if execution.sha(CODE / relative) != entry["sha256"]:
            raise ValueError("Package file changed: " + relative)


def sources():
    paths = set()
    for method in METHODS:
        paths.update(execution.source_paths(method))
    return {path.relative_to(CODE).as_posix(): execution.sha(path)
            for path in sorted(paths)}


def verify_sources(expected):
    actual = sources()
    if actual != expected:
        changed = sorted(k for k in set(actual) | set(expected)
                         if actual.get(k) != expected.get(k))
        raise ValueError("Frozen pilot source changed: " + ", ".join(changed))


def prior_usage_registry(workspace, cases):
    """Bounded record search; absence is not an exhaustive held-out certificate."""
    records = []
    roots = [workspace / "research_artifacts" / name for name in
             ("tdirp_newalgo", "tdirp_followup", "tdirp_v3", "tdirp_v4",
              "tdirp_v5", "tdirp_v6", "tdirp_v7")]
    for root in roots:
        if not root.exists():
            continue
        for directory, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if not d.endswith("_checkpoints")
                       and d not in {"checkpoints", "frozen_source", "frozen",
                                     "initials", "literature", "snapshots"}]
            for name in files:
                if not name.endswith(".json") or not any(
                        token in name.lower() for token in ("results", "aggregate", "plan", "protocol")):
                    continue
                path = Path(directory) / name
                if path.stat().st_size > 80 * 1024**2:
                    continue
                content = path.read_bytes()
                matches = [case for case in cases if case.encode() in content]
                records.append({"file": path.relative_to(workspace).as_posix(),
                                "sha256": hashlib.sha256(content).hexdigest(),
                                "matching_selected_cases": matches,
                                "role": "outcome" if "result" in name.lower() else "plan_or_protocol"})
    return {"scope": "Bounded previous record search; no geographical independence or held-out claim",
            "files_checked": len(records), "records": records,
            "selected_case_hits": {case: [row["file"] for row in records
                                          if case in row["matching_selected_cases"]] for case in cases}}


def initializer_worker(args):
    while not Path(args.gate).exists():
        if time.perf_counter() >= args.parent_start + args.hard_seconds:
            raise TimeoutError("Initializer launch gate timeout")
        time.sleep(.005)
    frozen = bind_archive(args.archive)
    if args.kind == "original":
        record = frozen.create_start(args.case, args.output, seconds=args.inner_seconds,
                                     seed=args.initial_seed)
    else:
        from consolidation_start import create_start
        record = create_start(args.case, args.output, seconds=args.inner_seconds,
                              seed=args.initial_seed, memory_limit_mib=args.memory,
                              max_patterns=8, route_starts=8)
    if not record.get("success"):
        raise SystemExit(2)


def initialize_one(root, case, kind, archive, inner_seconds, hard_seconds, memory):
    stem = case.replace("/", "_") + "_" + kind
    output = root / "initials" / (stem + ".json")
    output.parent.mkdir(parents=True, exist_ok=True)
    gate = output.with_suffix(".gate")
    log_path = output.with_suffix(".log")
    command = [sys.executable, "-B", str(Path(__file__).resolve()), "--init-worker",
               "--case", case, "--kind", kind, "--output", str(output),
               "--gate", str(gate), "--archive", str(archive),
               "--inner-seconds", str(inner_seconds), "--hard-seconds", str(hard_seconds),
               "--memory", str(memory), "--initial-seed", str(SEEDS[0])]
    started = time.perf_counter()
    command += ["--parent-start", str(started)]
    job = process = None
    stop = error = None
    samples = []
    try:
        with log_path.open("w", encoding="utf-8") as log:
            job = execution.WindowsJob()
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                       env=dict(os.environ, PYTHONIOENCODING="utf-8"),
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            job.attach(process)
            execution.atomic(gate, {"attached": True})
            while True:
                info = job.sample()
                samples.append({"elapsed_seconds": time.perf_counter()-started, **info})
                if info["resident_bytes"] > memory * 1024**2:
                    stop = "resident_memory_limit"
                if process.poll() is not None:
                    break
                if stop or time.perf_counter() >= started + hard_seconds:
                    stop = stop or "wall_time_limit"
                    job.terminate()
                    break
                time.sleep(.1)
            process.wait(timeout=10.)
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        if process is not None and process.poll() is None:
            if job is not None:
                job.terminate()
            else:
                process.kill()
            process.wait(timeout=10.)
    finally:
        if job is not None:
            job.close()
    row = {"input": case, "kind": kind, "initial_file": str(output),
           "success": False, "cold_worker_wall_seconds": time.perf_counter()-started,
           "inner_allowance_seconds": inner_seconds, "hard_wall_seconds": hard_seconds,
           "memory_limit_mib": memory, "external_stop": stop, "error": error,
           "exit_code": None if process is None else process.returncode,
           "peak_sampled_resident_bytes": max((x["resident_bytes"] for x in samples), default=0),
           "samples": samples, "log": str(log_path)}
    if output.is_file():
        try:
            record = load(output)
            row["record"] = record
            if record.get("success") and process.returncode == 0 and stop is None and error is None:
                frozen = bind_archive(archive)
                verified = frozen.validate_plan(frozen.read_instance(case), record)
                row.update(success=True, independent_verification=verified,
                           payload_sha256=execution.sha(output))
        except (ValueError, KeyError, TypeError, OSError) as exc:
            row["error"] = "initial_verification:" + str(exc)
    execution.atomic(output.with_suffix(".execution.json"), row)
    return row


def prepare(args):
    root = args.root.resolve()
    if root.exists():
        raise ValueError("Preserve existing preparation; choose a new --root")
    if execution.sha(args.archive) != ARCHIVE_SHA256:
        raise ValueError("Unexpected benchmark bytes")
    verify_historical_core()
    root.mkdir(parents=True)
    cases = ("H3/inst_5_120_1.txt",) if args.engineering else CASES
    with zipfile.ZipFile(args.archive) as archive:
        for case in cases:
            archive.getinfo(case)
        inputs = {case: hashlib.sha256(archive.read(case)).hexdigest() for case in cases}
    expected = sources()
    inner, hard, reserve = (5., 15., 2.) if args.engineering else (30., 45., 3.)
    seeds = SEEDS[:1] if args.engineering else SEEDS
    stages = [{"name": "engineering" if args.engineering else "primary20",
               "budget_seconds": 8. if args.engineering else 20.,
               "cases": list(cases), "methods": list(METHODS), "seeds": list(seeds)}]
    if not args.engineering:
        stages.append({"name": "diagnostic60", "budget_seconds": 60.,
                       "cases": [CASES[0], CASES[-1]],
                       "methods": [METHODS[0], METHODS[-1]], "seeds": [SEEDS[0]]})
    cells = []
    rng = random.Random(ORDER_SEED)
    for stage in stages:
        selected = [{"stage": stage["name"], "budget_seconds": stage["budget_seconds"],
                     "input": case, "start_kind": kind, "method": method, "seed": seed}
                    for case in stage["cases"] for kind in STARTS
                    for seed in stage["seeds"] for method in stage["methods"]]
        rng.shuffle(selected)
        cells.extend(selected)
    for index, cell in enumerate(cells):
        cell["cell_id"] = f"cell_{index:04d}"
    plan = {"status": "DESIGN_FIXED_BEFORE_INITIALIZATION", "created_utc": now(),
            "run_id": root.name, "engineering_only": args.engineering,
            "contract": execution.CONTRACT, "archive_sha256": ARCHIVE_SHA256,
            "archive": str(args.archive.resolve()), "input_sha256": inputs,
            "methods": list(METHODS), "start_kinds": list(STARTS),
            "initializer_seed": SEEDS[0], "initializer_inner_seconds": inner,
            "initializer_hard_wall_seconds": hard, "reserve_seconds": reserve,
            "sampled_tree_memory_limit_mib": args.memory, "threads": 1,
            "execution_order_seed": ORDER_SEED, "cells": cells,
            "planned_calls": len(cells), "source_hashes": expected,
            "publication_policy": "distinct verified plans plus initialized/final states",
            "scope": "New restricted source-informed control and two-start sensitivity pilot; not full BCHeu reproduction, external geography, or a pooled historical result"}
    execution.atomic(root / "design_before_initialization.json", plan)
    registry = (prior_usage_registry(args.workspace.resolve(), cases) if args.workspace else
                {"scope": "No prior research workspace supplied; no unused/held-out assertion", "files_checked": 0})
    execution.atomic(root / "prior_input_use.json", registry)
    initialization = []
    for case in cases:
        for kind in STARTS:
            verify_sources(expected)
            row = initialize_one(root, case, kind, args.archive, inner, hard, args.memory)
            initialization.append(row)
            execution.atomic(root / "initialization.json", {"rows": initialization})
            print(json.dumps({"initialization": len(initialization), "input": case, "kind": kind,
                              "success": row["success"], "cost": row.get("record", {}).get("objective")}), flush=True)
    plan["initialization"] = [{k: row[k] for k in ("input", "kind", "success", "initial_file")}
                              | ({"payload_sha256": row["payload_sha256"]} if row["success"] else {})
                              for row in initialization]
    verify_sources(expected)
    for relative in expected:
        destination = root / "frozen_source" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(CODE / relative, destination)
    plan.update(status="FROZEN_BEFORE_FIRST_SEARCH", frozen_utc=now())
    execution.atomic(root / "frozen_plan.json", plan)
    print(json.dumps({"frozen": True, "planned_search_calls": len(cells),
                      "initializations_available": sum(row["success"] for row in initialization)}), flush=True)


def run(args):
    root = args.root.resolve()
    plan_path = root / "frozen_plan.json"
    plan = load(plan_path)
    if plan["status"] != "FROZEN_BEFORE_FIRST_SEARCH":
        raise ValueError("A frozen preparation is required")
    verify_sources(plan["source_hashes"])
    archive = Path(plan["archive"])
    if execution.sha(archive) != plan["archive_sha256"]:
        raise ValueError("Frozen archive changed")
    output = root / "results.json"
    if output.exists():
        raise ValueError("A run already exists; no scientific cell is automatically retried")
    initials = {(item["input"], item["kind"]): item for item in plan["initialization"]}
    results = {"status": "RUNNING", "started_utc": now(), "planned_calls": plan["planned_calls"],
               "frozen_plan_sha256": execution.sha(plan_path), "rows": []}
    execution.atomic(output, results)
    for index, cell in enumerate(plan["cells"]):
        verify_sources(plan["source_hashes"])
        initial = initials[(cell["input"], cell["start_kind"])]
        if initial["success"]:
            if execution.sha(initial["initial_file"]) != initial["payload_sha256"]:
                raise ValueError("Frozen full start changed")
            row = execution.run_one(cell["input"], cell["method"], cell["seed"],
                                    initial["initial_file"], root / "workers",
                                    cell["budget_seconds"], plan["reserve_seconds"],
                                    plan["sampled_tree_memory_limit_mib"], archive=archive)
        else:
            row = {"endpoint_eligible": False, "endpoint_objective": None,
                   "failure": "unavailable_declared_initializer", "worker_attempted": False}
        row.update(cell)
        results["rows"].append(row)
        execution.atomic(output, results)
        print(json.dumps({"progress": f"{index+1}/{plan['planned_calls']}",
                          **{k: cell[k] for k in ("stage", "input", "start_kind", "method")},
                          "eligible": row["endpoint_eligible"], "objective": row["endpoint_objective"],
                          "failure": row.get("failure"), "external_stop": row.get("external_stop")}), flush=True)
    results.update(status="COMPLETED", finished_utc=now())
    execution.atomic(output, results)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--init-worker", action="store_true")
    parser.add_argument("--root", type=Path)
    parser.add_argument("--workspace", type=Path, help="Optional previous research records for a bounded input-use search")
    parser.add_argument("--archive", type=Path, default=CODE / "data/Benchmark.zip")
    parser.add_argument("--engineering", action="store_true")
    parser.add_argument("--memory", type=float, default=1024.)
    for key in ("case", "kind", "output", "gate"):
        parser.add_argument("--" + key)
    parser.add_argument("--inner-seconds", type=float)
    parser.add_argument("--hard-seconds", type=float)
    parser.add_argument("--initial-seed", type=int)
    parser.add_argument("--parent-start", type=float)
    args = parser.parse_args()
    if not args.init_worker and args.root is None:
        parser.error("--root is required")
    if args.init_worker:
        initializer_worker(args)
    elif args.prepare:
        prepare(args)
    else:
        run(args)


if __name__ == "__main__":
    main()
