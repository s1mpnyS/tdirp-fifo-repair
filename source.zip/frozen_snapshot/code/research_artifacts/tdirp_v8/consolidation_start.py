"""Independent visit-first, consolidation-oriented full-plan initialization.

This module never calls routing_initializer.build_initial_plan. A binary
visit/inventory planner first minimizes the number of visits. Only a proven
primary optimum permits a secondary holding solve with that count fixed.
FIFO insertion constructs complete routes, followed by all-quantity recourse
and the unchanged literal physical verifier. Route-construction failures may
exclude an attempted period membership, explicitly as a heuristic search
restriction, not a valid original-problem infeasibility cut.

All limits here are cooperative. The caller must use its declared cold-worker
wall/RSS watchdog for hard enforcement, including imports and publication.
Initialization is measured separately from subsequent search workers.
"""
from __future__ import annotations

import ctypes
from datetime import datetime, timezone
from fractions import Fraction
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix

BASE = Path(__file__).resolve().parent
for folder in ("tdirp_math_audit", "tdirp_newalgo", "tdirp_v3"):
    directory = str(BASE.parent / folder)
    if directory not in sys.path:
        sys.path.insert(0, directory)
from schedule_repair import FifoNetwork, inventory_recourse, route_finish, verify_routes, MILP_OPTIONS
from frozen_start import CONTRACT, input_hash, plan_hash, read_instance

INITIALIZER = "visit_first_fifo_insertion_all_quantity_recourse_v1"
DEFAULT_SEED = 20261141
PRIMARY_SHARE = .60
SECONDARY_CAP_SECONDS = 3.


class InitializationLimit(RuntimeError):
    pass


def process_peak_resident_bytes():
    """Process RSS high-water mark, rather than a solver allocation promise."""
    if sys.platform == "win32":
        from ctypes import wintypes
        class Counters(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
        if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
            return None
        return int(counters.PeakWorkingSetSize)
    try:
        import resource
        value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return int(value if sys.platform == "darwin" else value * 1024)
    except (ImportError, OSError, ValueError):
        return None


class ResourceGuard:
    def __init__(self, deadline, memory_limit_mib, reserve_seconds=.25):
        if (not math.isfinite(deadline) or not math.isfinite(memory_limit_mib)
                or memory_limit_mib <= 0 or reserve_seconds < 0):
            raise ValueError("Invalid initializer resource limits")
        self.deadline = float(deadline)
        self.work_deadline = self.deadline - reserve_seconds
        self.memory_limit_bytes = int(memory_limit_mib * 2**20)
        self.peak_resident_bytes = 0
        self._last_memory_check = -math.inf

    def remaining(self):
        return self.work_deadline - time.perf_counter()

    def check(self, final=False):
        now = time.perf_counter()
        if now >= (self.deadline if final else self.work_deadline):
            raise InitializationLimit("initialization_time_limit")
        if final or now - self._last_memory_check >= .05:
            observed = process_peak_resident_bytes()
            if observed is None:
                raise InitializationLimit("memory_monitor_unavailable")
            self.peak_resident_bytes = max(self.peak_resident_bytes, observed)
            self._last_memory_check = now
            if observed > self.memory_limit_bytes:
                raise InitializationLimit("initialization_resident_memory_limit")


def validate_instance(i):
    n, horizon = int(i.n), int(i.horizon)
    if n < 1 or horizon < 1 or i.steps < 1 or i.step_seconds < 1:
        raise ValueError("Positive dimensions and traffic bins are required")
    shapes = {"initial": (n,), "maximum": (n,), "minimum": (n,),
              "demand": (horizon, n), "production": (horizon,), "service": (n,),
              "holding": (n,), "travel": (n + 1, n + 1, int(i.steps))}
    for name, shape in shapes.items():
        array = np.asarray(getattr(i, name))
        if array.shape != shape or not np.isfinite(array).all() or np.any(array < 0):
            raise ValueError("Invalid " + name + " data")
        if name != "holding" and np.any(array != np.rint(array)):
            raise ValueError("Integral benchmark physical data required: " + name)
    physical = np.asarray([i.capacity, i.deadline, i.supplier_initial, i.steps, i.step_seconds])
    if not np.isfinite(physical).all() or np.any(physical < 0) or np.any(physical != np.rint(physical)):
        raise ValueError("Invalid integral physical scalars")
    if not math.isfinite(i.supplier_holding) or i.supplier_holding < 0:
        raise ValueError("Invalid depot holding cost")


def build_visit_model(i, exclusions=(), fixed_visit_count=None):
    """Pure construction of the finite-depot ML planner; no optimization call.

    Exclusions are dictionaries {period, selected}; each forbids that exact
    period membership, including absent-customer bits. They are algorithmic
    search restrictions and are kept separate from physical-model constraints.
    """
    validate_instance(i)
    n, horizon = i.n, i.horizon
    y = np.arange(horizon * n).reshape(horizon, n)
    q = np.arange(horizon * n, 2 * horizon * n).reshape(horizon, n)
    inventory = np.arange(2 * horizon * n, 2 * horizon * n + horizon * (n + 1)).reshape(horizon, n + 1)
    size = 2 * horizon * n + horizon * (n + 1)
    lower = np.zeros(size)
    upper = np.full(size, np.inf)
    upper[y] = 1
    lower[inventory[:, 1:]] = np.asarray(i.minimum)
    integer = np.zeros(size, dtype=np.uint8)
    integer[y] = 1
    visits_objective, holding_objective = np.zeros(size), np.zeros(size)
    visits_objective[y] = 1
    holding_objective[inventory[:, 0]] = i.supplier_holding
    holding_objective[inventory[:, 1:]] = np.asarray(i.holding)
    row_indices, col_indices, values, row_lower, row_upper, row_names = [], [], [], [], [], []

    def add(name, coefficients, lo=-np.inf, hi=np.inf):
        row = len(row_lower)
        for column, value in coefficients.items():
            if value:
                row_indices.append(row)
                col_indices.append(int(column))
                values.append(float(value))
        row_lower.append(float(lo))
        row_upper.append(float(hi))
        row_names.append(name)

    for p in range(horizon):
        balance = {int(inventory[p, 0]): 1., **{int(k): 1. for k in q[p]}}
        if p:
            balance[int(inventory[p - 1, 0])] = -1.
        rhs = i.production[p] + (i.supplier_initial if p == 0 else 0.)
        add(("depot_balance", p), balance, rhs, rhs)
        add(("vehicle_capacity", p), {int(k): 1. for k in q[p]}, hi=i.capacity)
        # A necessary original-route condition, not a static travel surrogate.
        add(("service_time_necessary", p), {int(y[p, k]): i.service[k] for k in range(n)}, hi=i.deadline)
        for k in range(n):
            balance = {int(inventory[p, k + 1]): 1., int(q[p, k]): -1.}
            if p:
                balance[int(inventory[p - 1, k + 1])] = -1.
            rhs = -i.demand[p, k] + (i.initial[k] if p == 0 else 0.)
            add(("customer_balance", p, k), balance, rhs, rhs)
            storage = {int(q[p, k]): 1.}
            if p:
                storage[int(inventory[p - 1, k + 1])] = 1.
            add(("pre_demand_storage", p, k), storage,
                hi=i.maximum[k] - (i.initial[k] if p == 0 else 0.))
            add(("visit_quantity", p, k), {int(q[p, k]): 1., int(y[p, k]): -i.maximum[k]}, hi=0.)
    for index, excluded in enumerate(exclusions):
        p = int(excluded["period"])
        selected = set(map(int, excluded["selected"]))
        if not 0 <= p < horizon or not selected.issubset(set(range(n))):
            raise ValueError("Invalid exact-pattern exclusion")
        # sum_selected(1-y) + sum_absent(y) >= 1.
        add(("heuristic_pattern_exclusion", index, p),
            {int(y[p, k]): -1. if k in selected else 1. for k in range(n)}, lo=1 - len(selected))
    if fixed_visit_count is not None:
        if int(fixed_visit_count) != fixed_visit_count or not 0 <= fixed_visit_count <= n * horizon:
            raise ValueError("Invalid fixed visit count")
        add(("fixed_visit_count",), {int(k): 1. for k in y.ravel()}, fixed_visit_count, fixed_visit_count)
    matrix = coo_matrix((values, (row_indices, col_indices)), shape=(len(row_lower), size)).tocsc()
    return {"visits_objective": visits_objective, "holding_objective": holding_objective,
            "integrality": integer, "bounds": Bounds(lower, upper),
            "constraint": LinearConstraint(matrix, np.array(row_lower), np.array(row_upper)),
            "matrix": matrix, "row_names": row_names, "y": y, "q": q, "inventory": inventory,
            "variables": size, "constraints": len(row_lower)}


def _visit_mask(model, vector):
    values = np.asarray(vector)[model["y"]]
    if not np.isfinite(values).all() or np.max(np.abs(values - np.rint(values))) > 1e-7:
        raise InitializationLimit("planner_returned_nonbinary_visits")
    rounded = np.rint(values).astype(int)
    if np.any(rounded < 0) or np.any(rounded > 1):
        raise InitializationLimit("planner_returned_invalid_visits")
    return rounded


def _solve(model, objective, seconds):
    return milp(objective, integrality=model["integrality"], bounds=model["bounds"],
                constraints=model["constraint"], options={**MILP_OPTIONS, "time_limit": float(seconds)})


def _solve_stats(result, seconds):
    def finite(name):
        value = getattr(result, name, None)
        return float(value) if value is not None and math.isfinite(value) else None
    return {"status": int(result.status), "message": str(result.message), "seconds": seconds,
            "objective": finite("fun"), "dual_bound": finite("mip_dual_bound"),
            "relative_gap": finite("mip_gap"), "has_incumbent": result.x is not None}


def construct_fifo_route(i, selected, net, guard, rng, route_starts=8):
    """Seeded FIFO cheapest insertion, with no invalid partial-route pruning.

    A partial route that misses the return cutoff is not discarded: inserting
    a customer can shorten a nonmetric route. Only complete selected-set routes
    are tested against the deadline. No old initializer or block repair is used.
    """
    customers = sorted(set(map(int, selected)))
    if len(customers) != len(selected) or any(k < 0 or k >= i.n for k in customers):
        raise ValueError("Invalid selected customer set")
    if route_starts < 1:
        raise ValueError("At least one route start is required")
    guard.check()
    if not customers:
        return {"feasible": True, "route": [], "return_time": 0., "starts": 0, "evaluations": 0}
    anchors = list(map(int, rng.permutation(customers)))[:route_starts]
    best_route, best_value, evaluations = None, math.inf, 0
    for attempts, first in enumerate(anchors, 1):
        route, remaining = [first], set(customers) - {first}
        while remaining:
            choice = None
            for customer in sorted(remaining):
                for at in range(len(route) + 1):
                    guard.check()
                    candidate = route[:at] + [customer] + route[at:]
                    value = float(route_finish(i, candidate, net))
                    evaluations += 1
                    key = (value, customer, at)
                    if choice is None or key < choice[0]:
                        choice = (key, candidate, customer)
            _, route, customer = choice
            remaining.remove(customer)
        value = float(route_finish(i, route, net))
        if best_route is None or (value, tuple(route)) < (best_value, tuple(best_route)):
            best_route, best_value = route, value
        if math.isfinite(value) and value <= i.deadline:
            return {"feasible": True, "route": route, "return_time": value,
                    "starts": attempts, "evaluations": evaluations}
    return {"feasible": False, "route": best_route,
            "return_time": best_value if math.isfinite(best_value) else None,
            "starts": len(anchors), "evaluations": evaluations,
            "scope": "route-construction failure, not selected-set or original-problem infeasibility"}


def plan_components(i, checked):
    completion = sum(checked["return_times"])
    moving = sum(checked["travel_times"])
    holding = Fraction(checked["holding_cost"])
    value = Fraction(checked["exact_feasible_objective"])
    if value != completion + holding:
        raise ValueError("Verified objective components do not add exactly")
    return {"objective": float(value), "exact_objective": str(value),
            "moving": moving, "service": completion - moving,
            "holding": float(holding), "exact_holding": str(holding),
            "customer_stops": sum(map(len, checked["routes"])),
            "active_period_routes": sum(bool(route) for route in checked["routes"]),
            "zero_quantity_stops": sum(checked["quantities"][p][k] == 0
                                       for p, route in enumerate(checked["routes"]) for k in route)}


def build_consolidation_plan(i, *, seconds=30., deadline=None, seed=DEFAULT_SEED,
                             memory_limit_mib=1024, max_patterns=8, route_starts=8):
    started = time.perf_counter()
    if seconds <= 0 or not math.isfinite(seconds) or max_patterns < 1 or route_starts < 1:
        raise ValueError("Invalid initialization budget or construction policy")
    if deadline is not None and not math.isfinite(deadline):
        raise ValueError("Invalid absolute deadline")
    end = min(started + seconds, deadline) if deadline is not None else started + seconds
    guard = ResourceGuard(end, memory_limit_mib)
    result = {"success": False, "initializer": INITIALIZER, "seed": int(seed),
              "generation_budget_seconds": seconds, "memory_limit_mib": memory_limit_mib,
              "max_patterns": max_patterns, "route_starts": route_starts,
              "attempts": [], "heuristic_pattern_exclusions": [], "global_bound": None,
              "global_gap": None, "old_initializer_used": False,
              "scope": "independent visit-first feasible-start heuristic; planner optima are not true objective/global certificates"}
    try:
        guard.check()
        validate_instance(i)
        setup = time.perf_counter()
        net = FifoNetwork(i)
        result["fifo_setup_seconds"] = time.perf_counter() - setup
        rng = np.random.default_rng(seed)
        exclusions = result["heuristic_pattern_exclusions"]
        for attempt_number in range(max_patterns):
            guard.check()
            attempt = {"number": attempt_number + 1}
            result["attempts"].append(attempt)
            lap = time.perf_counter()
            model = build_visit_model(i, exclusions)
            attempt["model_build_seconds"] = time.perf_counter() - lap
            guard.check()
            lap = time.perf_counter()
            primary_allowance = PRIMARY_SHARE * guard.remaining()
            if primary_allowance <= 0:
                raise InitializationLimit("initialization_time_limit")
            primary = _solve(model, model["visits_objective"], primary_allowance)
            attempt["primary"] = _solve_stats(primary, time.perf_counter() - lap)
            guard.check()
            if primary.x is None:
                result["reason"] = "visit_planner_no_incumbent"
                break
            selected = _visit_mask(model, primary.x)
            count = int(selected.sum())
            if primary.fun is None or abs(float(primary.fun) - count) > 1e-6:
                raise InitializationLimit("planner_visit_count_objective_mismatch")
            proven = primary.status == 0
            attempt.update(planned_visit_count=count, primary_count_proven_optimal=proven,
                           count_optimality_scope="current inventory/service relaxation with recorded heuristic pattern exclusions")
            if proven:
                secondary_model = build_visit_model(i, exclusions, fixed_visit_count=count)
                guard.check()
                lap = time.perf_counter()
                secondary_allowance = min(SECONDARY_CAP_SECONDS, .25 * guard.remaining())
                if secondary_allowance <= 0:
                    raise InitializationLimit("initialization_time_limit")
                secondary = _solve(secondary_model, secondary_model["holding_objective"],
                                   secondary_allowance)
                attempt["secondary"] = _solve_stats(secondary, time.perf_counter() - lap)
                guard.check()
                if secondary.x is not None:
                    secondary_selected = _visit_mask(secondary_model, secondary.x)
                    if int(secondary_selected.sum()) != count:
                        raise InitializationLimit("secondary_changed_primary_visit_count")
                    selected = secondary_selected
                else:
                    attempt["secondary"]["used_primary_schedule"] = True
            else:
                attempt["secondary"] = {"skipped": True, "reason": "primary_visit_count_not_proven_optimal"}
            attempt["lexicographic_planner_optimal"] = bool(proven and attempt["secondary"].get("status") == 0)
            route_stats, routes, failed_periods = [], [], []
            lap = time.perf_counter()
            for p in range(i.horizon):
                construction = construct_fifo_route(i, np.flatnonzero(selected[p]).tolist(),
                                                     net, guard, rng, route_starts)
                route_stats.append(construction)
                routes.append(construction["route"])
                if not construction["feasible"]:
                    failed_periods.append(p)
                    break
            attempt["routing_seconds"] = time.perf_counter() - lap
            attempt["route_construction"] = route_stats
            attempt["visits_per_period"] = selected.sum(axis=1).tolist()
            if failed_periods:
                p = failed_periods[0]
                exclusion = {"period": p, "selected": np.flatnonzero(selected[p]).tolist(),
                             "reason": "no FIFO-feasible order found by bounded insertion",
                             "scope": "heuristic membership exclusion, not a valid original-problem infeasibility cut"}
                exclusions.append(exclusion)
                attempt["outcome"] = "routing_failed_pattern_excluded"
                continue
            guard.check()
            lap = time.perf_counter()
            recovered = inventory_recourse(i, routes, time_limit=max(.001, guard.remaining()))
            attempt["recourse_seconds"] = time.perf_counter() - lap
            guard.check()
            if not recovered.get("success"):
                result["reason"] = "fixed_visit_recourse_failed"
                break
            lap = time.perf_counter()
            checked = verify_routes(i, routes, recovered["quantities"], "completion")
            attempt["verification_seconds"] = time.perf_counter() - lap
            guard.check(final=True)
            if not checked.get("checked"):
                result["reason"] = "literal_physical_verification_failed: " + checked.get("reason", "unknown")
                break
            components = plan_components(i, checked)
            attempt["outcome"] = "full_plan_verified"
            result.update(success=True, routes=checked["routes"], quantities=checked["quantities"],
                          verification=checked, objective=checked["objective_decimal"],
                          exact_feasible_objective=checked["exact_feasible_objective"],
                          stage_costs={"verified_full_plan": components},
                          lexicographic_planner_optimal=attempt["lexicographic_planner_optimal"],
                          primary_count_proven_optimal=proven,
                          planner_status_scope=attempt["count_optimality_scope"])
            break
        if not result["success"] and "reason" not in result:
            result["reason"] = "bounded_membership_attempts_exhausted"
        if result["success"]:
            guard.check(final=True)
    except InitializationLimit as error:
        result.update(success=False, reason=str(error))
    result.update(seconds=time.perf_counter() - started, observed_peak_resident_bytes=guard.peak_resident_bytes,
                  resource_scope="cooperative inner clock and sampled process RSS high-water checks; cold parent watchdog enforces hard cap")
    if not result["success"]:
        result["failure_scope"] = "no verified start produced under this policy/budget; not original-problem infeasibility"
    return result


def create_start(name, path, seconds=30., seed=DEFAULT_SEED, memory_limit_mib=1024,
                 max_patterns=8, route_starts=8):
    """Write a frozen_start-compatible complete record, or an explicit failure."""
    started = time.perf_counter()
    end = started + seconds
    instance = read_instance(name)
    value = build_consolidation_plan(instance, seconds=seconds, deadline=end - .10, seed=seed,
                                     memory_limit_mib=memory_limit_mib, max_patterns=max_patterns,
                                     route_starts=route_starts)
    record = {"input": name, "created_utc": datetime.now(timezone.utc).isoformat(),
              "input_sha256": input_hash(name), "contract": CONTRACT,
              "objective_definition": "completion", "initializer_seed": seed,
              "initializer_budget_seconds": seconds, "initializer": INITIALIZER,
              "success": value["success"], "consolidation_initialization": value}
    if value["success"]:
        record.update(routes=value["routes"], quantities=value["quantities"], objective=value["objective"],
                      exact_feasible_objective=value["exact_feasible_objective"],
                      plan_sha256=plan_hash(name, value["routes"], value["quantities"]),
                      initializer_route_dp_calls=0, initializer_joint_repairs=0,
                      stage_costs=value["stage_costs"])
        stock = np.r_[instance.supplier_initial, instance.initial].astype(int)
        inventory = [stock.tolist()]
        for p, quantity in enumerate(record["quantities"]):
            stock = stock.copy()
            stock[0] += int(instance.production[p]) - sum(quantity)
            stock[1:] += np.asarray(quantity, dtype=int) - instance.demand[p].astype(int)
            inventory.append(stock.tolist())
        record["inventory_including_initial_period"] = inventory
    else:
        record["failure_reason"] = value["reason"]
    record["offline_initialization_wall_seconds"] = time.perf_counter() - started
    record["initializer_parent_cumulative_peak_working_set_bytes"] = value["observed_peak_resident_bytes"]
    record["initialization_memory_scope"] = value["resource_scope"]
    if time.perf_counter() >= end:
        record["success"] = False
        record["failure_reason"] = "initialization_time_limit_before_record_publication"
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(target)
    return record
