"""Restricted BCHeu-inspired contiguous-cluster guidance, with true FIFO acceptance.

For each subset of the sampled block, an internal shortest Hamiltonian path is
inserted at its best consecutive outside-chain gap under directed static means.
Full proxy routes are evaluated; no triangle inequality or additive independent
move savings are assumed. The candidate family also retains an incumbent-profile
fallback. This is not the complete BCHeu cluster/removal MILP or its outer search.

The all-quantity master, original FIFO verification, strict true-cost acceptance,
block sampling and polishing are frozen V5 helpers. Proxy bounds never certify a
true FIFO conditional neighbourhood or the global problem. Hooks are process-local,
non-reentrant, and restored even on error; use one fresh sequential worker.
"""
from __future__ import annotations

from fractions import Fraction
import importlib.util
import math
from numbers import Integral
from pathlib import Path
import sys
import threading
import time

import numpy as np

BASE = Path(__file__).resolve().parent
for path in (BASE.parent / "tdirp_v3", BASE.parent / "tdirp_newalgo", BASE.parent / "tdirp_math_audit"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))
import joint_repair as _joint


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_static = _load("_tdirp_v8_static_clock", BASE.parent / "tdirp_v7/static_operators.py")
_v5 = _load("_tdirp_v8_cluster_v5", BASE.parent / "tdirp_v5/operators.py")
METHOD = "static_cluster_insertion_polish"
METHODS = (METHOD,)
LABEL = "restricted static contiguous-cluster insertion with incumbent-profile fallback"
SCOPE = (LABEL + "; BCHeu-inspired CSP mechanism only, not the full published algorithm; "
         "no true-FIFO conditional or global bound/certificate")
POLICY = _v5.POLICY
MAX_BLOCK = 10  # Same API safety cap as the frozen profile master.
_LOCK = threading.Lock()


class ProfileBudgetExceeded(TimeoutError):
    """A partial cluster profile must not reach the master as a complete table."""


class StaticClusterNetwork(_static.StaticAverageNetwork):
    """The V7 directed raw-bin mean clock, with exact scaled-integer CSP costs."""

    def __init__(self, instance):
        super().__init__(instance)
        service = np.asarray(instance.service)
        if service.shape != (instance.n,) or not np.isfinite(service).all() or np.any(service < 0):
            raise ValueError("Finite nonnegative customer service times required")
        rational_service = tuple(Fraction(str(value)) for value in service)
        self.scale = math.lcm(instance.steps, *(value.denominator for value in rational_service))
        # The reused network treats self arcs as zero, including the empty depot gap.
        self.arc_units = tuple(tuple(0 if a == b else int(self.mean_exact[a][b] * self.scale)
                                     for b in range(instance.n + 1))
                               for a in range(instance.n + 1))
        self.service_units = tuple(int(value * self.scale) for value in rational_service)

    def route_cost_units(self, route):
        value, previous = 0, 0
        for customer in route:
            value += self.arc_units[previous][customer + 1] + self.service_units[customer]
            previous = customer + 1
        return value + self.arc_units[previous][0] if route else 0

    def exact_route_completion(self, route):
        return Fraction(self.route_cost_units(route), self.scale)

    def metadata(self):
        return {**super().metadata(), "cluster_rule": "shortest internal Hamiltonian path; best outside-chain gap",
                "pool": "all subsets of the sampled block, not the published singleton/k-means pool",
                "route_family": "contiguous static cluster candidates plus incumbent-profile fallback",
                "cost_evaluation": "full static route including original service; no independent-savings sum",
                "internal_numeric_representation": "exact scaled integers", "integer_scale": self.scale,
                "triangle_inequality_assumed": False,
                "source_mechanism": "CSP and least-cost gap insertion (source Section 3.2.1, equations 30–31)",
                "omitted_source_components": "k-means pool, simultaneous-removal variables/compatibility master and published outer search"}


def _check_time(deadline):
    if deadline is not None and time.perf_counter() >= deadline:
        raise ProfileBudgetExceeded("cluster profile construction exhausted its allowance")


def _customers(values, n, name):
    answer = list(values)
    if any(not isinstance(value, Integral) or isinstance(value, bool) or not 0 <= value < n for value in answer):
        raise ValueError("Invalid " + name + " customer")
    answer = [int(value) for value in answer]
    if len(set(answer)) != len(answer):
        raise ValueError("Repeated " + name + " customer")
    return answer


def _internal_paths(entry, block, net, deadline, diagnostics):
    """All-subset Held–Karp paths from one fixed outside endpoint.

    State endpoints are selected block customers; outside customers can never be
    interleaved. Equal costs use lexicographic customer-order tie breaking.
    """
    width = len(block)
    count = 1 << width
    costs = [[None] * width for _ in range(count)]
    orders = [[None] * width for _ in range(count)]
    for mask in range(1, count):
        _check_time(deadline)
        for last in range(width):
            if not mask >> last & 1:
                continue
            customer = block[last]
            previous_mask = mask ^ (1 << last)
            if not previous_mask:
                best = (net.arc_units[entry][customer + 1] + net.service_units[customer], (customer,))
            else:
                candidates = []
                for previous in range(width):
                    if not previous_mask >> previous & 1:
                        continue
                    diagnostics["internal_dp_transitions"] += 1
                    value = costs[previous_mask][previous] + net.arc_units[block[previous] + 1][customer + 1]
                    candidates.append((value + net.service_units[customer], orders[previous_mask][previous] + (customer,)))
                best = min(candidates)
            costs[mask][last], orders[mask][last] = best
            diagnostics["internal_dp_states"] += 1
    return costs, orders


def _new_diagnostics():
    return {"calls": 0, "period_profile_calls": 0, "subset_profiles_generated": 0,
            "gap_candidates_evaluated": 0, "internal_dp_states": 0, "internal_dp_transitions": 0,
            "incumbent_profile_fallbacks": 0, "true_fifo_rejected_candidates": 0,
            "inventory_recourse_failures": 0, "no_proxy_feasible_profile_calls": 0,
            "no_verified_candidate_calls": 0, "verified_true_candidates": 0,
            "profile_budget_exhaustions": 0, "last_repair": None}


def cluster_profiles(instance, backbone, block, net=None, incumbent=None, deadline=None, diagnostics=None):
    """Return ``(proxy_values, routes)`` for all block masks; no LP/MIP call.

    Customer indices are zero based, and node 0 is the depot inside ``net``.
    Every nonempty mask is inserted contiguously in one consecutive backbone gap.
    When supplied, the original incumbent can replace its own membership mask if
    strictly cheaper. That declared exception may interleave block/outside nodes.
    Values are unrounded floats only at the frozen master interface; all route
    choices are made with exact scaled integers.
    """
    backbone = _customers(backbone, instance.n, "outside")
    block = _customers(block, instance.n, "block")
    if set(backbone).intersection(block):
        raise ValueError("Outside chain and block overlap")
    if len(block) > MAX_BLOCK:
        raise ValueError("Cluster block exceeds the frozen master's size cap")
    if deadline is not None and (not math.isfinite(deadline) or deadline < 0):
        raise ValueError("Finite nonnegative absolute deadline required")
    net = StaticClusterNetwork(instance) if net is None else net
    if not isinstance(net, StaticClusterNetwork) or net.inst is not instance:
        raise ValueError("StaticClusterNetwork must belong to this exact instance")
    diagnostics = _new_diagnostics() if diagnostics is None else diagnostics
    diagnostics["period_profile_calls"] += 1
    count = 1 << len(block)
    costs, routes = [None] * count, [None] * count
    base_cost = net.route_cost_units(backbone)
    costs[0], routes[0] = base_cost, list(backbone)
    for gap in range(len(backbone) + 1):
        _check_time(deadline)
        entry = 0 if gap == 0 else backbone[gap - 1] + 1
        exit_node = 0 if gap == len(backbone) else backbone[gap] + 1
        internal_costs, internal_orders = _internal_paths(entry, block, net, deadline, diagnostics)
        for mask in range(1, count):
            _check_time(deadline)
            path_cost, cluster = min((internal_costs[mask][last] + net.arc_units[block[last] + 1][exit_node],
                                      internal_orders[mask][last])
                                     for last in range(len(block)) if mask >> last & 1)
            candidate = backbone[:gap] + list(cluster) + backbone[gap:]
            value = net.route_cost_units(candidate)
            # Full-route evaluation is authoritative; this identity checks mapping.
            if value != base_cost + path_cost - net.arc_units[entry][exit_node]:
                raise RuntimeError("Full-route/CSP insertion cost identity failed")
            diagnostics["gap_candidates_evaluated"] += 1
            if costs[mask] is None or (value, tuple(candidate)) < (costs[mask], tuple(routes[mask])):
                costs[mask], routes[mask] = value, candidate
    diagnostics["subset_profiles_generated"] += count - 1
    if incumbent is not None:
        incumbent = _customers(incumbent, instance.n, "incumbent")
        positions = {customer: position for position, customer in enumerate(block)}
        if [customer for customer in incumbent if customer not in positions] != backbone:
            raise ValueError("Incumbent does not preserve the declared outside chain")
        mask = sum(1 << positions[customer] for customer in incumbent if customer in positions)
        value = net.route_cost_units(incumbent)
        if value < costs[mask]:
            costs[mask], routes[mask] = value, list(incumbent)
            diagnostics["incumbent_profile_fallbacks"] += 1
    values = np.asarray([float(Fraction(value, net.scale)) for value in costs])
    return values, routes


def _repair(instance, routes, block, time_limit, net, diagnostics):
    started = time.perf_counter()
    end = started + time_limit
    before = dict(diagnostics)
    observed = {"true_fifo_rejected_candidates": 0, "inventory_recourse_failures": 0}
    old_builder, old_verify, old_recourse = _joint.greedy_values, _joint.verify_routes, _joint.inventory_recourse
    old_finish = _joint.route_finish

    def build(i, outside, selected, proxy, incumbent=None):
        return cluster_profiles(i, outside, selected, net=proxy, incumbent=incumbent,
                                deadline=end, diagnostics=diagnostics)

    def verify(*args, **kwargs):
        checked = old_verify(*args, **kwargs)
        if not checked.get("checked"):
            observed["true_fifo_rejected_candidates"] += 1
            observed["true_rejection_reason"] = checked.get("reason")
        return checked

    def recourse(*args, **kwargs):
        answer = old_recourse(*args, **kwargs)
        observed["inventory_recourse_failures"] += not bool(answer.get("success"))
        return answer

    def proxy_finish(i, route, clock):
        # Use the same exact proxy valuation at the frozen containment/filter
        # boundary; the original FIFO verifier and V5 polishing are untouched.
        if isinstance(clock, StaticClusterNetwork):
            return float(clock.exact_route_completion(route))
        return old_finish(i, route, clock)

    _joint.greedy_values, _joint.verify_routes, _joint.inventory_recourse = build, verify, recourse
    _joint.route_finish = proxy_finish
    try:
        try:
            # Constructed-profile mode deliberately avoids the exact-interleaving
            # decoder's containment assertion and any exact-decoder claim.
            answer = _joint.profile_repair(instance, routes, block, time_limit=time_limit,
                                           objective="completion", decoder="greedy", net=net)
        except ProfileBudgetExceeded:
            diagnostics["profile_budget_exhaustions"] += 1
            answer = {"status": 1, "objective": None, "reason": "cluster_profile_build_budget",
                      "profile_seconds": time.perf_counter() - started}
    finally:
        _joint.greedy_values, _joint.verify_routes, _joint.inventory_recourse = old_builder, old_verify, old_recourse
        _joint.route_finish = old_finish
    answer = dict(answer)
    proxy_bound = answer.get("profile_master_lower_bound")
    answer.update(decoder="static_contiguous_cluster_insertion", scope=SCOPE,
                  profile_master_lower_bound=None, conditional_lower_bound=None,
                  profile_master_optimal=False, conditional_optimum_verified=False,
                  global_bound=None, global_gap=None, proxy_master_lower_bound=proxy_bound,
                  proxy_master_bound_scope="constructed static cluster/incumbent-profile master only; not a FIFO bound",
                  proxy_master_solve_status=answer.get("status"))
    if answer.get("reason") == "no feasible profile":
        answer["reason"] = "cluster_proxy_no_feasible_profile"
        diagnostics["no_proxy_feasible_profile_calls"] += 1
    if observed["true_fifo_rejected_candidates"]:
        answer["reason"] = "cluster_proxy_candidate_rejected_by_original_true_verifier"
    if observed["inventory_recourse_failures"] and not answer.get("reason"):
        answer["reason"] = "cluster_proxy_inventory_recourse_failed"
    diagnostics["calls"] += 1
    diagnostics["true_fifo_rejected_candidates"] += observed["true_fifo_rejected_candidates"]
    diagnostics["inventory_recourse_failures"] += observed["inventory_recourse_failures"]
    diagnostics["no_verified_candidate_calls"] += answer.get("objective") is None
    diagnostics["verified_true_candidates"] += answer.get("objective") is not None
    detail = {key: diagnostics[key] - before[key] for key in diagnostics if key != "last_repair"}
    detail.update(proxy_master_lower_bound=proxy_bound,
                  proxy_master_bound_scope=answer["proxy_master_bound_scope"],
                  proxy_master_solve_status=answer.get("status"), reason=answer.get("reason"),
                  candidate_family="contiguous static cluster candidates plus incumbent-profile fallback")
    if observed.get("true_rejection_reason"):
        detail["true_rejection_reason"] = observed["true_rejection_reason"]
    if answer.get("objective") is not None:
        checked = answer["independent_verification"]
        if not checked.get("checked"):
            raise RuntimeError("Cluster guidance returned an unverified true-model candidate")
        proxy = sum((net.exact_route_completion(route) for route in answer["routes"]), Fraction(0))
        proxy += Fraction(checked["holding_cost"])
        detail.update(proxy_evaluated_candidate_objective_exact=str(proxy),
                      proxy_evaluated_candidate_objective=float(proxy),
                      true_candidate_objective_exact=checked["exact_feasible_objective"],
                      true_candidate_objective=checked["objective_decimal"])
    answer["cluster_diagnostics"] = detail
    answer["wall_seconds"] = time.perf_counter() - started
    diagnostics["last_repair"] = detail
    return answer


def cluster_profile_repair(instance, routes, block, time_limit=1.5, static_net=None):
    """One raw all-quantity-free repair; true verified objective or explicit failure."""
    if not math.isfinite(time_limit) or time_limit <= 0:
        raise ValueError("Finite positive repair allowance required")
    if not _LOCK.acquire(blocking=False):
        raise RuntimeError("Cluster insertion requires a nonconcurrent fresh worker")
    try:
        net = StaticClusterNetwork(instance) if static_net is None else static_net
        if not isinstance(net, StaticClusterNetwork) or net.inst is not instance:
            raise ValueError("StaticClusterNetwork must belong to this exact instance")
        return _repair(instance, routes, block, time_limit, net, _new_diagnostics())
    finally:
        _LOCK.release()


raw_repair = cluster_profile_repair
profile_repair = cluster_profile_repair


def optimize(instance, initial, method=METHOD, seed=20261141, deadline=None, publish=None):
    """Frozen-V5-shaped interface; only raw profile construction is replaced."""
    if method != METHOD:
        raise ValueError("Unknown cluster-insertion method")
    if deadline is None or not math.isfinite(deadline):
        raise ValueError("Finite absolute parent-clock search deadline required")
    if not _LOCK.acquire(blocking=False):
        raise RuntimeError("Cluster insertion requires a nonconcurrent fresh worker")
    old_hook = _v5.profile_repair
    try:
        net, diagnostics = StaticClusterNetwork(instance), _new_diagnostics()

        def hook(i, routes, block, time_limit=1.5, objective="completion", decoder="dp", net=None, **kwargs):
            if objective != "completion" or decoder != "dp" or kwargs:
                raise ValueError("Cluster control supports only the shared all-quantity-free joint repair")
            return _repair(i, routes, block, time_limit, proxy, diagnostics)

        proxy = net

        def augment(record):
            output = dict(record)
            counters = dict(output.get("counters", {}))
            if counters.get("completed_raw_conditional_repairs", 0):
                raise RuntimeError("Cluster proxy leaked a true conditional certificate")
            counters.update({"cluster_" + key: value for key, value in diagnostics.items() if key != "last_repair"})
            counters["completed_raw_conditional_repairs"] = 0
            output.update(method=METHOD, method_label=LABEL, scope=SCOPE, counters=counters,
                          static_proxy_clock=proxy.metadata(), cluster_last_repair=diagnostics["last_repair"],
                          global_bound=None, global_gap=None, conditional_lower_bound=None,
                          conditional_optimum_verified=False)
            output["trace"] = [dict(row) for row in output.get("trace", [])]
            for row in output["trace"]:
                if "raw_local_bound" in row:
                    row["raw_local_bound"], row["raw_bound_scope"] = None, SCOPE
            return output

        def emit(record):
            if publish is not None:
                publish(augment(record))

        _v5.profile_repair = hook
        return augment(_v5.optimize(instance, initial, "joint_dp_polish", seed, deadline, publish=emit))
    finally:
        _v5.profile_repair = old_hook
        _LOCK.release()


def source_paths():
    return [Path(__file__), BASE.parent / "tdirp_v7/static_operators.py",
            BASE.parent / "tdirp_v5/operators.py", BASE.parent / "tdirp_v3/joint_repair.py",
            BASE.parent / "tdirp_newalgo/schedule_repair.py", BASE.parent / "tdirp_math_audit/root_lp_probe.py"]


def self_check():
    """Pure 2–4-customer enumeration checks, with no optimizer call or file write."""
    from itertools import permutations
    from types import SimpleNamespace

    tested = 0
    for n in (2, 3, 4):
        raw = np.zeros((n + 1, n + 1, 3), dtype=int)
        for a in range(n + 1):
            for b in range(n + 1):
                if a != b:
                    raw[a, b] = [1 + (7*a + 3*b) % 13, 2 + (2*a + 5*b) % 11, 1 + (3*a + b) % 7]
        instance = SimpleNamespace(n=n, steps=3, travel=raw, service=np.arange(n) + 1)
        net = StaticClusterNetwork(instance)
        for width in range(n + 1):
            block, outside = list(range(width)), list(range(width, n))
            values, routes = cluster_profiles(instance, outside, block, net)
            for mask in range(1 << width):
                selected = [block[j] for j in range(width) if mask >> j & 1]
                candidates = [outside[:gap] + list(order) + outside[gap:]
                              for gap in range(len(outside) + 1) for order in permutations(selected)]
                expected = min((net.exact_route_completion(route), tuple(route)) for route in candidates)
                assert net.exact_route_completion(routes[mask]) == expected[0]
                assert tuple(routes[mask]) == expected[1]
                assert values[mask] == float(expected[0])
                tested += 1
    raw = np.full((5, 5, 1), 10, dtype=int)
    for node in range(5):
        raw[node, node, 0] = 0
    for a, b in zip((0, 1, 2, 3, 4), (1, 2, 3, 4, 0)):
        raw[a, b, 0] = 1
    instance = SimpleNamespace(n=4, steps=1, travel=raw, service=np.zeros(4, dtype=int))
    net = StaticClusterNetwork(instance)
    values, routes = cluster_profiles(instance, [0, 2], [1, 3], net)
    interleaved = [0, 1, 2, 3]
    assert values[3] == 32 and net.exact_route_completion(interleaved) == 5
    diagnostics = _new_diagnostics()
    kept, _ = cluster_profiles(instance, [0, 2], [1, 3], net, incumbent=interleaved, diagnostics=diagnostics)
    assert kept[3] == 5 and diagnostics["incumbent_profile_fallbacks"] == 1
    return {"passed": True, "brute_force_profiles_checked": tested, "solver_called": False,
            "strict_interleaving_witness": {"contiguous_cost": 32, "interleaved_cost": 5},
            "incumbent_fallback_checked": True}


if __name__ == "__main__":
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if not args.self_test:
        parser.error("Use the optimize/profile API or explicitly request --self-test")
    print(json.dumps(self_check(), indent=2))
