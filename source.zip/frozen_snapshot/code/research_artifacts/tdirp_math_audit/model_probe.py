"""Bounded mathematical probes; not a reproduction of the article's solver.

Input: the author's unchanged public TDIRP archive.
Two explicitly distinguished candidate objectives are evaluated.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import itertools
import json
import time
import zipfile
import numpy as np
import scipy.sparse as sp
from scipy.optimize import Bounds, LinearConstraint, milp

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE.parent / "tdirp_check_2026-11-01" / "Benchmark.zip"

@dataclass
class Instance:
    name: str
    n: int
    horizon: int
    capacity: int
    steps: int
    step_seconds: int
    deadline: int
    supplier_initial: float
    production: np.ndarray
    supplier_holding: float
    initial: np.ndarray
    maximum: np.ndarray
    minimum: np.ndarray
    demand: np.ndarray
    holding: np.ndarray
    service: np.ndarray
    travel: np.ndarray

def read_instance(name: str) -> Instance:
    with zipfile.ZipFile(ARCHIVE) as z:
        rows = [line.split() for line in z.read(name).decode("utf-8-sig").splitlines() if line.strip()]
    nodes, horizon, capacity, steps, seconds, deadline = map(int, rows[0])
    sup = list(map(float, rows[1]))
    clients = np.array([list(map(float, r)) for r in rows[2:nodes + 1]])
    travel = np.array([list(map(float, r)) for r in rows[nodes + 1:]]).reshape(nodes, nodes, steps)
    return Instance(
        name, nodes-1, horizon, capacity, steps, seconds, deadline,
        sup[1], np.array(sup[2:2+horizon]), sup[-1],
        clients[:, 1], clients[:, 2], clients[:, 3],
        clients[:, 4:4+horizon].T, clients[:, -2], clients[:, -1], travel
    )

def static_subset_values(inst: Instance):
    """Exact on static first-bin arcs. Public case is locked to deadline < first breakpoint."""
    if not inst.deadline < inst.step_seconds:
        raise ValueError("This probe requires deadline < first time breakpoint.")
    n = inst.n
    a = inst.travel[:, :, 0]
    count = 1 << n
    dep = np.full((count, n), np.inf)
    parent = np.full((count, n), -1, dtype=np.int16)
    finish = np.full(count, np.inf)
    finish[0] = 0.
    for mask in range(1, count):
        for j in range(n):
            if not mask >> j & 1:
                continue
            prev = mask ^ (1 << j)
            if prev == 0:
                dep[mask,j] = a[0,j+1] + inst.service[j]
            else:
                candidates = dep[prev,:] + a[1:,j+1]
                k = int(np.argmin(candidates))
                dep[mask,j] = candidates[k] + inst.service[j]
                parent[mask,j] = k
        finish[mask] = float(np.min(dep[mask,:] + a[1:,0]))
    return finish, dep, parent

def exhaustive_static_values(inst: Instance):
    n = inst.n
    a = inst.travel[:,:,0]
    out = np.zeros(1 << n)
    for mask in range(1,1<<n):
        vertices = [i for i in range(n) if mask >> i & 1]
        best = np.inf
        for order in itertools.permutations(vertices):
            t = 0.; last = 0
            for v in order:
                t += a[last,v+1] + inst.service[v]
                last = v+1
            best = min(best,t+a[last,0])
        out[mask] = best
    return out

def pattern_master(inst: Instance, finish: np.ndarray, objective: str, time_limit=30., policy="ML", branch_on_visits=False, absolute_deadline=None, solver_options=None):
    """Exact complete-pattern master for the stated candidate model only."""
    if objective not in {"completion","travel"}:
        raise ValueError(objective)
    n,H = inst.n,inst.horizon
    masks = [s for s,r in enumerate(finish) if r <= inst.deadline]
    incidence = np.array([[(s>>i)&1 for i in range(n)] for s in masks],dtype=float)
    routes = len(masks)
    nx = H*routes; ny=H*n if branch_on_visits else 0
    nq=H*n; ni=H*(n+1); size=nx+ny+nq+ni
    yidx=lambda p,i:nx+p*n+i
    qidx=lambda p,i:nx+ny+p*n+i
    iidx=lambda p,i:nx+ny+nq+p*(n+1)+i
    cost=np.zeros(size)
    route_cost = finish[masks].copy()
    if objective=="travel":
        route_cost -= incidence@inst.service
    cost[:nx] = np.tile(route_cost,H)
    for p in range(H):
        cost[iidx(p,0)] = inst.supplier_holding
        for i in range(n):
            cost[iidx(p,i+1)] = inst.holding[i]
    lb=np.zeros(size); ub=np.full(size,np.inf); ub[:nx]=1.
    integer=np.zeros(size,dtype=np.int32)
    if branch_on_visits:
        integer[nx:nx+ny]=1;ub[nx:nx+ny]=1.
    else:integer[:nx]=1
    rr=[];cc=[];vv=[];lower=[];upper=[]
    def add(coeff,lo,hi):
        row=len(lower)
        for col,val in coeff.items():
            if val:
                rr.append(row);cc.append(col);vv.append(val)
        lower.append(lo);upper.append(hi)
    for p in range(H):
        add({p*routes+k:1. for k in range(routes)},1.,1.)
        c={iidx(p,0):1.}
        c.update({qidx(p,i):1. for i in range(n)})
        if p: c[iidx(p-1,0)]=-1.
        rhs=inst.production[p]+(inst.supplier_initial if p==0 else 0.)
        add(c,rhs,rhs)
        add({qidx(p,i):1. for i in range(n)},-np.inf,inst.capacity)
        for i in range(n):
            if branch_on_visits:
                c={yidx(p,i):1.}
                c.update({p*routes+k:-incidence[k,i] for k in range(routes) if incidence[k,i]})
                add(c,0.,0.)
            c={iidx(p,i+1):1.,qidx(p,i):-1.}
            if p:c[iidx(p-1,i+1)]=-1.
            rhs=-inst.demand[p,i]+(inst.initial[i] if p==0 else 0.)
            add(c,rhs,rhs)
            c={qidx(p,i):1.}
            if p:c[iidx(p-1,i+1)]=1.
            add(c,-np.inf,inst.maximum[i]-(inst.initial[i] if p==0 else 0.))
            c={qidx(p,i):1.}
            if branch_on_visits:c[yidx(p,i)]=-inst.maximum[i]
            else:c.update({p*routes+k:-inst.maximum[i]*incidence[k,i] for k in range(routes) if incidence[k,i]})
            add(c,-np.inf,0.)
            if policy=="OU":
                c={qidx(p,i):1.}
                if p:c[iidx(p-1,i+1)]=1.
                c.update({p*routes+k:-inst.maximum[i]*incidence[k,i] for k in range(routes) if incidence[k,i]})
                add(c,-inst.initial[i] if p==0 else 0.,np.inf)
            elif policy!="ML":raise ValueError(policy)
            lb[iidx(p,i+1)]=inst.minimum[i]
    matrix=sp.coo_matrix((vv,(rr,cc)),shape=(len(lower),size)).tocsc()
    started=time.perf_counter()
    allowed_seconds=time_limit if absolute_deadline is None else min(time_limit,max(0.,absolute_deadline-started))
    if allowed_seconds<=0:
        return {"input":inst.name,"objective_definition":objective,"status":1,
                "message":"Whole-model budget exhausted during master construction",
                "objective":None,"lower_bound":0.,"mip_gap":None,"route_patterns":routes,"variables":size}
    options={"time_limit":allowed_seconds,"mip_rel_gap":0.}
    if solver_options:options.update(solver_options)
    result=milp(cost,integrality=integer,bounds=Bounds(lb,ub),
        constraints=LinearConstraint(matrix,np.array(lower),np.array(upper)),
        options=options)
    ans={"input":inst.name,"objective_definition":objective,"policy":policy,"branch_on_visits":branch_on_visits,
         "binary_variables":int(integer.sum()),"status":int(result.status),
         "message":result.message,"elapsed_seconds":time.perf_counter()-started,
         "route_patterns":routes,"variables":size,
         "objective":float(result.fun) if result.fun is not None else None,
         "lower_bound":float(result.mip_dual_bound) if getattr(result,"mip_dual_bound",None) is not None else None,
         "mip_gap":float(result.mip_gap) if getattr(result,"mip_gap",None) is not None else None}
    if result.x is not None:
        x=result.x
        selected=[masks[int(np.argmax(x[p*routes:(p+1)*routes]))] for p in range(H)]
        ans["sets"]=[[i+1 for i in range(n) if s>>i&1] for s in selected]
        ans["quantities"]=[[float(x[qidx(p,i)]) for i in range(n)] for p in range(H)]
        ans["inventory"]=[[float(x[iidx(p,i)]) for i in range(n+1)] for p in range(H)]
        ans["routing_cost"]=float(sum(route_cost[masks.index(s)] for s in selected))
        ans["holding_cost"]=float(cost[nx:]@x[nx:])
        residual=matrix@x
        violation=max(float(np.max(np.maximum(np.array(lower)-residual,0.))),
                      float(np.max(np.maximum(residual-np.array(upper),0.))),
                      float(np.max(np.maximum(lb-x,0.))),
                      float(np.max(np.maximum(x-ub,0.))))
        ans["max_linear_violation"]=violation
    return ans

def main():
    cases=["H3/inst_5_12_1.txt","H6/inst_5_12_1.txt"]
    results=[]
    for name in cases:
        inst=read_instance(name)
        finish,_,_=static_subset_values(inst)
        enumeration=exhaustive_static_values(inst)
        deviation=float(np.max(np.abs(finish-enumeration)))
        print(json.dumps({"input":name,"dp_vs_enumeration_max_error":deviation,"deadline":inst.deadline,"first_breakpoint":inst.step_seconds}),flush=True)
        assert deviation==0.
        for objective in ("completion","travel"):
            row=pattern_master(inst,finish,objective)
            row["dp_vs_enumeration_max_error"]=deviation
            results.append(row)
            print(json.dumps(row),flush=True)
    HERE.mkdir(parents=True,exist_ok=True)
    (HERE/"static_first_bin_probe.json").write_text(json.dumps(results,indent=2),encoding="utf-8")

if __name__=="__main__":main()

