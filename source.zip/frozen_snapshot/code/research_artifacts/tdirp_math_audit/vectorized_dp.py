"""Vectorized implementation of the same exact FIFO subset recurrence.

No change to the model, FIFO function, or feasible mask set.
"""
from pathlib import Path
import json,time
import numpy as np
from fifo_probe import FifoNetwork,read_instance,dynamic_values

BASE=Path(__file__).resolve().parent

def vector_arrival(inst,net,a,b,times):
    finite=np.isfinite(times)
    safe=np.where(finite,times,0.)
    m=(safe//inst.step_seconds).astype(np.int64)
    valid=finite&(m>=0)&(m<inst.steps)
    bounded=np.clip(m,0,inst.steps-1)
    vals=np.minimum(safe+inst.travel[a,b,bounded],net.suffix[a,b,bounded+1])
    return np.where(valid,vals,np.inf)

def fast_values(inst):
    n=inst.n;count=1<<n
    estimate=count*n*9+count*24
    if n>24 or estimate>512*1024**2:
        raise MemoryError("This research implementation caps estimated DP allocation at 512 MiB")
    net=FifoNetwork(inst)
    masks=np.arange(count,dtype=np.uint32)
    counts=np.bitwise_count(masks)
    layers=[masks[counts==k] for k in range(n+1)]
    dep=np.full((count,n),np.inf)
    parent=np.full((count,n),-1,dtype=np.int8)
    for j in range(n):dep[1<<j,j]=net.arrival(0,j+1,0.)+inst.service[j]
    for size in range(2,n+1):
        layer=layers[size]
        for j in range(n):
            current=layer[(layer&(1<<j))!=0]
            previous=current^(1<<j)
            best=np.full(len(current),np.inf)
            pred=np.full(len(current),-1,dtype=np.int8)
            for k in range(n):
                if k==j:continue
                positions=np.flatnonzero((previous&(1<<k))!=0)
                candidate=vector_arrival(inst,net,k+1,j+1,dep[previous[positions],k])+inst.service[j]
                improve=candidate<best[positions]
                indices=positions[improve]
                best[indices]=candidate[improve];pred[indices]=k
            dep[current,j]=best;parent[current,j]=pred
    finish=np.full(count,np.inf);finish[0]=0.
    last=np.full(count,-1,dtype=np.int8)
    for j in range(n):
        candidate=vector_arrival(inst,net,j+1,0,dep[:,j])
        improve=candidate<finish
        finish[improve]=candidate[improve];last[improve]=j
    return finish,dep,parent,last

def main():
    rows=[]
    for name in ["H3/inst_5_120_1.txt","H3/inst_10_120_1.txt","H3/inst_15_120_1.txt"]:
        i=read_instance(name);start=time.perf_counter();fast=fast_values(i);secs=time.perf_counter()-start
        slow=dynamic_values(i)
        row={"input":name,"return_values_identical":bool(np.array_equal(fast[0],slow[0])),
             "departure_labels_identical":bool(np.array_equal(fast[1],slow[1])),
             "predecessors_identical":bool(np.array_equal(fast[2],slow[2])),
             "last_nodes_identical":bool(np.array_equal(fast[3],slow[3])),
             "fast_seconds":secs,"patterns":len(fast[0])}
        assert all(row[k] for k in ["return_values_identical","departure_labels_identical","predecessors_identical","last_nodes_identical"])
        rows.append(row);print(json.dumps(row),flush=True)
        del fast,slow
    (BASE/"vectorized_dp_validation.json").write_text(json.dumps(rows,indent=2),encoding="utf-8")
if __name__=="__main__":main()

