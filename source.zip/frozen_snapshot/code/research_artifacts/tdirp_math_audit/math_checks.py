"""Finite, reproducible checks of the proposed mathematics.

These are mathematical sanity checks, not article reproduction or performance benchmarks.
"""
from __future__ import annotations
import itertools,json,heapq
from pathlib import Path
import numpy as np
from scipy.optimize import linprog

BASE=Path(__file__).resolve().parent

def subset_dp(n,arrival,service):
    d=np.full((1<<n,n),np.inf);r=np.full(1<<n,np.inf);r[0]=0.
    for mask in range(1,1<<n):
        for j in range(n):
            if not (mask>>j&1):continue
            prev=mask^(1<<j)
            if not prev:d[mask,j]=arrival(0,j+1,0.)+service[j]
            else:
                d[mask,j]=min(arrival(i+1,j+1,d[prev,i]) for i in range(n) if prev>>i&1)+service[j]
        r[mask]=min(arrival(j+1,0,d[mask,j]) for j in range(n) if mask>>j&1)
    return r

def enumerated(n,arrival,service):
    out=np.zeros(1<<n)
    for mask in range(1,1<<n):
        best=np.inf
        for order in itertools.permutations(i for i in range(n) if mask>>i&1):
            t=0.;last=0
            for j in order:t=arrival(last,j+1,t)+service[j];last=j+1
            best=min(best,arrival(last,0,t))
        out[mask]=best
    return out

def closure_arrival(nodes,arrival):
    def closed(source,target,t):
        if source==target:return t
        labels=[float("inf")]*nodes;labels[source]=t;queue=[(t,source)]
        while queue:
            now,i=heapq.heappop(queue)
            if now!=labels[i]:continue
            if i==target:return now
            for j in range(nodes):
                if i==j:continue
                val=arrival(i,j,now)
                if val<labels[j]:labels[j]=val;heapq.heappush(queue,(val,j))
        return labels[target]
    return closed

def quantity_epigraph(values,U,Q,y,q=None):
    k=len(U);masks=list(range(1<<k));count=len(masks)
    inc=np.array([[(m>>i)&1 for i in range(k)] for m in masks],dtype=float)
    if q is None:
        obj=np.array(values)
        eq=np.vstack([np.ones(count),inc.T])
        res=linprog(obj,A_eq=eq,b_eq=np.r_[1.,y],bounds=(0.,None),method="highs")
        return res
    allocations=[(m,i) for m in masks for i in range(k) if m>>i&1]
    slots={item:count+j for j,item in enumerate(allocations)}
    size=count+len(allocations);cost=np.zeros(size);cost[:count]=values
    eq=np.zeros((1+2*k,size));rhs=np.r_[1.,y,q]
    eq[0,:count]=1.;eq[1:1+k,:count]=inc.T
    for (m,i),col in slots.items():eq[1+k+i,col]=1.
    ub=[];bu=[]
    for (m,i),col in slots.items():
        row=np.zeros(size);row[col]=1.;row[m]=-U[i];ub.append(row);bu.append(0.)
    for m in masks:
        row=np.zeros(size);row[m]=-Q
        for i in range(k):
            if m>>i&1:row[slots[m,i]]=1.
        ub.append(row);bu.append(0.)
    return linprog(cost,A_ub=np.array(ub),b_ub=np.array(bu),
                   A_eq=eq,b_eq=rhs,bounds=(0.,None),method="highs")

def continuous_knapsack(mask,gamma,U,Q):
    remaining=Q;val=0.
    for i in sorted((i for i in range(len(U)) if mask>>i&1),key=lambda i:gamma[i],reverse=True):
        if gamma[i]<=0:break
        take=min(remaining,U[i]);val+=gamma[i]*take;remaining-=take
        if remaining<=0:break
    return val

def main():
    out={}
    # FIFO does not imply monotonicity under arbitrary nonmetric input.
    mat=np.array([[0.,10.,1.],[10.,0.,1.],[1.,1.,0.]])
    r=subset_dp(2,lambda i,j,t:t+mat[i,j],[1.,1.])
    out["nonmetric_fifo_counterexample"]={"R_A":r[1],"R_AB":r[3],
        "invalid_subset_cut_at_AB":r[1],"actual_AB":r[3]}
    assert r[1]==21. and r[3]==14.
    # Even a FIFO temporal metric can have nonmonotone travel-only cost:
    # extra service delays a return arc inside its flat arrival segment.
    def flat_return(i,j,t):
        if i==j:return t
        if j==0:return max(t+1.,20.)
        return t+1.
    r=subset_dp(2,flat_return,[1.,1.])
    out["travel_only_counterexample"]={"completion_A":r[1],"completion_AB":r[3],
        "travel_A":r[1]-1.,"travel_AB":r[3]-2.}
    assert r[1]==r[3]==20. and r[3]-2.<r[1]-1.
    # Same inventory constraints, different objective definitions, different visit plans.
    out["inventory_objective_counterexample"]={
        "data":{"demand":[1,1],"initial":0,"maximum":2,"capacity":2,"holding":3,
                "travel_per_visit":1,"service_per_visit":4},
        "travel_objective":{"batch_once":4,"split_twice":2,"optimum":"split_twice"},
        "completion_objective":{"batch_once":8,"split_twice":10,"optimum":"batch_once"}}
    # Smallest strict example for delivery-quantity-aware perspective strengthening.
    values=np.array([0.,1.,1.,1.5])
    visit=quantity_epigraph(values,[1.,1.],1.,[.5,.5])
    joint=quantity_epigraph(values,[1.,1.],1.,[.5,.5],[.5,.5])
    assert visit.success and joint.success
    pi=joint.eqlin.marginals;a=float(pi[0]);beta=pi[1:3];gamma=pi[3:5]
    mask_residuals=[a+sum(beta[i] for i in range(2) if m>>i&1)
                    +continuous_knapsack(m,gamma,[1.,1.],1.)-values[m] for m in range(4)]
    out["quantity_strengthening"]={"visit_only_bound":float(visit.fun),
        "joint_visit_quantity_bound":float(joint.fun),
        "dual_cut":{"constant":a,"visit_coefficients":beta.tolist(),"quantity_coefficients":gamma.tolist()},
        "maximum_dual_constraint_violation":float(max(mask_residuals))}
    assert abs(visit.fun-.75)<1e-10 and abs(joint.fun-1.)<1e-10
    assert max(mask_residuals)<1e-9

    rng=np.random.default_rng(20261102)
    dp_errors=[];projection_slacks=[];cut_slacks=[];dual_residuals=[]
    feasible_joint_samples=0
    for repeat in range(12):
        n=5;nodes=n+1
        floor=rng.integers(1,8,size=(nodes,nodes)).astype(float)
        intercept=rng.integers(5,25,size=(nodes,nodes)).astype(float)
        # A(t)=max(t+floor, intercept+0.5*t), FIFO and nonnegative.
        def arrival(i,j,t):
            return t if i==j else max(t+floor[i,j],intercept[i,j]+.5*t)
        service=rng.integers(1,4,size=n).astype(float)
        exact=subset_dp(n,arrival,service)
        brute=enumerated(n,arrival,service)
        dp_errors.append(float(np.max(np.abs(exact-brute))))
        close=closure_arrival(nodes,arrival)
        B=[0,1,2];k=len(B)
        block=subset_dp(k,lambda i,j,t:close(0 if i==0 else B[i-1]+1,
                                          0 if j==0 else B[j-1]+1,t),service[B])
        for S in range(1<<n):
            T=sum(1<<b for b,i in enumerate(B) if S>>i&1)
            projection_slacks.append(float(exact[S]-block[T]))
        # Obtain a feasible fractional marginal point by mixing feasible integer masks
        # and their deliveries, then separate a capacity-aware affine cut.
        U=np.array([2.,3.,2.]);Q=4.
        lam=rng.random(1<<k);lam/=lam.sum()
        inc=np.array([[(m>>i)&1 for i in range(k)] for m in range(1<<k)])
        quantities=np.zeros((1<<k,k))
        for m in range(1<<k):
            raw=rng.random(k)*U*inc[m]
            if raw.sum()>Q:raw*=Q/raw.sum()
            quantities[m]=raw
        y=lam@inc;q=lam@quantities
        z=quantity_epigraph(block,U,Q,y,q)
        assert z.success
        feasible_joint_samples+=1
        pi=z.eqlin.marginals;a=float(pi[0]);beta=pi[1:1+k];gamma=pi[1+k:]
        for T in range(1<<k):
            lhs=a+sum(beta[i] for i in range(k) if T>>i&1)+continuous_knapsack(T,gamma,U,Q)
            dual_residuals.append(float(lhs-block[T]))
        for S in range(1<<n):
            T=sum(1<<b for b,i in enumerate(B) if S>>i&1)
            for trial in range(3):
                qB=rng.random(k)*U*np.array([(T>>i)&1 for i in range(k)])
                if qB.sum()>Q:qB*=Q/qB.sum()
                rhs=a+sum(beta[i] for i in range(k) if T>>i&1)+float(gamma@qB)
                cut_slacks.append(float(exact[S]-rhs))
    out["randomized_checks"]={"seed":20261102,"networks":12,"customers_per_network":5,
        "full_subset_dp_vs_permutation_max_error":max(dp_errors),
        "projection_inequalities_checked":len(projection_slacks),
        "minimum_projection_slack":min(projection_slacks),
        "affine_cuts_separated":feasible_joint_samples,
        "affine_cut_evaluations":len(cut_slacks),"minimum_affine_cut_slack":min(cut_slacks),
        "maximum_dual_constraint_violation":max(dual_residuals)}
    assert max(dp_errors)<1e-9 and min(projection_slacks)>-1e-9
    assert min(cut_slacks)>-1e-9 and max(dual_residuals)<1e-9
    (BASE/"math_checks.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(json.dumps(out,indent=2))

if __name__=="__main__":main()

