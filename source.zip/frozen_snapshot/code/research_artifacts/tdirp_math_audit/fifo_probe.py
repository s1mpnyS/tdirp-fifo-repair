"""Paper Algorithm-1 FIFO and complete-pattern checks on public small instances.

Reference conventions: 0-based time bins, depot departure/service 0, c=1,
end-period holding costs, header duration bound, and maximum-level inventory.
The published result tables are NOT claimed reproduced by this script.
"""
from __future__ import annotations
from fractions import Fraction
import itertools,json,math,time
from pathlib import Path
import numpy as np
from model_probe import read_instance,pattern_master

BASE=Path(__file__).resolve().parent

class FifoNetwork:
    def __init__(self,inst):
        self.inst=inst
        nodes=inst.n+1;M=inst.steps
        drops=np.full((nodes,nodes,M+1),np.inf)
        for m in range(1,M):
            b=m*inst.step_seconds+inst.travel[:,:,m]
            drops[:,:,m]=np.where(inst.travel[:,:,m-1]>inst.travel[:,:,m],b,np.inf)
        self.suffix=np.minimum.accumulate(drops[:,:,::-1],axis=2)[:,:,::-1]
    def arrival(self,i,j,t):
        if math.isinf(t):return np.inf
        if i==j:return t
        m=int(t//self.inst.step_seconds)
        if m<0 or m>=self.inst.steps:return np.inf
        return min(t+self.inst.travel[i,j,m],self.suffix[i,j,m+1])

def direct_arrival(inst,i,j,t):
    """Independent literal evaluation of active ramps in Algorithm 1."""
    if math.isinf(t):return float("inf")
    if i==j:return t
    m=int(t//inst.step_seconds)
    if m<0 or m>=inst.steps:return float("inf")
    val=t+inst.travel[i,j,m]
    for r in range(1,inst.steps):
        if inst.travel[i,j,r-1]>inst.travel[i,j,r] and t<r*inst.step_seconds:
            val=min(val,r*inst.step_seconds+inst.travel[i,j,r])
    return val

def dynamic_values(inst):
    n=inst.n;a=FifoNetwork(inst)
    d=np.full((1<<n,n),np.inf);parent=np.full((1<<n,n),-1,dtype=np.int16)
    r=np.full(1<<n,np.inf);last=np.full(1<<n,-1,dtype=np.int16);r[0]=0.
    for mask in range(1,1<<n):
        for j in range(n):
            if not mask>>j&1:continue
            prev=mask^(1<<j)
            if prev==0:d[mask,j]=a.arrival(0,j+1,0.)+inst.service[j]
            else:
                choices=[(a.arrival(i+1,j+1,d[prev,i]),i) for i in range(n) if prev>>i&1]
                val,i=min(choices);d[mask,j]=val+inst.service[j];parent[mask,j]=i
        choices=[(a.arrival(j+1,0,d[mask,j]),j) for j in range(n) if mask>>j&1]
        r[mask],last[mask]=min(choices)
    return r,d,parent,last

def reconstruct(mask,parent,last):
    order=[];j=int(last[mask])
    while mask:
        order.append(j);nxt=int(parent[mask,j]);mask^=1<<j;j=nxt
    return list(reversed(order))

def verify_plan(inst,row,parent,last):
    if row["status"] not in (0,1) or row.get("sets") is None:return {"checked":False}
    # Integral min-cost-flow replenishment is available for fixed visit sets;
    # only certify a rounded plan if every exact inequality below passes.
    raw=np.array(row["quantities"])
    if np.max(np.abs(raw-np.rint(raw)))>1e-6:return {"checked":False,"reason":"nonintegral solver plan"}
    deliveries=np.rint(raw).astype(int)
    inv=np.rint(inst.initial).astype(int);sup=int(inst.supplier_initial)
    route_cost=0;holding=Fraction(0);routes=[];departures=[];returns=[]
    for p,visits in enumerate(row["sets"]):
        mask=sum(1<<(i-1) for i in visits);order=reconstruct(mask,parent,last)
        assert set(order)=={i-1 for i in visits}
        q=deliveries[p]
        assert np.all(q>=0) and int(q.sum())<=inst.capacity
        assert all(q[i]==0 or i+1 in visits for i in range(inst.n))
        assert np.all(inv+q<=inst.maximum)
        assert np.all(inv+q-inst.demand[p]>=inst.minimum)
        sup+=int(inst.production[p])-int(q.sum());assert sup>=0
        inv=inv+q-inst.demand[p].astype(int)
        now=0.;old=0;tr=0.;times=[]
        for i in order:
            times.append(int(now))
            arr=direct_arrival(inst,old,i+1,now);tr+=arr-now
            now=arr+inst.service[i];old=i+1
        arr=direct_arrival(inst,old,0,now) if order else 0.
        tr+=arr-now if order else 0.
        assert arr<=inst.deadline
        assert tr==int(tr) and arr==int(arr)
        route_cost+=int(tr if row["objective_definition"]=="travel" else arr)
        holding+=Fraction(str(inst.supplier_holding))*sup
        holding+=sum(Fraction(str(inst.holding[i]))*int(inv[i]) for i in range(inst.n))
        routes.append([0]+[i+1 for i in order]+[0]);departures.append(times);returns.append(int(arr))
    total=Fraction(route_cost)+holding
    return {"checked":True,"exact_integer_inventory_and_capacity_check":True,
        "exact_feasible_objective":str(total),"objective_decimal":float(total),
        "objective_difference_from_solver":float(total)-row["objective"],
        "routes":routes,"departure_times":departures,"return_times":returns}

def main():
    output=[]
    for H in (3,6):
        for M in (12,30,60,120):
            inst=read_instance(f"H{H}/inst_5_{M}_1.txt")
            started=time.perf_counter();r,d,parent,last=dynamic_values(inst)
            elapsed=time.perf_counter()-started
            brute=np.zeros(1<<inst.n)
            for mask in range(1,1<<inst.n):
                best=np.inf
                for order in itertools.permutations(i for i in range(inst.n) if mask>>i&1):
                    now=0.;old=0
                    for i in order:now=direct_arrival(inst,old,i+1,now)+inst.service[i];old=i+1
                    best=min(best,direct_arrival(inst,old,0,now))
                brute[mask]=best
            error=float(np.max(np.abs(r-brute)))
            assert error==0. and np.all(d[np.isfinite(d)]==np.rint(d[np.isfinite(d)]))
            for objective in ("travel","completion"):
                row=pattern_master(inst,r,objective)
                row["dp_seconds"]=elapsed;row["dp_vs_enumeration_max_error"]=error
                row["reference_conventions"]={"c":1,"time_bins":"0-based","depot_service":0,
                    "deadline":"input header","inventory":"maximum-level; holding at period end"}
                row["independent_plan_verification"]=verify_plan(inst,row,parent,last)
                output.append(row)
                print(json.dumps({k:row[k] for k in ["input","objective_definition","objective","status","dp_vs_enumeration_max_error"]}),flush=True)
    (BASE/"fifo_public_small_probe.json").write_text(json.dumps(output,indent=2),encoding="utf-8")

if __name__=="__main__":main()

