"""Bounded full-mask root pricing and a restricted-pool primal pilot.

The restricted integer solution is an upper bound only. No n=20 integer
optimality or comparison against published result tables is claimed.
"""
from pathlib import Path
import json,time,ctypes
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from root_lp_probe import base_model
from fifo_probe import read_instance,verify_plan
from vectorized_dp import fast_values

BASE=Path(__file__).resolve().parent


def subset_sums(values):
    out=np.zeros(1<<len(values))
    for k,value in enumerate(values):
        length=1<<k
        out[length:2*length]=out[:length]+value
    return out


def build_master(i,g,pools):
    lp,y,q,inv,z=base_model(i)
    zset=set(z)
    keep=[j for j,row in enumerate(lp.ub) if not zset.intersection(row)]
    lp.ub=[lp.ub[j] for j in keep];lp.ubrhs=[lp.ubrhs[j] for j in keep]
    for v in z:lp.c[v]=0.
    convex=[];marginal=[]
    for p in range(i.horizon):
        columns={S:lp.var(c=float(g[S])) for S in sorted(pools[p])}
        convex.append(len(lp.eq));lp.equality({v:1. for v in columns.values()},1.)
        rows=[]
        for k in range(i.n):
            rows.append(len(lp.eq));row={y[p][k]:-1.}
            row.update({v:1. for S,v in columns.items() if S>>k&1})
            lp.equality(row,0.)
        marginal.append(rows)
    return lp,y,q,inv,convex,marginal


def peak_working_set_bytes():
    # Windows process counter; report actual process high-water mark separately
    # from array storage. This is not a portable resource benchmark.
    from ctypes import wintypes
    class Counters(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),
                  ('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),
                  ('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),
                  ('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),
                  ('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
    c=Counters();c.cb=ctypes.sizeof(c)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetCurrentProcess.restype=wintypes.HANDLE
    psapi=ctypes.WinDLL('psapi',use_last_error=True)
    psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(),ctypes.byref(c),c.cb):
        return None
    return int(c.PeakWorkingSetSize)


def run(name='H3/inst_20_120_1.txt',budget=180.,max_rounds=100):
    started=time.perf_counter();i=read_instance(name)
    R,dep,parent,last=fast_values(i)
    allocated=int(R.nbytes+dep.nbytes+parent.nbytes+last.nbytes)
    dp_seconds=time.perf_counter()-started
    del dep
    g=R-subset_sums(i.service);feasible=R<=i.deadline
    full=(1<<i.n)-1
    if not feasible[full]:raise RuntimeError('This root pilot needs a feasible full-set seed')
    pools=[{0,full} for _ in range(i.horizon)]
    trace=[];converged=False
    print(json.dumps({'stage':'dp_complete','input':name,'seconds':dp_seconds,
                      'patterns':len(R),'feasible_patterns':int(feasible.sum()),
                      'dp_return_array_bytes':allocated}),flush=True)
    for iteration in range(max_rounds):
        if time.perf_counter()-started>=budget:break
        lap=time.perf_counter()
        lp,y,q,inv,cr,mr=build_master(i,g,pools)
        r,solver_seconds=lp.solve()
        if not r.success:raise RuntimeError('Root pool infeasible; phase-I required: '+r.message)
        pricing_started=time.perf_counter();minima=[];added=[]
        for p in range(i.horizon):
            pi=np.array(r.eqlin.marginals[mr[p]])
            reduced=g-float(r.eqlin.marginals[cr[p]])-subset_sums(pi)
            reduced[~feasible]=np.inf;minima.append(float(np.min(reduced)))
            reduced[np.fromiter(pools[p],dtype=np.int64)]=np.inf
            k=min(10,len(reduced))
            candidates=np.argpartition(reduced,k-1)[:k]
            candidates=candidates[np.argsort(reduced[candidates],kind='stable')]
            added.append([int(S) for S in candidates if reduced[S]<-1e-8])
        corrected=float(r.fun+sum(min(0.,v) for v in minima))
        row={'iteration':iteration,'restricted_lp':float(r.fun),
             'pricing_corrected_lower_bound':corrected,'minimum_reduced_costs':minima,
             'pool_sizes':[len(s) for s in pools],'lp_solver_seconds':solver_seconds,
             'pricing_seconds':time.perf_counter()-pricing_started,
             'round_wall_seconds':time.perf_counter()-lap}
        trace.append(row)
        if iteration%5==0:print(json.dumps(row),flush=True)
        if all(v>=-1e-8 for v in minima):converged=True;break
        if not any(added):raise RuntimeError('Negative pricing without an omitted column')
        for p,columns in enumerate(added):pools[p].update(columns)
    if not trace:raise RuntimeError('Budget expired before a valid pricing bound')
    root_wall=time.perf_counter()-started
    result={'input':name,'converged':converged,'rounds':len(trace),
            'full_lp_bound':trace[-1]['pricing_corrected_lower_bound'],
            'restricted_lp_objective':trace[-1]['restricted_lp'],
            'patterns':len(R),'feasible_patterns':int(feasible.sum()),
            'columns_by_period':[len(s) for s in pools],'dp_wall_seconds':dp_seconds,
            'root_wall_seconds_including_input_dp_master_pricing':root_wall,
            'dp_return_array_bytes':allocated,'pricing_tolerance':1e-8,'trace':trace,
            'scope':'internal single run; c=1, travel + end-period holding; no published comparison'}
    # A feasible integer solution of the generated pool is a full-model UB.
    lap=time.perf_counter();lp,y,q,inv,_,_=build_master(i,g,pools)
    integral=np.zeros(len(lp.c),dtype=int);integral[np.array(y).ravel()]=1
    lb=np.array([b[0] for b in lp.bounds]);ub=np.array([np.inf if b[1] is None else b[1] for b in lp.bounds])
    constraints=[LinearConstraint(lp.sparse(lp.eq),np.array(lp.eb),np.array(lp.eb)),
                 LinearConstraint(lp.sparse(lp.ub),-np.inf,np.array(lp.ubrhs))]
    integer=milp(np.array(lp.c),integrality=integral,bounds=Bounds(lb,ub),
                 constraints=constraints,options={'time_limit':30.,'mip_rel_gap':0.})
    primal={'solver_status':int(integer.status),'message':str(integer.message),
            'wall_seconds_including_master_build':time.perf_counter()-lap,
            'scope':'restricted-pool solve; its dual bound is NOT the full integer lower bound'}
    if integer.x is not None:
        visits=np.rint(integer.x[np.array(y)]).astype(int)
        row={'status':int(integer.status),'sets':[[k+1 for k in range(i.n) if visits[p,k]] for p in range(i.horizon)],
             'quantities':integer.x[np.array(q)].tolist(),'inventory':integer.x[np.array(inv)].tolist(),
             'objective_definition':'travel','objective':float(integer.fun)}
        verification=verify_plan(i,row,parent,last)
        if not verification.get('checked') or abs(verification['objective_difference_from_solver'])>1e-6:
            raise RuntimeError('Restricted-pool incumbent failed independent verification')
        primal.update({'upper_bound':verification['objective_decimal'],'plan':row,'verification':verification})
        result['full_model_relative_gap_from_root']=(verification['objective_decimal']-result['full_lp_bound'])/verification['objective_decimal']
    result['restricted_pool_primal']=primal
    result['total_wall_seconds']=time.perf_counter()-started
    result['peak_process_working_set_bytes']=peak_working_set_bytes()
    (BASE/'n20_root_pilot.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in {'trace','restricted_pool_primal'}}),flush=True)
    print(json.dumps(primal),flush=True)
    return result


if __name__=='__main__':run()
