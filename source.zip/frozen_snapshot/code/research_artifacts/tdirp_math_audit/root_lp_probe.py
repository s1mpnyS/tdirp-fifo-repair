"""Internal root-LP comparison under one declared mathematical model.

Not a reproduction or performance comparison against published implementations.
"""
from __future__ import annotations
import itertools,json,time
from pathlib import Path
import numpy as np
import scipy.sparse as sp
from scipy.optimize import linprog
from fifo_probe import FifoNetwork,dynamic_values
from model_probe import read_instance
from math_checks import subset_dp,closure_arrival

BASE=Path(__file__).resolve().parent

class LP:
    def __init__(self):
        self.c=[];self.bounds=[];self.eq=[];self.eb=[];self.ub=[];self.ubrhs=[]
    def var(self,c=0.,lo=0.,hi=None):
        k=len(self.c);self.c.append(c);self.bounds.append((lo,hi));return k
    def equality(self,d,rhs):self.eq.append(d);self.eb.append(rhs)
    def leq(self,d,rhs):self.ub.append(d);self.ubrhs.append(rhs)
    def sparse(self,rows):
        rr=[];cc=[];vv=[]
        for r,d in enumerate(rows):
            for c,v in d.items():
                if v:rr.append(r);cc.append(c);vv.append(v)
        return sp.coo_matrix((vv,(rr,cc)),shape=(len(rows),len(self.c))).tocsc()
    def solve(self):
        started=time.perf_counter()
        r=linprog(np.array(self.c),A_ub=self.sparse(self.ub),b_ub=np.array(self.ubrhs),
                  A_eq=self.sparse(self.eq),b_eq=np.array(self.eb),bounds=self.bounds,method="highs")
        return r,time.perf_counter()-started

def base_model(i):
    lp=LP();n,H=i.n,i.horizon
    y=[[lp.var(hi=1.) for k in range(n)] for p in range(H)]
    q=[[lp.var() for k in range(n)] for p in range(H)]
    inv=[[lp.var(c=i.supplier_holding)]+[lp.var(c=i.holding[k]) for k in range(n)] for p in range(H)]
    z=[lp.var(c=1.,hi=i.deadline) for p in range(H)]
    for p in range(H):
        d={inv[p][0]:1.,**{q[p][k]:1. for k in range(n)}}
        if p:d[inv[p-1][0]]=-1.
        lp.equality(d,i.production[p]+(i.supplier_initial if p==0 else 0.))
        lp.leq({q[p][k]:1. for k in range(n)},i.capacity)
        lp.leq({z[p]:1.,**{y[p][k]:i.service[k] for k in range(n)}},i.deadline)
        for k in range(n):
            d={inv[p][k+1]:1.,q[p][k]:-1.}
            if p:d[inv[p-1][k+1]]=-1.
            lp.equality(d,-i.demand[p,k]+(i.initial[k] if p==0 else 0.))
            d={q[p][k]:1.}
            if p:d[inv[p-1][k+1]]=1.
            lp.leq(d,i.maximum[k]-(i.initial[k] if p==0 else 0.))
            lp.leq({q[p][k]:1.,y[p][k]:-i.maximum[k]},0.)
    return lp,y,q,inv,z

def add_projection(lp,i,y,q,z,B,values,joint,dynamic=False,allowed=None):
    k=len(B);masks=list(range(1<<k)) if allowed is None else allowed
    for p in range(i.horizon):
        weights={T:lp.var() for T in masks}
        lp.equality({v:1. for v in weights.values()},1.)
        for b,global_i in enumerate(B):
            row={y[p][global_i]:-1.}
            row.update({weights[T]:1. for T in masks if T>>b&1})
            lp.equality(row,0.)
        row={z[p]:-1.};row.update({weights[T]:values[T] for T in masks})
        if dynamic:row.update({y[p][k]:-i.service[k] for k in range(i.n)})
        lp.leq(row,0.)
        if not joint:continue
        allocations={(T,b):lp.var() for T in masks for b in range(k) if T>>b&1}
        for b,global_i in enumerate(B):
            row={q[p][global_i]:-1.}
            row.update({col:1. for (T,bb),col in allocations.items() if bb==b})
            lp.equality(row,0.)
        for T in masks:
            row={weights[T]:-i.capacity}
            for b,global_i in enumerate(B):
                if T>>b&1:
                    col=allocations[T,b];row[col]=1.
                    lp.leq({col:1.,weights[T]:-i.maximum[global_i]},0.)
            lp.leq(row,0.)

def static_closure(i,tight=False):
    if tight:
        network=FifoNetwork(i)
        times=sorted({0,i.deadline}|{min(i.deadline,(m+1)*i.step_seconds-1) for m in range(i.steps) if m*i.step_seconds<=i.deadline})
        d=np.zeros((i.n+1,i.n+1))
        for a in range(i.n+1):
            for b in range(i.n+1):
                if a!=b:d[a,b]=min(network.arrival(a,b,float(t))-t for t in times)
        # All actual depot departures take place at zero.
        for b in range(1,i.n+1):d[0,b]=network.arrival(0,b,0.)
    else:
        d=np.min(i.travel,axis=2).copy()
    np.fill_diagonal(d,0.)
    for k in range(i.n+1):d=np.minimum(d,d[:,k,None]+d[None,k,:])
    return d

def add_static_flow(lp,i,y,q,z,metric,cutsets=True):
    nodes=range(i.n+1)
    for p in range(i.horizon):
        use=lp.var(hi=1.)
        arcs={(a,b):lp.var(hi=1.) for a in nodes for b in nodes if a!=b}
        flow={(a,b):lp.var() for a,b in arcs}
        for a in nodes:
            target=use if a==0 else y[p][a-1]
            out={target:-1.};out.update({col:1. for (aa,b),col in arcs.items() if aa==a})
            inc={target:-1.};inc.update({col:1. for (b,aa),col in arcs.items() if aa==a})
            lp.equality(out,0.);lp.equality(inc,0.)
            balance={}
            for (b,c),col in flow.items():
                if c==a:balance[col]=balance.get(col,0.)+1.
                if b==a:balance[col]=balance.get(col,0.)-1.
            if a:balance[q[p][a-1]]=-1.
            else:
                for k in range(i.n):balance[q[p][k]]=1.
            lp.equality(balance,0.)
        for edge,col in flow.items():lp.leq({col:1.,arcs[edge]:-i.capacity},0.)
        lp.leq({use:-i.capacity,**{q[p][k]:1. for k in range(i.n)}},0.)
        row={z[p]:-1.};row.update({col:metric[a,b] for (a,b),col in arcs.items()})
        lp.leq(row,0.)
        if cutsets:
            for S in range(1,1<<i.n):
                crossing={col:-1. for (a,b),col in arcs.items() if a>0 and S>>(a-1)&1 and (b==0 or not S>>(b-1)&1)}
                for k in range(i.n):
                    if S>>k&1:lp.leq({**crossing,y[p][k]:1.},0.)

def block_values(i,B,metric,closed=None):
    k=len(B);nodes=[0]+[a+1 for a in B]
    stat=subset_dp(k,lambda a,b,t:t+metric[nodes[a],nodes[b]],np.zeros(k))
    dyn=None
    if closed is not None:
        dyn=subset_dp(k,lambda a,b,t:closed(nodes[a],nodes[b],t),i.service[list(B)])
    return stat,dyn

def run_case(name,with_dynamic=True):
    i=read_instance(name);start=time.perf_counter()
    exact,_,_,_=dynamic_values(i)
    statmetric=static_closure(i);network=FifoNetwork(i)
    closed=closure_arrival(i.n+1,network.arrival) if with_dynamic else None
    blocks=list(itertools.combinations(range(i.n),3))
    tables={B:block_values(i,B,statmetric,closed) for B in blocks}
    preprocess=time.perf_counter()-start
    rows=[]
    modes=["inventory_only","static_visit","static_joint"]
    if with_dynamic:modes+=["static_dynamic_visit","static_dynamic_joint"]
    modes+=["full_route_quantity"]
    for mode in modes:
        build_start=time.perf_counter()
        lp,y,q,inv,z=base_model(i)
        if mode=="full_route_quantity":
            values=exact-np.array([sum(i.service[k] for k in range(i.n) if T>>k&1) for T in range(1<<i.n)])
            allowed=[T for T in range(1<<i.n) if exact[T]<=i.deadline]
            add_projection(lp,i,y,q,z,tuple(range(i.n)),values,True,allowed=allowed)
        elif mode!="inventory_only":
            joint=mode.endswith("joint")
            for B,(stat,dyn) in tables.items():
                add_projection(lp,i,y,q,z,B,stat,joint)
                if "dynamic" in mode:add_projection(lp,i,y,q,z,B,dyn,joint,dynamic=True)
        build=time.perf_counter()-build_start
        r,solve=lp.solve()
        assert r.success,(mode,r.message)
        rows.append({"input":name,"mode":mode,"lower_bound":float(r.fun),
                     "variables":len(lp.c),"rows":len(lp.eq)+len(lp.ub),
                     "build_seconds":build,"solve_seconds":solve,"block_count":len(blocks),
                     "preprocess_seconds":preprocess})
        print(json.dumps(rows[-1]),flush=True)
    by={r["mode"]:r["lower_bound"] for r in rows}
    assert by["static_joint"]+1e-6>=by["static_visit"]
    assert by["full_route_quantity"]+1e-6>=max(by.values())
    if with_dynamic:assert by["static_dynamic_joint"]+1e-6>=by["static_dynamic_visit"]
    return rows

def main():
    out=[]
    for name in ["H3/inst_5_120_1.txt","H6/inst_5_120_1.txt"]:
        out+=run_case(name)
    (BASE/"root_lp_probe.json").write_text(json.dumps(out,indent=2),encoding="utf-8")

if __name__=="__main__":main()

