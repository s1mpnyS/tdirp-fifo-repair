"""Post hoc replay of sensitivity probes with a gap before the first RSS sample.

Run in the original campaign checkout. This program reads frozen evidence and
writes a separate report. It never calls the optimizer.
"""

import argparse
from collections import Counter
from math import isfinite
from pathlib import Path
import sys
from zipfile import ZipFile


V17 = Path(__file__).resolve().parent / "research_artifacts" / "tdirp_v17"
sys.path.insert(0, str(V17))

import cell_evidence
import runner
import sensitivity_analysis
import sensitivity_probe


def load_cell(output, plan, cell, index):
    entry = index[cell["cell_id"]]
    folder = output / "run" / "cells" / cell["cell_id"]
    path = folder / "parent_result.json"
    if plan.get("evidence_storage") == cell_evidence.FORMAT:
        cell_evidence.verify(folder, entry)
    if runner.sha(path) != entry["sha256"]:
        raise ValueError(f"Parent result digest mismatch for {cell['cell_id']}")
    row = runner.load(path)
    identity = row["identity"]
    if (row["cell"] != cell or identity["cell"] != cell or identity["plan_sha256"] != plan["plan_sha256"]
            or row["budget_seconds"] != cell["budget_seconds"]):
        raise ValueError(f"Frozen assignment mismatch for {cell['cell_id']}")
    return row


def monitoring(row, resources):
    """Apply the frozen limits from the first sample through worker completion."""
    if row["worker_exit_code"] != 0 or row["execution_error"] or row["external_stop"]:
        return None, "worker_failure_or_stop"
    times = [sample["elapsed_seconds"] for sample in row["samples"]]
    if not times:
        return None, "missing_samples"
    end = row["full_parent_seconds"]
    gaps = [b - a for a, b in zip(times, times[1:] + [end])]
    peak = max(sample["resident_bytes"] for sample in row["samples"])
    if not isfinite(times[0]) or times[0] < 0 or any(not isfinite(gap) or gap < 0 for gap in gaps):
        raise ValueError("Invalid elapsed sampling clock")
    if peak != row["peak_sampled_tree_rss_bytes"]:
        raise ValueError("Recorded peak RSS differs from samples")
    if peak > resources["tree_rss_mib"] * 2**20:
        return None, "memory_limit"
    limit = resources["max_monitor_gap_seconds"]
    active_gap = max(gaps)
    if active_gap > limit:
        return None, "gap_after_first_sample"
    if row["clean_resource_timing"] != (times[0] <= limit):
        raise ValueError("Recorded monitoring status differs from sampling evidence")
    return {"first_sample_seconds": times[0], "max_gap_after_first_sample_seconds": active_gap,
            "peak_sampled_tree_rss_bytes": peak}, None


def warm_start_after_first_sample(row, checked_start, first_sample):
    """Use the verified pre-solve publication to bound when optimization could start."""
    warm = [publication for publication in row["publications"]
            if (publication.get("payload") or {}).get("stage") == "prior_known_warm_start"]
    if len(warm) != 1:
        return None
    publication = warm[0]
    payload = runner.load(publication["file"])
    receipt = runner.load(publication["receipt_file"])
    if (publication["rejections"] or payload != publication["payload"]
            or publication["verified"] != checked_start
            or runner.checkpoint_rejections(payload, receipt, row["identity"],
                publication["observed_elapsed_seconds"], row["budget_seconds"], checked_start)):
        raise ValueError("Pre-solve checkpoint receipt did not replay")
    elapsed = payload["completed_elapsed_since_parent"]
    return elapsed if elapsed >= first_sample else None


def analyze(output):
    plan_path = output / "plan.json"
    plan = runner.load(plan_path)
    if plan["cohort"] != "sensitivity":
        raise ValueError("Expected a V17 sensitivity campaign")
    runner.validate_plan(plan)
    runner.external_freeze(plan_path, plan, output / "execution_freeze.json", output / "receipt")
    index_path = output / "run" / "progress.json"
    original_path = output / "analysis.json"
    index = runner.load(index_path)
    original = runner.load(original_path)
    cells = {cell["cell_id"]: cell for cell in plan["cells"]}
    if (set(index) != set(cells) or original["plan_sha256"] != plan["plan_sha256"]
            or original["assigned_cells"] != len(cells) or original["recorded_cells"] != len(index)):
        raise ValueError("Expected the completed original sensitivity campaign")
    verifier = runner.independent_verifier()
    replayed, exclusions = {}, {}
    counts = Counter()
    with ZipFile(plan["archive"]) as inputs:
        for cell in cells.values():
            if cell["arm"] != "P":
                continue
            cell_id = cell["cell_id"]
            counts["assigned"] += 1
            if "sha256" not in index[cell_id]:
                exclusions[cell_id] = "missing_parent_evidence"
                continue
            row = load_cell(output, plan, cell, index)
            timing, reason = monitoring(row, plan["resources"])
            if timing is None:
                exclusions[cell_id] = reason
                continue
            report = row["phase_records"].get("probe")
            if report is None:
                exclusions[cell_id] = "missing_probe_report"
                continue
            source_cell = cells[cell["source_cell"]]
            source = load_cell(output, plan, source_cell, index)
            if (source_cell["arm"] != "K1" or source_cell["input"] != cell["input"]
                    or source_cell["seed"] != cell["seed"] or not source["clean_resource_timing"]
                    or "fixed_handoff" not in source["phase_records"]
                    or row["identity"]["source_result_sha256"] != index[source_cell["cell_id"]]["sha256"]):
                raise ValueError(f"Probe source identity mismatch for {cell_id}")
            instance = verifier.parse_instance(inputs.read(cell["input"]))
            checked_start = verifier.verify_physical(instance, source["retained"])
            if checked_start != source["retained"]:
                raise ValueError(f"Frozen K1 endpoint did not replay for {cell_id}")
            if not row["clean_resource_timing"]:
                warm = warm_start_after_first_sample(row, checked_start, timing["first_sample_seconds"])
                if warm is None:
                    exclusions[cell_id] = "no_proof_worker_was_sampled_before_solve"
                    continue
                timing["verified_pre_solve_checkpoint_seconds"] = warm
            status, hit, attempted, deadline = sensitivity_probe.replay(row, source, report, verifier, instance)
            counts["original_clean" if row["clean_resource_timing"] else "startup_gap_replayed"] += 1
            replayed[cell["input"], cell["seed"]] = {"cell_id": cell_id, "singleton_status": status,
                "joint_hit": hit, "joint_attempted": attempted, "joint_deadline": deadline, **timing}

    probes = []
    seeds = sorted({cell["seed"] for cell in cells.values() if cell["arm"] == "P"})
    for name, treatment in plan["sensitivity_files"].items():
        for seed in seeds:
            row = replayed.get((treatment["alias_of"] or name, seed))
            if row is not None:
                probes.append({"family": treatment["family"], "input": treatment["base_input"],
                               "treatment": treatment["treatment"], "seed": seed, **row})
    keys = sensitivity_analysis.prepare_pairs(original["rows"])
    lookup = {sensitivity_analysis.row_key(row): row for row in probes}
    if len(lookup) != len(probes) or lookup.keys() - keys.keys():
        raise ValueError("Replayed probes do not match the original treatment pairs")
    escape = {treatment: sensitivity_analysis.escape_summary(
        sorted(key for key in keys if key[3] == treatment), lookup)
        for treatment in sensitivity_analysis.TREATMENTS}
    return {"status": "POST_HOC_PROBE_REPLAY", "plan_sha256": plan["plan_sha256"],
            "original_analysis_sha256": runner.sha(original_path), "evidence_index_sha256": runner.sha(index_path),
            "assigned_probes": counts["assigned"], "original_clean_replayed": counts["original_clean"],
            "startup_gap_replayed": counts["startup_gap_replayed"], "excluded_probes": exclusions,
            "probes": probes, "directed_escape_by_treatment": escape}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Original completed campaign directory")
    args = parser.parse_args()
    output = args.output.resolve(strict=True)
    report = analyze(output)
    path = output / "escape_posthoc_replay.json"
    runner.atomic(path, report)
    print(f"Replayed {report['startup_gap_replayed']} startup-gap probes and "
          f"{report['original_clean_replayed']} originally clean probes. Excluded {len(report['excluded_probes'])}.")
    for key, entry in report["directed_escape_by_treatment"].items():
        print(f"{key}: {entry['certified_joint_hits']} hits, "
              f"{entry['singleton_status_counts']['certified']} certified, {entry['assigned_states']} assigned")
    print(path)


if __name__ == "__main__":
    main()
