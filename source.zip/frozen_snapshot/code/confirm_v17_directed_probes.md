# Prospective execution confirmation of the directed probes

Repeat all 120 probes from the completed V17 sensitivity campaign. The
assignments reuse the original K1 endpoints, treatments, seed-dependent
singleton order and preassigned K6 block. The K1 and K6 benchmark searches
are outside this confirmation. The existing post hoc report describes the
previous execution. This confirmation checks the same endpoint–block pairs
under an execution plan fixed before the new probes start.

Before the probe clock starts, verify each retained K1 endpoint and its
checkpoint receipt. Copy the retained checkpoint and receipt into a compact
source record. The frozen roster binds both the original K1 parent digest
and the compact source, along with the endpoint signature and unchanged
assignment. Timestamp the original plan, compact sources, execution code
and this protocol before dispatch. The compact source allows the parent to
replay the handoff without loading the entire K1 search journal at startup.

The original 32-second parent clock still includes source replay and setup.
The original one-second sampling limit applies from the start of the parent
clock through the final sampling interval. The 1,024 MiB sampled memory
limit, singleton limits, six-second joint limit and reserve stay as in the
original plan. A retained probe must also have a verified pre-solve receipt
whose timestamp follows the first RSS sample. Use the original feasibility,
strict improvement and numerical certificate criteria for every probe.

Attempt each assignment once. Report all failures and unresolved probes in
the assigned denominator. Report certified joint hits, the number of eligible
singleton-certified endpoints and the assigned count by condition. The repeated
executions assess the timing protocol on the same finite endpoint set.
