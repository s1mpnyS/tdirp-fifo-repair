"""Export and verify the portable evidence for the V22 probe confirmation."""

import argparse
from collections import Counter
import hashlib
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from confirm_v17_directed_probes import confirmation_result
from replay_v17_probe_startup import cell_evidence, monitoring, runner, sensitivity_probe
import timestamp


ANALYSIS_SHA256 = "8d9914bb8b39d354bae479cba0a287b8b99e02b18a1aa5f1fbc7361bb012a162"
RECEIPT_FILES = ("request.tsq", "response.tsr", "cacert.pem", "tsa.crt")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def frozen_name(name):
    path = PurePosixPath(name)
    require(path.anchor == "/" and ".." not in path.parts, "Invalid frozen Linux path")
    return "frozen/" + path.relative_to("/").as_posix()


def member_path(manifest, suffix):
    matches = [entry["path"] for entry in manifest["members"] if entry["path"].endswith(suffix)]
    require(len(matches) == 1, f"Expected one frozen member ending in {suffix}")
    return matches[0]


def read_report(data):
    require(digest(data) == ANALYSIS_SHA256, "Confirmation report differs from pinned commit 7d79b471")
    return json.loads(data)


def export(run, output):
    report = read_report((run / "analysis.json").read_bytes())
    manifest_file = run / "execution_freeze.json"
    require(runner.sha(manifest_file) == report["freeze_manifest_sha256"], "Execution freeze changed")
    manifest = runner.load(manifest_file)
    plan = runner.load(member_path(manifest, "/plan.json"))
    timestamp.verify(manifest_file, run / "receipt")
    for row in report["probes"]:
        cell_evidence.verify(run / "run" / "cells" / row["cell_id"], row)
    with ZipFile(output, "x", ZIP_DEFLATED) as bundle:
        bundle.write(run / "analysis.json", "analysis.json")
        bundle.write(manifest_file, "execution_freeze.json")
        for name in RECEIPT_FILES:
            bundle.write(run / "receipt" / name, "receipt/" + name)
        for entry in manifest["members"]:
            if entry["path"] not in plan["runtime_binary_sha256"]:
                bundle.write(entry["path"], frozen_name(entry["path"]))
        for row in report["probes"]:
            name = "run/cells/" + row["cell_id"] + "/evidence.zip"
            bundle.write(run / name, name)
    print(f"Portable probe evidence: {output}")


def verify_token(bundle, manifest, target):
    manifest_path = target / "execution_freeze.json"
    manifest_path.write_bytes(manifest)
    for name in RECEIPT_FILES:
        data = bundle.read("receipt/" + name)
        if name in timestamp.CERTIFICATES:
            require(digest(data) == timestamp.CERTIFICATES[name], "Pinned timestamp certificate changed")
        (target / name).write_bytes(data)
    common = ["-in", target / "response.tsr", "-CAfile", target / "cacert.pem", "-untrusted", target / "tsa.crt"]
    timestamp.command(["ts", "-verify", *common, "-queryfile", target / "request.tsq"])
    timestamp.command(["ts", "-verify", *common, "-data", manifest_path])


def check_source(frozen, item, plan, verifier, instance, target):
    cell = item["cell"]
    source_path = target / "source.json"
    source_path.write_bytes(frozen(item["source"]))
    source = runner.load(source_path)
    identity = sensitivity_probe.source_identity(source_path, plan, cell)
    require(identity["source_result_sha256"] == item["compact_parent_sha256"]
            and identity["source_endpoint_sha256"] == item["source_endpoint_sha256"], "K1 source digest mismatch")
    point = verifier.verify_physical(instance, source["retained"])
    anchor = verifier.verify_physical(instance, plan["warm_starts"][cell["input"]]["point"])
    require(point == source["retained"] and anchor == source["initial"]
            and source["phase_records"]["fixed_handoff"]["physical_sha256"] == runner.physical_signature(anchor),
            "K1 endpoint or handoff failed physical replay")
    if source["retained_checkpoint_file"] is None:
        require(point == anchor, "Fallback without a retained receipt differs from anchor")
    else:
        publication, = source["publications"]
        payload = json.loads(frozen(publication["file"]))
        receipt = json.loads(frozen(publication["receipt_file"]))
        require(source["retained_checkpoint_file"] == publication["file"]
                and publication["payload"] == payload and publication["verified"] == point
                and not publication["rejections"] and not runner.checkpoint_rejections(
                    payload, receipt, source["identity"], publication["observed_elapsed_seconds"],
                    source["budget_seconds"], point), "K1 receipt did not replay")
    return {**item, "source": str(source_path)}


def replay_cell(bundle, expected, item, plan, verifier, instance, target):
    cid = expected["cell_id"]
    archive = bundle.read(f"run/cells/{cid}/evidence.zip")
    require(digest(archive) == expected["evidence_zip_sha256"], f"Probe archive changed for {cid}")
    with ZipFile(BytesIO(archive)) as cell:
        raw = cell.read("parent_result.json")
        require(digest(raw) == expected["parent_result_sha256"], f"Parent result changed for {cid}")
        row = json.loads(raw)
        require(row["cell"] == row["identity"]["cell"] == item["cell"]
                and row["identity"]["plan_sha256"] == plan["plan_sha256"]
                and row["budget_seconds"] == item["cell"]["budget_seconds"], f"Probe assignment changed for {cid}")
        for publication in row["publications"]:
            for key in ("file", "receipt_file"):
                name = PurePosixPath(publication[key]).name
                path = target / name
                path.write_bytes(cell.read("checkpoints/" + name))
                if publication[key] == row["latest_eligible_checkpoint_file"]:
                    row["latest_eligible_checkpoint_file"] = str(path)
                publication[key] = str(path)
    timing, reason = monitoring(row, plan["resources"])
    require(timing is not None and row["clean_resource_timing"]
            and timing["first_sample_seconds"] <= plan["resources"]["max_monitor_gap_seconds"]
            and max(timing["first_sample_seconds"], timing["max_gap_after_first_sample_seconds"])
            == row["observed_max_sampling_gap_seconds"],
            f"Original gate failed for {cid}: {reason}")
    actual = confirmation_result(row, item, plan, verifier, instance)
    require(all(expected[key] == value for key, value in actual.items()), f"Probe replay differs for {cid}")
    return actual


def verify(artifact):
    with ZipFile(artifact) as bundle, TemporaryDirectory(prefix="v22-probes-") as temp:
        report = read_report(bundle.read("analysis.json"))
        manifest_bytes = bundle.read("execution_freeze.json")
        require(digest(manifest_bytes) == report["freeze_manifest_sha256"], "Execution freeze changed")
        require(len(bundle.namelist()) == len(set(bundle.namelist())), "Duplicate archive members")
        manifest = json.loads(manifest_bytes)
        frozen = lambda path: bundle.read(frozen_name(path))
        plan_path = member_path(manifest, "/plan.json")
        plan = json.loads(frozen(plan_path))
        original_checkout = PurePosixPath(plan_path).parents[3]
        omitted = set(plan["runtime_binary_sha256"])
        checked_sources = 0
        for entry in manifest["members"]:
            if entry["path"] not in omitted:
                data = frozen(entry["path"])
                require(len(data) == entry["bytes"] and digest(data) == entry["sha256"], "Frozen member digest mismatch")
                recorded_path = PurePosixPath(entry["path"])
                if recorded_path.is_relative_to(original_checkout / "code") and not recorded_path.is_relative_to(original_checkout / "code/runs"):
                    local = runner.CODE.parent / recorded_path.relative_to(original_checkout)
                    require(runner.sha(local) == entry["sha256"], f"Local frozen source differs: {local}")
                    checked_sources += 1
        verify_token(bundle, manifest_bytes, Path(temp))
        roster = json.loads(frozen(member_path(manifest, "/confirmation_plan.json")))
        index = json.loads(frozen(member_path(manifest, "/run/progress.json")))
        original = [cell for cell in plan["cells"] if cell["arm"] == "P"]
        require([item["cell"] for item in roster["assignments"]] == original and len(original) == 120,
                "Original probe roster changed")
        verifier = runner.independent_verifier()
        hits = Counter()
        with ZipFile(BytesIO(frozen(plan["archive"]))) as inputs:
            for item, expected in zip(roster["assignments"], report["probes"], strict=True):
                cell = item["cell"]
                cid = cell["cell_id"]
                require(expected["cell_id"] == cid and item["source_parent_sha256"] == index[cell["source_cell"]]["sha256"],
                        f"K1 parent digest or probe assignment mismatch for {cid}")
                instance = verifier.parse_instance(inputs.read(cell["input"]))
                target = Path(temp) / cid
                target.mkdir()
                local_item = check_source(frozen, item, plan, verifier, instance, target)
                actual = replay_cell(bundle, expected, local_item, plan, verifier, instance, target)
                require(actual["eligibility"] == "eligible" and actual["singleton_status"] == "certified",
                        f"Missing verified singleton certificates for {cid}")
                hits[actual["treatment"]] += actual["joint_hit"]
        print(json.dumps({"verified_probes": len(original), "joint_hits": sum(hits.values()), "hits_by_treatment": hits,
                          "frozen_members_verified": len(manifest["members"]) - len(omitted),
                          "local_frozen_sources_verified": checked_sources,
                          "original_runtime_binaries_omitted": len(omitted), "rfc3161_token_verified": True}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    exporter = sub.add_parser("export", help="Run in the original server checkout")
    exporter.add_argument("--run", type=Path, required=True)
    exporter.add_argument("--output", type=Path, required=True)
    checker = sub.add_parser("verify", help="Run from an independent checkout with OpenSSL")
    checker.add_argument("archive", type=Path)
    args = parser.parse_args()
    if args.command == "export":
        export(args.run.resolve(strict=True), args.output.resolve())
    else:
        verify(args.archive)


if __name__ == "__main__":
    main()
