"""Isolated, reused-state FIFO profile mechanism diagnostic (not V10 search)."""
