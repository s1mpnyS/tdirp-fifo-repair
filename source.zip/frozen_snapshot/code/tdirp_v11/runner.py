"""Prepare/freeze without optimization, then explicitly execute a fixed diagnostic.

No optimizer imports occur in the parent supervision process. Scientific workers
wait for assignment to the existing Windows Job monitor before numerical imports.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import random
import subprocess
import sys
import time
import traceback
import zipfile

CODE = Path(__file__).resolve().parents[1]
ART = CODE / "research_artifacts"
DECODERS = ("fifo_free_exact", "fifo_contiguous_exact_pure", "fifo_greedy_legacy")
FORMAT = "v11_reused_fifo_local_mechanism_v1"
ARCHIVE_SHA = "90f4b2e5705f43d1a1b2a574ea2f2ac35c443c04fedff8ebf77ac6fecb0e093c"
THREAD_ENV = {name: "1" for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
                                      "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def source_paths():
    paths = list((CODE / "tdirp_v11").glob("*.py"))
    paths += list((ART / "tdirp_math_audit").glob("*.py"))
    paths += [ART / "tdirp_newalgo/schedule_repair.py", ART / "tdirp_v3/joint_repair.py",
              ART / "tdirp_v10/execution.py"]
    return sorted(set(path.resolve() for path in paths))


def expected_cases():
    return {f"H{H}/inst_{n}_{M}_{index}.txt" for H, n in ((6, 15), (6, 20), (3, 25), (3, 30))
            for M in (30, 120) for index in (1, 3)}


def block_order(case):
    H, name = case.split("/")
    _, n, _, index = name.removesuffix(".txt").split("_")
    return sorted(range(int(n)), key=lambda customer: hashlib.sha256(
        f"v11_control_block_v1|20261190|{int(H[1:])}|{int(n)}|{int(index)}|{customer}".encode()).digest())


def build_cells(cases):
    cells = [{"input": case, "state": state, "k": k, "decoder": decoder,
              "block": block_order(case)[:k]}
             for case in cases for state in ("I", "E") for k in (4, 6, 8) for decoder in DECODERS]
    random.Random(20261191).shuffle(cells)
    return [{"cell_id": f"{index:04d}", **cell} for index, cell in enumerate(cells)]


def numerical_dependencies():
    for name in ("tdirp_math_audit", "tdirp_newalgo"):
        path = str(ART / name)
        if path not in sys.path:
            sys.path.insert(0, path)
    import model_probe
    from schedule_repair import verify_routes
    return model_probe, verify_routes


def prepare(output, archive, verify_states=False):
    output, archive = Path(output).resolve(), Path(archive).resolve()
    if output.exists():
        raise FileExistsError("Plan output already exists")
    if sha(archive) != ARCHIVE_SHA:
        raise ValueError("Pinned benchmark archive mismatch")
    protocol_path, results_path = CODE / "reference/protocol.json", CODE / "reference/results.json"
    protocol, results = json.loads(protocol_path.read_text()), json.loads(results_path.read_text())
    cases = protocol["cases"]
    if len(cases) != 16 or set(cases) != expected_cases():
        raise ValueError("Expected the complete fixed 16-file V6 panel")
    model_probe = verify = None
    if verify_states:
        model_probe, verify = numerical_dependencies()
        model_probe.ARCHIVE = archive
    states, initial_sources, input_hashes = {}, {}, {}
    with zipfile.ZipFile(archive) as zipped:
        for case in cases:
            input_hashes[case] = hashlib.sha256(zipped.read(case)).hexdigest()
            original_path = CODE / "initials" / (case.replace("/", "_") + ".json")
            original = json.loads(original_path.read_text())
            matches = [(index, row) for index, row in enumerate(results["search"])
                       if row["input"] == case and row["method"] == "joint_dp_polish" and row["seed"] == 20261121]
            if len(matches) != 1 or original.get("success") is not True:
                raise ValueError("Missing fixed state: " + case)
            row_index, row = matches[0]
            if row.get("endpoint_eligible") is not True or row["result"].get("independent_verification", {}).get("checked") is not True:
                raise ValueError("Fixed endpoint lacks stored eligibility: " + case)
            initial_sources[str(original_path)] = sha(original_path)
            states[case] = {}
            instance = model_probe.read_instance(case) if verify_states else None
            for label, source in (("I", original), ("E", row["result"])):
                physical = {key: copy.deepcopy(source[key]) for key in ("routes", "quantities")}
                record = {**physical, "input": case, "physical_sha256": digest(physical),
                          "source": str(original_path) if label == "I" else str(results_path),
                          "endpoint_selector": None if label == "I" else {"row_index": row_index,
                              "method": "joint_dp_polish", "seed": 20261121},
                          "exact_feasible_objective": source.get("exact_feasible_objective",
                              source.get("independent_verification", {}).get("exact_feasible_objective"))}
                if verify_states:
                    checked = verify(instance, physical["routes"], physical["quantities"], "completion")
                    if not checked.get("checked"):
                        raise ValueError("Fixed state failed independent literal replay: " + case + "/" + label)
                    if record["exact_feasible_objective"] is not None:
                        from fractions import Fraction
                        if Fraction(record["exact_feasible_objective"]) != Fraction(checked["exact_feasible_objective"]):
                            raise ValueError("Stored objective disagrees with literal replay")
                    record["exact_feasible_objective"] = checked["exact_feasible_objective"]
                    record["independent_preflight_verification"] = checked
                states[case][label] = record
    plan = {"format": FORMAT, "status": "PREPARED_NOT_FROZEN", "scientific_calls_executed": 0,
            "scope": "Reused V6 fixed-state local mechanism diagnostic; not held-out, global or end-to-end evidence",
            "archive": str(archive), "archive_sha256": ARCHIVE_SHA, "input_sha256": input_hashes,
            "legacy_protocol": str(protocol_path), "legacy_protocol_sha256": sha(protocol_path),
            "legacy_results": str(results_path), "legacy_results_sha256": sha(results_path),
            "initial_sources": initial_sources, "source_sha256": {str(p): sha(p) for p in source_paths()},
            "state_preflight_verified": verify_states, "states": states, "cases": cases,
            "cells": build_cells(cases), "local_seconds": 6., "parent_seconds": 15., "reserve_seconds": 3.,
            "threads": 1, "sampled_tree_memory_mib": 1024., "sampling_seconds": .1,
            "fallback": "pure raw contiguous master; original full input state retained externally",
            "greedy_incumbent_augmentation": True, "block_seed": 20261190, "order_seed": 20261191,
            "comparison_outcome_used_in_selection": False, "automatic_retries": False}
    plan["plan_sha256"] = digest(plan)
    output.parent.mkdir(parents=True, exist_ok=True)
    atomic(output, plan)
    return plan


def validate_plan(plan, frozen=False, verify_archive=True):
    if plan.get("format") != FORMAT or digest({k: v for k, v in plan.items() if k != "plan_sha256"}) != plan.get("plan_sha256"):
        raise ValueError("Plan format/digest mismatch")
    if set(plan["cases"]) != expected_cases() or plan["cells"] != build_cells(plan["cases"]):
        raise ValueError("Cell grid/selection mismatch")
    if (plan["local_seconds"], plan["parent_seconds"], plan["reserve_seconds"], plan["threads"],
            plan["sampled_tree_memory_mib"]) != (6., 15., 3., 1, 1024.):
        raise ValueError("Fixed resource contract changed")
    if frozen and (plan.get("status") != "FROZEN_FOR_PARENT_AUTHORISED_EXECUTION" or not plan.get("state_preflight_verified")):
        raise ValueError("Require frozen plan and independent state preflight")
    for path, expected in plan["source_sha256"].items():
        if sha(path) != expected:
            raise ValueError("Computational source drift: " + path)
    for path, expected in {plan["legacy_protocol"]: plan["legacy_protocol_sha256"],
                           plan["legacy_results"]: plan["legacy_results_sha256"], **plan["initial_sources"]}.items():
        if sha(path) != expected:
            raise ValueError("Retained input-state source drift: " + path)
    if verify_archive and sha(plan["archive"]) != plan["archive_sha256"]:
        raise ValueError("Benchmark archive drift")
    for case in plan["cases"]:
        for label in ("I", "E"):
            record = plan["states"][case][label]
            if record.get("input") != case or digest({k: record[k] for k in ("routes", "quantities")}) != record["physical_sha256"]:
                raise ValueError("Frozen physical state mismatch")


def freeze(path):
    path = Path(path)
    plan = json.loads(path.read_text())
    validate_plan(plan)
    if not plan["state_preflight_verified"]:
        raise ValueError("Prepare with --verify-states before freeze")
    plan["status"] = "FROZEN_FOR_PARENT_AUTHORISED_EXECUTION"
    plan.pop("plan_sha256")
    plan["plan_sha256"] = digest(plan)
    atomic(path, plan)
    return plan


def load_monitor():
    spec = importlib.util.spec_from_file_location("_v11_frozen_v10_monitor", ART / "tdirp_v10/execution.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.WindowsJob


def publication_rejections(payload, receipt, cell, plan, observed_elapsed):
    rejected = []
    if receipt.get("payload_sha256") != digest(payload):
        rejected.append("receipt_digest_mismatch")
    if payload.get("plan_sha256") != plan["plan_sha256"] or payload.get("cell") != cell:
        rejected.append("identity_mismatch")
    completed = payload.get("completed_elapsed_since_parent")
    if isinstance(completed, bool) or not isinstance(completed, (int, float)) or not math.isfinite(completed) or not 0 <= completed <= plan["parent_seconds"]:
        rejected.append("completion_outside_parent_cap")
    if isinstance(observed_elapsed, bool) or not isinstance(observed_elapsed, (int, float)) or not math.isfinite(observed_elapsed) or not 0 <= observed_elapsed <= plan["parent_seconds"]:
        rejected.append("publication_observed_after_parent_cap")
    result = payload.get("result", {})
    claims_timed_evidence = (result.get("candidate_eligible") or result.get("raw_conditional_optimum_verified")
                            or result.get("raw_conditional_infeasible"))
    elapsed = result.get("wall_seconds")
    if claims_timed_evidence and (isinstance(elapsed, bool) or not isinstance(elapsed, (int, float))
                                 or not math.isfinite(elapsed) or not 0 <= elapsed <= plan["local_seconds"]):
        rejected.append("candidate_or_certificate_outside_local_cap")
    if result.get("raw_conditional_optimum_verified") or result.get("raw_conditional_infeasible"):
        certificate = result.get("certificate_seconds")
        if (isinstance(certificate, bool) or not isinstance(certificate, (int, float))
                or not math.isfinite(certificate) or not 0 <= certificate <= plan["local_seconds"]):
            rejected.append("certificate_time_invalid")
    if "local_allowance_seconds" in payload and claims_timed_evidence:
        allowance = payload["local_allowance_seconds"]
        if (isinstance(allowance, bool) or not isinstance(allowance, (int, float))
                or not math.isfinite(allowance) or isinstance(elapsed, bool)
                or not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed)
                or not 0 <= elapsed <= allowance <= plan["local_seconds"]):
            rejected.append("evidence_outside_actual_local_allowance")
    return rejected


def observe_publication(output, cell, plan, parent_start, clock=time.perf_counter):
    """One timed atomic-pair scan; called again on observed child exit."""
    output = Path(output)
    receipt_path = Path(str(output) + ".commit.json")
    if not output.exists() or not receipt_path.exists():
        return None
    payload, receipt = json.loads(output.read_text()), json.loads(receipt_path.read_text())
    elapsed = clock() - parent_start
    return payload, elapsed, publication_rejections(payload, receipt, cell, plan, elapsed)


def worker(args):
    while not Path(args.gate).exists():
        if time.perf_counter() >= args.parent_start + 15.:
            raise TimeoutError("Parent assignment gate timed out")
        time.sleep(.005)
    plan = json.loads(Path(args.plan).read_text())
    # Full source/state validation and archive hashing are charged to cold parent.
    validate_plan(plan, frozen=True)
    cell = next(cell for cell in plan["cells"] if cell["cell_id"] == args.cell_id)
    phase = time.perf_counter()
    model_probe, _ = numerical_dependencies()
    model_probe.ARCHIVE = Path(plan["archive"])
    instance = model_probe.read_instance(cell["input"])
    from .repair import one_repair
    setup_seconds = time.perf_counter() - phase
    local_start = time.perf_counter()
    local_deadline = min(local_start + plan["local_seconds"], args.parent_start + plan["parent_seconds"] - plan["reserve_seconds"])
    result = one_repair(instance, plan["states"][cell["input"]][cell["state"]], cell["block"],
                        cell["decoder"], local_deadline)
    import numpy, scipy
    payload = {"plan_sha256": plan["plan_sha256"], "cell": cell, "result": result,
               "setup_import_and_input_seconds": setup_seconds, "local_start_elapsed": local_start - args.parent_start,
               "local_allowance_seconds": max(0., local_deadline - local_start),
               "completed_elapsed_since_parent": time.perf_counter() - args.parent_start,
               "software": {"python": sys.version, "executable": sys.executable,
                            "numpy": numpy.__version__, "scipy": scipy.__version__}}
    atomic(args.output, payload)
    atomic(str(args.output) + ".commit.json", {"payload_sha256": digest(payload)})


def run_one(plan_path, plan, cell, root):
    folder = Path(root) / cell["cell_id"]
    folder.mkdir(exist_ok=False)
    output, gate = folder / "worker.json", folder / "attached.gate"
    start, hard_cap = time.perf_counter(), plan["parent_seconds"]
    command = [sys.executable, "-B", "-m", "tdirp_v11.runner", "worker", "--plan", str(plan_path),
               "--cell-id", cell["cell_id"], "--output", str(output), "--gate", str(gate),
               "--parent-start", repr(start)]
    job = process = None
    samples, observed, publication, rejects = [], None, None, []
    stop = error = None
    try:
        Job = load_monitor()
        job = Job()
        with (folder / "worker.log").open("w", encoding="utf-8") as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, cwd=CODE,
                                       env={**os.environ, **THREAD_ENV, "PYTHONIOENCODING": "utf-8"},
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            job.attach(process)
            atomic(gate, {"attached": True})
            while True:
                sample = job.sample()
                samples.append({"elapsed_seconds": time.perf_counter() - start, **sample})
                if sample["resident_bytes"] > plan["sampled_tree_memory_mib"] * 1024 ** 2:
                    stop = "sampled_process_tree_rss_limit"
                if observed is None:
                    found = observe_publication(output, cell, plan, start)
                    if found is not None:
                        publication, observed, rejects = found
                        if stop == "sampled_process_tree_rss_limit":
                            rejects.append("first_publication_after_sampled_memory_violation")
                if process.poll() is not None:
                    # The child can commit between the preceding scan and poll.
                    # Observe the atomic pair once more, retaining the real clock.
                    if observed is None:
                        found = observe_publication(output, cell, plan, start)
                        if found is not None:
                            publication, observed, rejects = found
                            if stop == "sampled_process_tree_rss_limit":
                                rejects.append("first_publication_after_sampled_memory_violation")
                    break
                if stop or time.perf_counter() >= start + hard_cap:
                    stop = stop or "parent_wall_limit"
                    job.terminate()
                    break
                time.sleep(min(plan["sampling_seconds"], max(0., start + hard_cap - time.perf_counter())))
            process.wait(timeout=10.)
    except Exception as exc:
        error, stop = f"{type(exc).__name__}: {exc}", stop or "worker_or_monitor_failure"
        if process is not None and process.poll() is None:
            try:
                job.terminate() if job is not None else process.kill()
            finally:
                process.wait(timeout=10.)
    finally:
        if job is not None:
            job.close()
    valid = publication is not None and not rejects
    original = plan["states"][cell["input"]][cell["state"]]
    result = publication["result"] if valid else None
    gaps = [samples[index]["elapsed_seconds"] - samples[index - 1]["elapsed_seconds"] for index in range(1, len(samples))]
    row = {"cell": cell, "plan_sha256": plan["plan_sha256"], "publication_eligible": valid,
           "publication_observed_elapsed_seconds": observed, "publication_rejections": rejects,
           "external_stop": stop, "execution_error": error,
           "worker_exit_code": None if process is None else process.returncode,
           "full_parent_seconds": time.perf_counter() - start,
           "peak_sampled_tree_rss_bytes": max((s["resident_bytes"] for s in samples), default=None),
           "observed_max_sampling_gap_seconds": max(gaps, default=None), "samples": samples,
           "resource_scope": "Windows kill-on-close job; simultaneous tree RSS sampled at 0.1s, not continuous peak enforcement",
           "result": result, "retained_origin": result["retained_origin"] if result else "preflight_input_external_fallback",
           "retained_exact_objective": result["retained_exact_objective"] if result else original["exact_feasible_objective"],
           "retained_routes": result["retained_routes"] if result else original["routes"],
           "retained_quantities": result["retained_quantities"] if result else original["quantities"]}
    atomic(folder / "parent_result.json", row)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare", help="Read-only state/source preparation; no optimization")
    prep.add_argument("--output", required=True)
    prep.add_argument("--archive", default=str(CODE / "data/Benchmark.zip"))
    prep.add_argument("--verify-states", action="store_true", help="Independent literal replay only; no optimizer")
    sealing = sub.add_parser("freeze", help="Seal checked sources/protocol; no optimization")
    sealing.add_argument("--plan", required=True)
    run = sub.add_parser("run", help="Explicit scientific execution only after parent freeze")
    run.add_argument("--plan", required=True); run.add_argument("--output", required=True)
    run.add_argument("--execute", action="store_true", required=True)
    child = sub.add_parser("worker")
    for flag in ("plan", "cell-id", "output", "gate"):
        child.add_argument("--" + flag, required=True)
    child.add_argument("--parent-start", type=float, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        plan = prepare(args.output, args.archive, args.verify_states)
        print(json.dumps({"status": plan["status"], "cells": len(plan["cells"]), "plan_sha256": plan["plan_sha256"]}))
    elif args.command == "freeze":
        plan = freeze(args.plan)
        print(json.dumps({"status": plan["status"], "plan_sha256": plan["plan_sha256"]}))
    elif args.command == "worker":
        worker(args)
    else:
        plan_path = Path(args.plan).resolve()
        plan = json.loads(plan_path.read_text())
        validate_plan(plan, frozen=True)
        if os.name != "nt":
            raise RuntimeError("This frozen protocol requires the Windows native tree monitor")
        root = Path(args.output).resolve()
        root.mkdir(parents=True, exist_ok=False)
        rows = []
        for cell in plan["cells"]:
            validate_plan(plan, frozen=True, verify_archive=False)
            rows.append(run_one(plan_path, plan, cell, root))
            atomic(root / "progress.json", {"status": "RUNNING", "planned_calls": len(plan["cells"]),
                                            "completed_calls": len(rows), "last_cell_id": cell["cell_id"]})
        atomic(root / "results.json", {"status": "COMPLETED", "plan_sha256": plan["plan_sha256"],
                                       "planned_calls": len(plan["cells"]), "rows": rows})
        print(json.dumps({"status": "COMPLETED", "cells": len(rows), "output": str(root)}))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)
