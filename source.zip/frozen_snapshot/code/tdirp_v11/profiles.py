"""Pure all-subset FIFO route profiles, with explicit family and interruption scope.

For contiguous profiles, a block run may start while mask is empty, continue
while the last node is a block node, and cannot reopen after an outside node.
Every gap/permutation is represented. FIFO dominance makes one earliest label
per (outside prefix, selected mask, last code) sufficient in either exact family.
"""
from __future__ import annotations

import math
from numbers import Integral
from pathlib import Path
import sys
import time

import numpy as np

ART = Path(__file__).resolve().parents[1] / "research_artifacts"
for directory in ("tdirp_newalgo", "tdirp_math_audit"):
    path = str(ART / directory)
    if path not in sys.path:
        sys.path.insert(0, path)
from schedule_repair import FifoNetwork, route_finish

DECODERS = ("fifo_free_exact", "fifo_contiguous_exact_pure", "fifo_greedy_legacy")


class ProfileInterrupted(TimeoutError):
    def __init__(self, counters):
        super().__init__("profile construction deadline")
        self.counters = dict(counters)


def customers(values, n, label):
    answer = list(values)
    if any(isinstance(value, bool) or not isinstance(value, Integral) or not 0 <= value < n
           for value in answer):
        raise ValueError("Invalid " + label + " customer")
    answer = [int(value) for value in answer]
    if len(set(answer)) != len(answer):
        raise ValueError("Repeated " + label + " customer")
    return answer


def check_deadline(deadline, clock, counters):
    if deadline is not None and clock() >= deadline:
        raise ProfileInterrupted(counters)


def structural_counts(m, k, contiguous=False):
    if any(isinstance(value, bool) or not isinstance(value, Integral) or value < 0 for value in (m, k)):
        raise ValueError("Nonnegative integer dimensions required")
    q = 1 << k
    a = k * (1 << (k - 1)) if k else 0
    b = k * (k - 1) * (1 << (k - 2)) if k > 1 else 0
    outside = 1 + (m - 1) * q + m * a if m else 0
    edges = outside + k + m * a + (m + 1) * b
    return {"allocated_label_slots": (m + 1) * q * (k + 1),
            "structurally_reachable_labels": 1 + m * q + (m + 1) * a,
            "customer_transition_arcs": edges - m * (a - k) if contiguous else edges,
            "return_candidates": q + a if m else a,
            "reopening_arcs_removed": m * (a - k) if contiguous else 0}


def build_profiles(instance, outside, block, decoder, net=None, incumbent=None,
                   deadline=None, clock=time.perf_counter):
    """Build a complete table or raise ProfileInterrupted; never return partial exact data.

    Greedy reproduces frozen greedy_values, including incumbent augmentation at
    its membership mask; descendants may inherit that augmented predecessor.
    Exact contiguous profiles remain pure; the repair retains input externally.
    """
    if decoder not in DECODERS:
        raise ValueError("Unsupported decoder")
    outside = customers(outside, instance.n, "outside")
    block = customers(block, instance.n, "block")
    if set(outside) & set(block) or len(block) > 10:
        raise ValueError("Disjoint outside/block and block size <=10 required")
    if deadline is not None and not math.isfinite(deadline):
        raise ValueError("Finite absolute deadline required")
    net = FifoNetwork(instance) if net is None else net
    if getattr(net, "inst", None) is not instance:
        raise ValueError("FIFO network must belong to the exact instance")
    if incumbent is not None:
        incumbent = customers(incumbent, instance.n, "incumbent")
        if [a for a in incumbent if a not in set(block)] != outside:
            raise ValueError("Incumbent does not preserve outside chain")
    counters = {"array_slots_scanned": 0, "finite_labels": 0,
                "customer_arcs_attempted": 0, "successful_relaxations": 0,
                "return_candidates_evaluated": 0, "greedy_positions_evaluated": 0,
                "incumbent_profile_replacements": 0}
    started = clock()
    check_deadline(deadline, clock, counters)
    if decoder == "fifo_greedy_legacy":
        values, routes, augmented = _greedy(instance, outside, block, net, incumbent, deadline, clock, counters)
    else:
        values, routes = _exact(instance, outside, block, net, decoder == "fifo_contiguous_exact_pure",
                                deadline, clock, counters)
        augmented = None
    check_deadline(deadline, clock, counters)
    return {"values": values, "routes": routes, "complete": True, "decoder": decoder,
            "family": ("one contiguous cluster in one outside gap" if decoder == DECODERS[1]
                       else "free interleaving preserving outside order" if decoder == DECODERS[0]
                       else "legacy constructed greedy profiles plus incumbent augmentation"),
            "incumbent_augmented_mask": augmented, "counters": counters,
            "structural_counts": None if decoder == DECODERS[2] else structural_counts(
                len(outside), len(block), decoder == DECODERS[1]),
            "profile_seconds": clock() - started}


def _exact(i, outside, block, net, contiguous, deadline, clock, counters):
    m, k = len(outside), len(block)
    count = 1 << k
    labels = np.full((m + 1, count, k + 1), np.inf)
    predecessor = np.full(labels.shape, -1, dtype=np.int16)
    labels[0, 0, 0] = 0.
    for r in range(m + 1):
        for mask in range(count):
            check_deadline(deadline, clock, counters)
            for code in range(k + 1):
                counters["array_slots_scanned"] += 1
                departure = labels[r, mask, code]
                if not np.isfinite(departure):
                    continue
                counters["finite_labels"] += 1
                last = (outside[r - 1] + 1 if r else 0) if code == 0 else block[code - 1] + 1
                if r < m:
                    actual = outside[r]
                    counters["customer_arcs_attempted"] += 1
                    candidate = net.arrival(last, actual + 1, departure) + i.service[actual]
                    if candidate < labels[r + 1, mask, 0]:
                        labels[r + 1, mask, 0] = candidate
                        predecessor[r + 1, mask, 0] = code
                        counters["successful_relaxations"] += 1
                # A nonempty mask at an outside endpoint means the cluster closed.
                if contiguous and code == 0 and mask:
                    continue
                for j, actual in enumerate(block):
                    if mask >> j & 1:
                        continue
                    counters["customer_arcs_attempted"] += 1
                    candidate = net.arrival(last, actual + 1, departure) + i.service[actual]
                    new_mask = mask | 1 << j
                    if candidate < labels[r, new_mask, j + 1]:
                        labels[r, new_mask, j + 1] = candidate
                        predecessor[r, new_mask, j + 1] = code
                        counters["successful_relaxations"] += 1
    values, routes = np.full(count, np.inf), [None] * count
    for mask in range(count):
        check_deadline(deadline, clock, counters)
        if m == 0 and mask == 0:
            values[0], routes[0] = 0., []
            continue
        best_code = -1
        for code in range(k + 1):
            if not np.isfinite(labels[m, mask, code]):
                continue
            last = (outside[-1] + 1 if m else 0) if code == 0 else block[code - 1] + 1
            counters["return_candidates_evaluated"] += 1
            value = net.arrival(last, 0, labels[m, mask, code])
            if value < values[mask]:
                values[mask], best_code = value, code
        if best_code < 0:
            continue
        r, remaining, code, reverse = m, mask, best_code, []
        while r or remaining:
            old = code
            code = int(predecessor[r, remaining, old])
            if old == 0:
                reverse.append(outside[r - 1]); r -= 1
            else:
                reverse.append(block[old - 1]); remaining ^= 1 << (old - 1)
            if code < 0:
                raise RuntimeError("Broken FIFO profile predecessor")
        routes[mask] = list(reversed(reverse))
    return values, routes


def _greedy(i, outside, block, net, incumbent, deadline, clock, counters):
    k = len(block)
    values, routes = np.full(1 << k, np.inf), [None] * (1 << k)
    routes[0], values[0] = list(outside), route_finish(i, outside, net)
    prefixes = {}
    old_mask = None if incumbent is None else sum(1 << j for j, a in enumerate(block) if a in incumbent)
    old_finish = np.inf if incumbent is None else route_finish(i, incumbent, net)
    augmented = None
    for mask in range(1, 1 << k):
        check_deadline(deadline, clock, counters)
        best, cost = None, np.inf
        for j, customer in enumerate(block):
            if not mask >> j & 1:
                continue
            previous = mask ^ 1 << j
            route = routes[previous]
            if route is None:
                continue
            if previous not in prefixes:
                stamps, last = [0.], 0
                for actual in route:
                    check_deadline(deadline, clock, counters)
                    stamps.append(net.arrival(last, actual + 1, stamps[-1]) + i.service[actual])
                    last = actual + 1
                prefixes[previous] = stamps
            for position in range(len(route) + 1):
                check_deadline(deadline, clock, counters)
                counters["greedy_positions_evaluated"] += 1
                last = 0 if position == 0 else route[position - 1] + 1
                now = net.arrival(last, customer + 1, prefixes[previous][position]) + i.service[customer]
                counters["customer_arcs_attempted"] += 1
                last = customer + 1
                for actual in route[position:]:
                    check_deadline(deadline, clock, counters)
                    now = net.arrival(last, actual + 1, now) + i.service[actual]
                    counters["customer_arcs_attempted"] += 1
                    last = actual + 1
                finish = net.arrival(last, 0, now)
                counters["return_candidates_evaluated"] += 1
                if finish < cost:
                    cost, best = finish, route[:position] + [customer] + route[position:]
        if mask == old_mask and old_finish < cost:
            cost, best, augmented = old_finish, list(incumbent), mask
            counters["incumbent_profile_replacements"] += 1
        values[mask], routes[mask] = cost, best
    return values, routes, augmented
