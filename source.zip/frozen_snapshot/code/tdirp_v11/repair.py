"""One all-quantity repair, with raw-family evidence separate from retained fallback."""
from __future__ import annotations

import copy
from fractions import Fraction
import math
import time

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

from .profiles import DECODERS, FifoNetwork, ProfileInterrupted, build_profiles, customers
from schedule_repair import MILP_OPTIONS, inventory_recourse, verify_routes
from root_lp_probe import base_model

CONTRACT = "completion_c1_endholding_nowait_ML_header_v1"


def finite_or_none(value):
    return float(value) if value is not None and math.isfinite(float(value)) else None


def validate_instance(i):
    dimensions = (i.n, i.horizon, i.steps, i.step_seconds)
    if any(isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < 1 for value in dimensions):
        raise ValueError("Positive integral dimensions required")
    shape_pairs = ((i.service, (i.n,)), (i.initial, (i.n,)), (i.maximum, (i.n,)),
                   (i.minimum, (i.n,)), (i.demand, (i.horizon, i.n)),
                   (i.production, (i.horizon,)), (i.holding, (i.n,)),
                   (i.travel, (i.n + 1, i.n + 1, i.steps)))
    if any(np.asarray(value).shape != shape for value, shape in shape_pairs):
        raise ValueError("Instance array shape mismatch")
    integer_data = [i.travel, i.service, i.initial, i.maximum, i.minimum, i.demand,
                    i.production, [i.supplier_initial, i.capacity, i.deadline]]
    if any(not np.isfinite(a).all() or np.any(np.asarray(a) < 0) or
           np.any(np.asarray(a) != np.rint(a)) for a in integer_data):
        raise ValueError("Finite nonnegative integral benchmark data required")
    holding = np.r_[i.supplier_holding, i.holding]
    if not np.isfinite(holding).all() or np.any(holding < 0):
        raise ValueError("Finite nonnegative holding costs required")


def build_master(i, routes, block, tables):
    """Pure model construction. No partial table can be consumed as exact data."""
    if len(tables) != i.horizon or any(table.get("complete") is not True for table in tables):
        raise ValueError("Every period needs a complete profile table")
    lp, y, q, inv, z = base_model(i)
    zset = set(z)
    keep = [r for r, row in enumerate(lp.ub) if not zset.intersection(row)]
    lp.ub, lp.ubrhs = [lp.ub[r] for r in keep], [lp.ubrhs[r] for r in keep]
    for variable in z:
        lp.c[variable] = 0.
    columns, selected_customers = [], set(block)
    for p, route in enumerate(routes):
        present = set(route)
        for customer in range(i.n):
            lp.bounds[inv[p][customer + 1]] = (float(i.minimum[customer]), None)
            if customer not in selected_customers:
                lp.bounds[y[p][customer]] = (float(customer in present), float(customer in present))
        table = tables[p]
        eligible = [mask for mask, path in enumerate(table["routes"])
                    if path is not None and math.isfinite(table["values"][mask])
                    and table["values"][mask] <= i.deadline]
        cols = {mask: lp.var(c=float(table["values"][mask])) for mask in eligible}
        columns.append(cols)
        if not cols:
            return {"infeasible_period": p, "columns": columns}
        lp.equality({col: 1. for col in cols.values()}, 1.)
        for j, customer in enumerate(block):
            row = {y[p][customer]: -1.}
            row.update({col: 1. for mask, col in cols.items() if mask >> j & 1})
            lp.equality(row, 0.)
    integer = np.zeros(len(lp.c), dtype=np.uint8)
    for p in range(i.horizon):
        for customer in block:
            integer[y[p][customer]] = 1
    return {"lp": lp, "columns": columns, "integrality": integer,
            "visit_variables": y, "quantity_variables": q,
            "constraints": [LinearConstraint(lp.sparse(lp.eq), lp.eb, lp.eb),
                            LinearConstraint(lp.sparse(lp.ub), -np.inf, lp.ubrhs)],
            "bounds": Bounds([b[0] for b in lp.bounds],
                             [np.inf if b[1] is None else b[1] for b in lp.bounds])}


def one_repair(i, state, block, decoder, absolute_deadline, clock=time.perf_counter):
    """No polishing/outer search; return JSON-safe raw and retained evidence.

    The complete operation, including independent input/candidate verification,
    shares one absolute local deadline. A late candidate/certificate is recorded
    as late and cannot become the retained endpoint.
    """
    started = clock()
    if decoder not in DECODERS or not math.isfinite(absolute_deadline):
        raise ValueError("Declared decoder and finite deadline required")
    validate_instance(i)
    block = customers(block, i.n, "block")
    if len(block) > 10:
        raise ValueError("Block size exceeds 10")
    routes = [customers(route, i.n, "route") for route in state["routes"]]
    if len(routes) != i.horizon:
        raise ValueError("Route horizon mismatch")
    checked = verify_routes(i, routes, state["quantities"], "completion")
    if not checked.get("checked"):
        raise ValueError("Input state failed literal verification: " + str(checked.get("reason")))
    if state.get("exact_feasible_objective") is not None and Fraction(state["exact_feasible_objective"]) != Fraction(checked["exact_feasible_objective"]):
        raise ValueError("Frozen input objective mismatch")
    selected_set = set(block)
    input_in_raw_family = decoder != DECODERS[1] or all(
        not positions or positions[-1] - positions[0] + 1 == len(positions)
        for positions in ([index for index, a in enumerate(route) if a in selected_set] for route in routes))
    answer = {"contract": CONTRACT, "objective_definition": "completion", "decoder": decoder,
              "block": block, "status": "started", "raw_status": None,
              "raw_objective": None, "raw_exact_objective": None,
              "raw_master_lower_bound": None, "raw_master_optimal": False,
              "raw_conditional_optimum_verified": False, "raw_conditional_infeasible": False,
              "certificate_numeric_scope": "HiGHS floating-point termination with frozen tolerances and exact feasible replay; not a rational dual proof",
              "global_bound": None, "global_gap": None,
              "raw_bound_scope": ("constructed greedy/incumbent profile master only" if decoder == DECODERS[2]
                                  else "pure contiguous fixed-outside-order/block family" if decoder == DECODERS[1]
                                  else "free-interleaving fixed-outside-order/block family"),
              "outside_quantities_free": True, "input_verification": checked,
              "input_in_raw_family": input_in_raw_family,
              "retained_objective": checked["objective_decimal"],
              "retained_exact_objective": checked["exact_feasible_objective"],
              "retained_routes": copy.deepcopy(routes), "retained_quantities": copy.deepcopy(checked["quantities"]),
              "retained_origin": "input_external_fallback", "fallback_reason": None,
              "phase_seconds": {"input_verification": clock() - started}, "period_profiles": [],
              "completed_period_tables": 0, "tables_complete": False,
              "master_started": False, "candidate_verified": False, "candidate_eligible": False,
              "raw_master_evidence_eligible": False,
              "strict_raw_gain": False, "certificate_seconds": None,
              "profile_complete_seconds": None, "local_deadline": absolute_deadline}

    def finish(reason):
        answer["status"] = reason
        answer["fallback_reason"] = None if answer["retained_origin"] == "verified_raw_repair" else reason
        answer["wall_seconds"] = clock() - started
        return answer

    if clock() >= absolute_deadline:
        return finish("input_verification_deadline")
    phase = clock()
    net = FifoNetwork(i)
    tables = []
    for route in routes:
        outside = [a for a in route if a not in set(block)]
        try:
            table = build_profiles(i, outside, block, decoder, net, route,
                                   deadline=absolute_deadline, clock=clock)
        except ProfileInterrupted as exc:
            answer["interrupted_profile_counters"] = exc.counters
            answer["phase_seconds"]["profiles"] = clock() - phase
            return finish("profile_deadline")
        tables.append(table)
        answer["period_profiles"].append({key: value for key, value in table.items() if key != "values"})
        answer["period_profiles"][-1]["values"] = [finite_or_none(value) for value in table["values"]]
        answer["period_profiles"][-1]["outside"] = outside
        answer["completed_period_tables"] += 1
    answer["tables_complete"] = True
    answer["profile_complete_seconds"] = clock() - started
    answer["phase_seconds"]["profiles"] = clock() - phase
    phase = clock()
    model = build_master(i, routes, block, tables)
    answer["phase_seconds"]["master_build"] = clock() - phase
    answer["patterns_by_period"] = [len(cols) for cols in model["columns"]]
    if clock() >= absolute_deadline:
        return finish("master_build_deadline")
    if "infeasible_period" in model:
        answer["raw_status"] = 2
        if input_in_raw_family:
            return finish("incumbent_containment_contradiction_no_period_profile")
        answer["raw_conditional_infeasible"] = True
        answer["certificate_seconds"] = clock() - started
        return finish("raw_no_feasible_period_profile")
    lp = model["lp"]
    answer.update(master_started=True, variables=len(lp.c), binary_visits=len(block) * i.horizon)
    phase = clock()
    result = milp(lp.c, integrality=model["integrality"], bounds=model["bounds"],
                  constraints=model["constraints"],
                  options={"time_limit": max(.001, absolute_deadline - clock()), **MILP_OPTIONS})
    answer["phase_seconds"]["master_solve"] = clock() - phase
    answer.update(raw_status=int(result.status), solver_message=str(result.message),
                  raw_solver_objective=finite_or_none(result.fun),
                  raw_master_lower_bound=finite_or_none(getattr(result, "mip_dual_bound", None)),
                  raw_mip_gap=finite_or_none(getattr(result, "mip_gap", None)),
                  raw_mip_node_count=finite_or_none(getattr(result, "mip_node_count", None)))
    if clock() >= absolute_deadline:
        return finish("master_solve_deadline")
    answer["raw_master_evidence_eligible"] = True
    if result.status == 2:
        if input_in_raw_family:
            return finish("incumbent_containment_contradiction_master_infeasible")
        answer["raw_conditional_infeasible"] = True
        answer["certificate_seconds"] = clock() - started
        return finish("raw_master_infeasible")
    if result.x is None:
        return finish("raw_master_no_candidate")
    selected = [max(cols, key=lambda mask: result.x[cols[mask]]) for cols in model["columns"]]
    new_routes = [tables[p]["routes"][mask] for p, mask in enumerate(selected)]
    phase = clock()
    recourse = inventory_recourse(i, new_routes, time_limit=max(.001, absolute_deadline - clock()))
    answer["phase_seconds"]["recourse"] = clock() - phase
    answer["recourse_status"] = recourse.get("status", 0 if recourse.get("success") else None)
    if clock() >= absolute_deadline:
        return finish("recourse_deadline")
    if not recourse.get("success"):
        return finish("recourse_failure")
    phase = clock()
    verification = verify_routes(i, new_routes, recourse["quantities"], "completion")
    answer["phase_seconds"]["candidate_verification"] = clock() - phase
    answer["raw_verification"] = verification
    answer["candidate_verified"] = bool(verification.get("checked"))
    if not verification.get("checked"):
        return finish("candidate_verification_rejected")
    answer.update(raw_objective=verification["objective_decimal"],
                  raw_exact_objective=verification["exact_feasible_objective"],
                  raw_routes=copy.deepcopy(new_routes), raw_quantities=verification["quantities"])
    if clock() >= absolute_deadline:
        return finish("candidate_verification_deadline")
    answer["candidate_eligible"] = True
    answer["raw_master_optimal"] = result.status == 0 and result.fun is not None and abs(
        float(result.fun) - verification["objective_decimal"]) <= 1e-5
    answer["raw_conditional_optimum_verified"] = decoder != DECODERS[2] and answer["raw_master_optimal"]
    if answer["raw_conditional_optimum_verified"]:
        answer["certificate_seconds"] = clock() - started
    if Fraction(verification["exact_feasible_objective"]) < Fraction(checked["exact_feasible_objective"]):
        answer.update(retained_objective=verification["objective_decimal"],
                      retained_exact_objective=verification["exact_feasible_objective"],
                      retained_routes=copy.deepcopy(new_routes), retained_quantities=verification["quantities"],
                      retained_origin="verified_raw_repair", strict_raw_gain=True)
        return finish("raw_strict_improvement")
    return finish("raw_verified_nonimprovement")
