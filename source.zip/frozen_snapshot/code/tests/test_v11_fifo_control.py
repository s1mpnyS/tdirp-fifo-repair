"""Synthetic internal-logic tests only; no benchmark optimization or workers."""
from __future__ import annotations

from copy import deepcopy
from itertools import permutations
from pathlib import Path
from types import SimpleNamespace
import math
import sys
import unittest
from unittest.mock import patch
from unittest.mock import MagicMock

import numpy as np

CODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE))
from tdirp_v11 import profiles as p, repair as r, runner
sys.path.insert(0, str(CODE / "research_artifacts/tdirp_v3"))
from joint_repair import greedy_values
from schedule_repair import backbone_values
from fifo_probe import direct_arrival


def tiny(n=4, bins=4, step=10, seed=91):
    rng = np.random.default_rng(seed)
    travel = rng.integers(0, 13, size=(n + 1, n + 1, bins)).astype(float)
    for node in range(n + 1):
        travel[node, node, :] = 0
    return SimpleNamespace(name="synthetic", n=n, horizon=1, capacity=100, steps=bins,
        step_seconds=step, deadline=bins * step - 1, supplier_initial=100.,
        production=np.zeros(1), supplier_holding=.1, initial=np.zeros(n), maximum=np.full(n, 100.),
        minimum=np.zeros(n), demand=np.zeros((1, n)), holding=np.full(n, .2),
        service=np.ones(n), travel=travel)


def literal_cost(i, route):
    now, last = 0., 0
    for actual in route:
        now = direct_arrival(i, last, actual + 1, now) + i.service[actual]
        last = actual + 1
    return direct_arrival(i, last, 0, now) if route else 0.


def brute(i, outside, block, contiguous):
    answer = []
    for mask in range(1 << len(block)):
        selected = [a for j, a in enumerate(block) if mask >> j & 1]
        if contiguous:
            routes = [outside[:gap] + list(order) + outside[gap:]
                      for order in permutations(selected) for gap in range(len(outside) + 1)]
        else:
            routes = [list(order) for order in permutations(outside + selected)
                      if [a for a in order if a in outside] == outside]
        answer.append(min(literal_cost(i, route) for route in routes))
    return answer


def strict_interleaving():
    i = tiny(4, bins=1, step=10000)
    i.travel[:] = 50
    i.service[:] = 0
    for node in range(5):
        i.travel[node, node, :] = 0
    # Depot -> b0 -> o0 -> b1 -> o1 -> depot is uniquely cheap.
    for a, b in zip((0, 1, 3, 2, 4), (1, 3, 2, 4, 0)):
        i.travel[a, b, :] = 1
    return i


class ProfileTests(unittest.TestCase):
    def test_should_match_literal_exhaustive_families_given_fifo_profiles(self):
        for seed in (5, 17, 91):
            i = tiny(5, seed=seed)
            for decoder, contiguous in ((p.DECODERS[0], False), (p.DECODERS[1], True)):
                table = p.build_profiles(i, [3, 4], [0, 1, 2], decoder)
                np.testing.assert_equal(table["values"], brute(i, [3, 4], [0, 1, 2], contiguous))
                for mask, route in enumerate(table["routes"]):
                    if route is None:
                        self.assertTrue(math.isinf(table["values"][mask])); continue
                    self.assertEqual([a for a in route if a in (3, 4)], [3, 4])
                    self.assertEqual(set(route) - {3, 4}, {j for j in range(3) if mask >> j & 1})
                    self.assertEqual(literal_cost(i, route), table["values"][mask])

    def test_should_match_frozen_exact_and_greedy_given_identical_synthetic_inputs(self):
        for seed in (3, 8, 11):
            i = tiny(5, seed=seed); net = p.FifoNetwork(i)
            for incumbent in ([0, 3, 1, 4], [3, 4], None):
                exact = p.build_profiles(i, [3, 4], [0, 1, 2], p.DECODERS[0], net, incumbent)
                expected, orders = backbone_values(i, [3, 4], [0, 1, 2], net)
                np.testing.assert_equal(exact["values"], expected)
                self.assertEqual(exact["routes"], orders)
                greedy = p.build_profiles(i, [3, 4], [0, 1, 2], p.DECODERS[2], net, incumbent)
                expected, orders = greedy_values(i, [3, 4], [0, 1, 2], net, incumbent)
                np.testing.assert_equal(greedy["values"], expected)
                self.assertEqual(greedy["routes"], orders)

    def test_should_forbid_reopening_when_a_selected_cluster_has_closed(self):
        i = strict_interleaving()
        free = p.build_profiles(i, [2, 3], [0, 1], p.DECODERS[0])
        cluster = p.build_profiles(i, [2, 3], [0, 1], p.DECODERS[1])
        self.assertEqual(free["routes"][3], [0, 2, 1, 3])
        self.assertLess(free["values"][3], cluster["values"][3])
        self.assertEqual(cluster["values"][3], brute(i, [2, 3], [0, 1], True)[3])

    def test_should_recover_feasible_nonempty_mask_when_nonmetric_backbone_is_unreachable(self):
        i = tiny(2, bins=1, step=10); i.service[:] = 0; i.travel[:] = 20
        i.travel[0, 1, :] = i.travel[1, 2, :] = i.travel[2, 0, :] = 1
        for node in range(3): i.travel[node, node, :] = 0
        table = p.build_profiles(i, [1], [0], p.DECODERS[1])
        self.assertTrue(math.isinf(table["values"][0]))
        self.assertEqual(table["values"][1], 3)

    def test_should_preserve_empty_route_and_coincide_for_empty_outside_or_singletons(self):
        i = tiny(3)
        for outside, block in (([], []), ([], [0, 1, 2]), ([0, 1], []), ([1, 2], [0])):
            free = p.build_profiles(i, outside, block, p.DECODERS[0])
            cluster = p.build_profiles(i, outside, block, p.DECODERS[1])
            np.testing.assert_equal(free["values"], cluster["values"])
        table = p.build_profiles(i, [], [0, 1], p.DECODERS[2], incumbent=[])
        self.assertEqual(table["routes"][0], []); self.assertEqual(table["values"][0], 0)

    def test_should_match_structural_counts_when_every_label_is_finite(self):
        for m in range(4):
            for k in range(5):
                i = tiny(max(1, m + k), bins=1, step=1000)
                i.travel[:] = 0; i.service[:] = 0
                for decoder in p.DECODERS[:2]:
                    table = p.build_profiles(i, list(range(k, k + m)), list(range(k)), decoder)
                    structural, actual = table["structural_counts"], table["counters"]
                    self.assertEqual(actual["finite_labels"], structural["structurally_reachable_labels"])
                    self.assertEqual(actual["customer_arcs_attempted"], structural["customer_transition_arcs"])
                    self.assertEqual(actual["return_candidates_evaluated"], structural["return_candidates"])

    def test_should_interrupt_without_a_partial_table_when_deadline_expires(self):
        class Clock:
            def __init__(self): self.now = 0
            def __call__(self): self.now += 1; return self.now
        for decoder in p.DECODERS:
            with self.assertRaises(p.ProfileInterrupted):
                p.build_profiles(tiny(5), [3, 4], [0, 1, 2], decoder, deadline=8, clock=Clock())

    def test_should_reject_malformed_customer_sets_and_cross_instance_networks(self):
        i = tiny()
        for outside, block in (([1, 1], [0]), ([0], [0]), ([], [True]), ([], [4])):
            with self.assertRaises(ValueError): p.build_profiles(i, outside, block, p.DECODERS[1])
        with self.assertRaises(ValueError): p.build_profiles(i, [], [0], p.DECODERS[1], p.FifoNetwork(tiny()))

    def test_should_match_literal_clock_at_bin_boundaries_and_drop_ramps(self):
        i = tiny(1, bins=3, step=10); i.travel[0, 1, :] = [20, 1, 15]
        net = p.FifoNetwork(i)
        for stamp in (0, 9, 10, 19, 20, 29, 30, float("inf")):
            self.assertEqual(net.arrival(0, 1, stamp), direct_arrival(i, 0, 1, stamp))
        self.assertEqual(net.arrival(0, 1, 9), 11)


class MasterAndRetentionTests(unittest.TestCase):
    def test_should_free_all_quantities_and_use_literal_cutoff_equality(self):
        i = tiny(2, bins=1, step=100)
        table = {"complete": True, "routes": [[1], [1, 0]], "values": [i.deadline, i.deadline + 1]}
        model = r.build_master(i, [[0, 1]], [0], [table])
        self.assertEqual(set(model["columns"][0]), {0})
        for variable in model["quantity_variables"][0]: self.assertEqual(model["lp"].bounds[variable], (0., None))
        y = model["visit_variables"][0]
        self.assertEqual(model["lp"].bounds[y[1]], (1., 1.))
        with self.assertRaises(ValueError): r.build_master(i, [[0, 1]], [0], [{**table, "complete": False}])

    def fake_backend(self, i, state, block, decoder):
        table = p.build_profiles(i, [a for a in state["routes"][0] if a not in block], block, decoder,
                                 incumbent=state["routes"][0])
        model = r.build_master(i, state["routes"], block, [table])
        selected_mask = min(model["columns"][0])
        x = np.zeros(len(model["lp"].c)); x[model["columns"][0][selected_mask]] = 1
        value = float(table["values"][selected_mask]) + 10.  # supplier stock 100 * holding .1
        return SimpleNamespace(status=0, message="synthetic backend contract", fun=value, x=x,
                               mip_dual_bound=value, mip_gap=0., mip_node_count=0)

    def test_should_keep_interleaving_input_outside_pure_contiguous_bound(self):
        i = strict_interleaving(); state = {"routes": [[0, 2, 1, 3]], "quantities": [[0, 0, 0, 0]]}
        original = deepcopy(state)
        backend = self.fake_backend(i, state, [0, 1], p.DECODERS[1])
        with patch.object(r, "milp", return_value=backend), patch.object(r, "inventory_recourse",
                return_value={"success": True, "quantities": [[0, 0, 0, 0]]}):
            result = r.one_repair(i, state, [0, 1], p.DECODERS[1], absolute_deadline=100., clock=lambda: 0.)
        self.assertTrue(result["raw_conditional_optimum_verified"])
        self.assertLess(result["retained_objective"], result["raw_master_lower_bound"])
        self.assertEqual(result["retained_origin"], "input_external_fallback")
        self.assertEqual(result["retained_routes"], state["routes"])
        self.assertEqual(state, original)

    def test_should_never_label_greedy_master_as_exact_conditional_neighborhood(self):
        i = strict_interleaving(); state = {"routes": [[0, 2, 1, 3]], "quantities": [[0, 0, 0, 0]]}
        backend = self.fake_backend(i, state, [0, 1], p.DECODERS[2])
        with patch.object(r, "milp", return_value=backend), patch.object(r, "inventory_recourse",
                return_value={"success": True, "quantities": [[0, 0, 0, 0]]}):
            result = r.one_repair(i, state, [0, 1], p.DECODERS[2], absolute_deadline=100., clock=lambda: 0.)
        self.assertTrue(result["raw_master_optimal"])
        self.assertFalse(result["raw_conditional_optimum_verified"])
        self.assertIn("constructed", result["raw_bound_scope"])

    def test_should_retain_input_when_solver_returns_after_local_deadline(self):
        i = strict_interleaving(); state = {"routes": [[0, 2, 1, 3]], "quantities": [[0, 0, 0, 0]]}
        now = [0.]
        def late(*args, **kwargs):
            now[0] = 7.
            return SimpleNamespace(status=0, message="late", fun=1., x=None)
        with patch.object(r, "milp", side_effect=late):
            result = r.one_repair(i, state, [0, 1], p.DECODERS[1], absolute_deadline=6., clock=lambda: now[0])
        self.assertEqual(result["status"], "master_solve_deadline")
        self.assertFalse(result["candidate_eligible"])
        self.assertFalse(result["raw_conditional_optimum_verified"])
        self.assertEqual(result["retained_origin"], "input_external_fallback")

    def test_should_stop_before_solver_when_profile_construction_expires(self):
        i = strict_interleaving(); state = {"routes": [[0, 2, 1, 3]], "quantities": [[0, 0, 0, 0]]}
        with patch.object(r, "build_profiles", side_effect=p.ProfileInterrupted({"finite_labels": 2})), \
             patch.object(r, "milp") as solver:
            result = r.one_repair(i, state, [0, 1], p.DECODERS[1], 100., clock=lambda: 0.)
        solver.assert_not_called(); self.assertFalse(result["tables_complete"])
        self.assertEqual(result["status"], "profile_deadline")

    def test_should_fail_closed_on_infeasibility_in_incumbent_containing_families(self):
        i = strict_interleaving(); state = {"routes": [[0, 2, 1, 3]], "quantities": [[0, 0, 0, 0]]}
        backend = SimpleNamespace(status=2, message="synthetic contradictory backend", fun=None, x=None)
        for decoder in p.DECODERS:
            with patch.object(r, "milp", return_value=backend):
                result = r.one_repair(i, state, [0, 1], decoder, 100., clock=lambda: 0.)
            if decoder == p.DECODERS[1]:
                self.assertTrue(result["raw_conditional_infeasible"])
            else:
                self.assertFalse(result["raw_conditional_infeasible"])
                self.assertIsNone(result["certificate_seconds"])
                self.assertIn("incumbent_containment_contradiction", result["status"])
        contiguous_state = {"routes": [[0, 1, 2, 3]], "quantities": [[0, 0, 0, 0]]}
        with patch.object(r, "milp", return_value=backend):
            result = r.one_repair(i, contiguous_state, [0, 1], p.DECODERS[1], 100., clock=lambda: 0.)
        self.assertTrue(result["input_in_raw_family"])
        self.assertFalse(result["raw_conditional_infeasible"])
        self.assertIn("incumbent_containment_contradiction", result["status"])


class ProtocolTests(unittest.TestCase):
    def test_should_build_exactly_288_cells_without_outcome_based_selection(self):
        cases = sorted(runner.expected_cases())
        cells = runner.build_cells(cases)
        self.assertEqual(len(cells), 288); self.assertEqual(cells, runner.build_cells(cases))
        self.assertEqual(len({cell["cell_id"] for cell in cells}), 288)
        for H, n in ((6, 15), (6, 20), (3, 25), (3, 30)):
            for index in (1, 3):
                a, b = [runner.block_order(f"H{H}/inst_{n}_{M}_{index}.txt") for M in (30, 120)]
                self.assertEqual(a, b); self.assertEqual(set(a), set(range(n)))

    def test_should_reject_late_or_misbound_publications_given_good_cost(self):
        plan = {"plan_sha256": "bound", "parent_seconds": 15., "local_seconds": 6.}
        cell = {"cell_id": "0000"}
        payload = {"plan_sha256": "bound", "cell": cell, "completed_elapsed_since_parent": 10.,
                   "result": {"candidate_eligible": True, "wall_seconds": 2.}}
        receipt = {"payload_sha256": runner.digest(payload)}
        self.assertEqual(runner.publication_rejections(payload, receipt, cell, plan, 11.), [])
        self.assertIn("publication_observed_after_parent_cap", runner.publication_rejections(payload, receipt, cell, plan, 16.))
        changed = {**payload, "cell": {"cell_id": "0001"}}
        self.assertIn("identity_mismatch", runner.publication_rejections(changed,
            {"payload_sha256": runner.digest(changed)}, cell, plan, 11.))
        changed = deepcopy(payload); changed["result"]["wall_seconds"] = 7.
        self.assertIn("candidate_or_certificate_outside_local_cap", runner.publication_rejections(changed,
            {"payload_sha256": runner.digest(changed)}, cell, plan, 11.))
        changed = deepcopy(payload); changed["completed_elapsed_since_parent"] = True
        self.assertIn("completion_outside_parent_cap", runner.publication_rejections(changed,
            {"payload_sha256": runner.digest(changed)}, cell, plan, 11.))
        changed = deepcopy(payload)
        changed["result"] = {"raw_conditional_infeasible": True, "wall_seconds": 7., "certificate_seconds": 7.}
        rejected = runner.publication_rejections(changed, {"payload_sha256": runner.digest(changed)}, cell, plan, 11.)
        self.assertIn("candidate_or_certificate_outside_local_cap", rejected)
        self.assertIn("certificate_time_invalid", rejected)

    def test_should_observe_exit_race_publication_and_reject_it_after_parent_cap(self):
        plan = {"plan_sha256": "bound", "parent_seconds": 15., "local_seconds": 6.}
        cell = {"cell_id": "0000"}
        payload = {"plan_sha256": "bound", "cell": cell, "completed_elapsed_since_parent": 10.,
                   "result": {"candidate_eligible": True, "wall_seconds": 2.}}
        import json
        def read(path, *args, **kwargs):
            return json.dumps({"payload_sha256": runner.digest(payload)} if str(path).endswith(".commit.json") else payload)
        with patch.object(Path, "exists", return_value=True), patch.object(Path, "read_text", read):
            found = runner.observe_publication("worker.json", cell, plan, 100., clock=lambda: 111.)
            self.assertEqual(found[2], [])
            late = runner.observe_publication("worker.json", cell, plan, 100., clock=lambda: 116.)
            self.assertIn("publication_observed_after_parent_cap", late[2])

    def test_should_apply_actual_shortened_allowance_to_infeasibility_certificate(self):
        plan = {"plan_sha256": "bound", "parent_seconds": 15., "local_seconds": 6.}
        cell = {"cell_id": "0000"}
        payload = {"plan_sha256": "bound", "cell": cell, "completed_elapsed_since_parent": 11.,
                   "local_allowance_seconds": 2.,
                   "result": {"raw_conditional_infeasible": True, "wall_seconds": 3., "certificate_seconds": 3.}}
        rejected = runner.publication_rejections(payload, {"payload_sha256": runner.digest(payload)}, cell, plan, 11.)
        self.assertIn("evidence_outside_actual_local_allowance", rejected)

    def test_should_scan_once_more_on_child_exit_given_an_atomic_publication_race(self):
        plan = {"plan_sha256": "bound", "parent_seconds": 15., "local_seconds": 6.,
                "sampled_tree_memory_mib": 1024., "sampling_seconds": .1,
                "states": {"synthetic": {"I": {"exact_feasible_objective": "5", "routes": [[]], "quantities": [[0]]}}}}
        cell = {"cell_id": "0000", "input": "synthetic", "state": "I"}
        result = {"retained_origin": "input_external_fallback", "retained_exact_objective": "5",
                  "retained_routes": [[]], "retained_quantities": [[0]]}
        process, job = MagicMock(), MagicMock()
        process.poll.return_value = 0; process.returncode = 0
        job.sample.return_value = {"resident_bytes": 1}
        with patch.object(Path, "mkdir"), patch.object(Path, "open", MagicMock()), \
             patch.object(runner, "atomic"), patch.object(runner, "load_monitor", return_value=lambda: job), \
             patch.object(runner.subprocess, "Popen", return_value=process), \
             patch.object(runner, "observe_publication", side_effect=[None, ({"result": result}, 11., [])]) as observe:
            row = runner.run_one("frozen.json", plan, cell, "results")
        self.assertEqual(observe.call_count, 2)
        self.assertTrue(row["publication_eligible"])
        job.sample.return_value = {"resident_bytes": 1025 * 1024 ** 2}
        with patch.object(Path, "mkdir"), patch.object(Path, "open", MagicMock()), \
             patch.object(runner, "atomic"), patch.object(runner, "load_monitor", return_value=lambda: job), \
             patch.object(runner.subprocess, "Popen", return_value=process), \
             patch.object(runner, "observe_publication", return_value=({"result": result}, 11., [])):
            row = runner.run_one("frozen.json", plan, cell, "results")
        self.assertFalse(row["publication_eligible"])
        self.assertIn("first_publication_after_sampled_memory_violation", row["publication_rejections"])


if __name__ == "__main__":
    unittest.main()
